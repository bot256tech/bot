@echo off
REM ============================================================================
REM 1_setup.cmd  -  One-time setup: venv, dependencies, database, superuser.
REM Double-click this ONCE after installing Python, PostgreSQL and Redis.
REM ============================================================================
setlocal
cd /d "%~dp0backend"

echo.
echo [1/6] Creating virtual environment...
if not exist ".venv\Scripts\python.exe" (
    python -m venv .venv
)

echo [2/6] Activating virtual environment...
call ".venv\Scripts\activate.bat"

echo [3/6] Upgrading pip...
python -m pip install --upgrade pip

echo [4/6] Installing dependencies...
pip install -r requirements.txt
pip install MetaTrader5

echo [5/6] Preparing environment file...
if not exist ".env" (
    if exist ".env.production" (
        copy ".env.production" ".env"
        echo    Copied .env.production to .env  ^(edit it if needed^)
    ) else (
        copy ".env.example" ".env"
        echo    Copied .env.example to .env  ^(EDIT IT with your DB/MT5 details^)
    )
)

echo [6/6] Database: creating DB/role then migrating...
python init_db.py
python manage.py migrate
python manage.py collectstatic --noinput

echo.
echo Now create your admin login:
python manage.py createsuperuser

echo.
echo ============================================================
echo  Setup complete. Next: double-click  START_ALL.cmd
echo ============================================================
pause
endlocal
