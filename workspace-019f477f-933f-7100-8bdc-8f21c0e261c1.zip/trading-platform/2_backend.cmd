@echo off
REM ============================================================================
REM 2_backend.cmd  -  Starts the Django ASGI server (Daphne) on 0.0.0.0:8000.
REM Serves both HTTP and WebSockets so the frontend/browser can reach it.
REM ============================================================================
setlocal
cd /d "%~dp0backend"
call ".venv\Scripts\activate.bat"

echo Applying migrations and collecting static files...
python manage.py migrate --noinput
python manage.py collectstatic --noinput

echo.
echo Starting backend on http://0.0.0.0:8000  (docs: /api/docs/)
daphne -b 0.0.0.0 -p 8000 config.asgi:application

pause
endlocal
