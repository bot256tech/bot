@echo off
REM ============================================================================
REM 3_worker.cmd  -  Starts the Celery worker (signal eval, prop-guard, tasks).
REM Requires Redis/Memurai to be running.
REM ============================================================================
setlocal
cd /d "%~dp0backend"
call ".venv\Scripts\activate.bat"

echo Starting Celery worker (solo pool for Windows)...
celery -A config worker --loglevel=info --pool=solo

pause
endlocal
