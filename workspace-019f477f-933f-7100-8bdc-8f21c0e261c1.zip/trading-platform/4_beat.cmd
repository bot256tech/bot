@echo off
REM ============================================================================
REM 4_beat.cmd  -  Starts the Celery beat scheduler (periodic scans, cache
REM purge, latency monitor). Requires Redis/Memurai to be running.
REM ============================================================================
setlocal
cd /d "%~dp0backend"
call ".venv\Scripts\activate.bat"

echo Starting Celery beat scheduler...
celery -A config beat --loglevel=info

pause
endlocal
