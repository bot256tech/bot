@echo off
REM ============================================================================
REM 5_frontend.cmd  -  Builds (first run) and serves the Next.js frontend on
REM 0.0.0.0:3000 so it is reachable from a browser on the VPS public IP.
REM ============================================================================
setlocal
cd /d "%~dp0frontend"

if not exist "node_modules" (
    echo Installing frontend dependencies...
    call npm install
)

if not exist ".next" (
    echo Building the frontend...
    call npm run build
)

echo.
echo Starting frontend on http://0.0.0.0:3000
set PORT=3000
call npm run start -- -H 0.0.0.0 -p 3000

pause
endlocal
