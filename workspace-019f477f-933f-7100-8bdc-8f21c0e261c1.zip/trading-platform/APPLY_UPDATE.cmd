@echo off
REM ============================================================================
REM APPLY_UPDATE.cmd  -  Apply a downloaded update zip and restart everything.
REM
REM 1. Download the update zip (e.g. full-update-v2.zip)
REM 2. Right-click it -> Extract All -> into  C:\trading-platform  (merge/overwrite)
REM 3. Double-click THIS file.
REM
REM It rebuilds the frontend (so UI changes show) and restarts all services.
REM ============================================================================
setlocal
cd /d C:\trading-platform

echo === Verifying the new scoring is present ===
findstr /C:"require_core" backend\apps\trading\engines\scoring.py >nul
if errorlevel 1 (
  echo *** ERROR: new scoring NOT found in backend\apps\trading\engines\scoring.py
  echo *** The update was not extracted to the right place. Extract the zip INTO
  echo *** C:\trading-platform so files land in backend\... and frontend\...
  pause
  exit /b 1
)
echo OK: new scoring is present.

echo === Backend: migrate + collectstatic ===
cd backend
call .venv\Scripts\activate.bat
python manage.py migrate --noinput
python manage.py collectstatic --noinput
cd ..

echo === Frontend: CLEAN rebuild (this is what makes UI changes show) ===
cd frontend
if exist .next rmdir /s /q .next
call npm install
call npm run build
cd ..

echo.
echo ============================================================
echo  Update applied. Now start the 4 services in separate windows:
echo    backend : cd backend ^&^& .venv\Scripts\activate.bat ^&^& daphne -b 0.0.0.0 -p 8000 config.asgi:application
echo    frontend: cd frontend ^&^& npx next start -H 0.0.0.0 -p 3000
echo    worker  : cd backend ^&^& .venv\Scripts\activate.bat ^&^& celery -A config worker --loglevel=info --pool=solo
echo    beat    : cd backend ^&^& .venv\Scripts\activate.bat ^&^& celery -A config beat --loglevel=info
echo  Then hard-refresh the browser: Ctrl+Shift+R
echo ============================================================
pause
