# Institutional Trading Platform

An AI-ready, institutional-grade trading platform: Django + DRF + Channels
backend, Next.js/TypeScript frontend, a broker abstraction layer with a live
**MetaTrader 5** adapter and a **simulated** adapter, realtime signal delivery
over WebSockets, JWT auth with role-based access control, and Windows-VPS
deployment via **NSSM** (no Docker).

> **Build status (Part 1 + Part 2):** verified end-to-end with **31 passing
> backend tests**, a **clean OpenAPI schema (0 errors / 0 warnings, 38
> endpoints)**, and a successful `next build` (7 routes). Completed & tested:
>
> - **Signals** vertical slice (model → service → REST → WebSocket → UI)
> - **Broker Intelligence Engine** — all broker/symbol specs read from MT5
>   (leverage, contract size, tick value/size, volume step, filling modes…),
>   never hardcoded; simulated adapter mirrors them for any OS
> - **Position Sizing Engine** — one code path for Forex/Indices/Metals/Energy/
>   Crypto using broker-reported specs; full auditable breakdown
> - **Risk Engine** — fixed/dynamic/confidence risk, daily/weekly/monthly loss
>   limits, max trades/exposure/drawdown, emergency stop
> - **Strategy engine framework** + core engines: **CRT, Liquidity, KOD, CISD,
>   Market Structure**, composed by a weighted **Scoring Engine**
> - **Execution Engine** — the deterministic **Romeo TPT** pipeline
>   (scoring → HTF alignment → session/news gate → risk → sizing → execute),
>   fully logged with a per-stage audit trail on every trade
> - **Market Scanner** (UI) — ranked, auto-refreshing table of the best setups
>   across the whole profile universe, spread/volume-filtered, one-click analyze
> - **Open Positions + order placement** (UI) · **Trade Journal + Analytics**
>   (win rate/PF/expectancy/drawdown/equity curve + charts) · **Telegram**
>   signal delivery (linking, verification webhook, broadcasts)
>
> Remaining engines from the Part 2 spec (Order Block, FVG, Premium/Discount,
> Session/News automation, Portfolio correlation, backtesting/Monte-Carlo, AI
> narration) plug into the same framework — each is a further tested slice.

## Trading engine architecture (Part 2)

```
apps/trading/engines/
├── base.py             # Candle + EngineResult + StrategyEngine protocol
├── liquidity.py        # swing detection, equal highs/lows, liquidity sweeps
├── crt.py              # Candle Range Theory (range / manipulation / distribution)
├── kod.py              # Kill-Off Delivery confirmation candle
├── structure.py        # Market Structure (HH/HL/LH/LL, BOS, CHOCH) + CISD
├── order_block.py      # Order Blocks: bullish/bearish/mitigated/breaker/invalid
├── fvg.py              # Fair Value Gaps + consequent encroachment / fill / strength
├── premium_discount.py # Dealing-range equilibrium, premium/discount, OTE zones
├── scoring.py          # weighted composition of 8 engines -> 0..100 score + bias
├── position_sizing.py  # broker-aware lot sizing, all asset classes
├── risk.py             # risk modes + account-protection limits
├── data_integrity.py   # stale-data / latency guard (abort > 500ms lag)
├── resampler.py        # custom timeframe (M69) resampler w/ bounded, purged cache
├── backtest.py         # bar-by-bar historical replay + performance metrics
└── execution.py        # Romeo TPT pipeline orchestrator (deterministic, audited)
```

### Strategy engines (8), weighted in the scoring pipeline

| Engine | Weight | Detects |
|--------|--------|---------|
| CRT | 0.18 | Range / manipulation / distribution, target liquidity |
| KOD | 0.18 | Sweep + rejection + close-back-inside confirmation candle |
| Liquidity | 0.15 | BSL/SSL, equal highs/lows, sweeps, failed sweeps |
| CISD | 0.11 | Change in state of delivery (momentum/structure shift) |
| Market Structure | 0.11 | HH/HL/LH/LL, BOS, CHOCH |
| Order Block | 0.10 | Bullish/bearish/mitigated/breaker/invalid blocks |
| FVG | 0.09 | Fair value gaps, consequent encroachment (50%), fill state |
| Premium/Discount | 0.08 | Equilibrium, premium/discount, OTE (62–79%) zones |

### Auto-Profile: Small Account vs Prop Firm (`profiles.py`)

On **every execution** the active trading profile is resolved from **live broker
equity** and enforced by the pipeline. It flips automatically as the account
grows past / drops below `SMALL_ACCOUNT_THRESHOLD` (default **$1000**):

| Equity | Profile | Risk % | Daily loss | Max drawdown | HTF match | Universe |
|--------|---------|--------|-----------|--------------|-----------|----------|
| `< $1000` | **SMALL** (growth) | 0.75% | 8% | 20% | relaxed | `SMALL_EXECUTION_SYMBOLS` |
| `≥ $1000` | **PROP** (funded) | 0.25% | 4% | 8% | strict | `PROP_EXECUTION_SYMBOLS` |

Small accounts trade for growth (higher per-trade risk, looser HTF) **but keep
safety caps** so a losing streak can't blow the account. Prop accounts enforce
tight prop-firm drawdown limits. All thresholds come from the `.env`
(`PROP_*` / `SMALL_*` / `AUTO_*` keys). The active profile is exposed at
`GET /trading/profile/`. Set `AUTO_PROFILE_ENABLED=false` + `TRADING_PROFILE=`
to force one profile.

### Prop-Firm Guard (tiered, PROP profile only) — `prop_guard.py`

On top of the base Risk Engine, prop accounts run a tiered guard evaluated on
every execution (and surfaced via `GET /trading/profile/` → `prop_guard`):

| Tier | Daily loss | Overall drawdown | Effect |
|------|-----------|------------------|--------|
| `OK` | < warning | < warning | trade normally |
| `WARNING` | ≥ `PROP_DAILY_WARNING_PERCENT` (3%) | ≥ `PROP_MAX_DRAWDOWN_WARNING_PERCENT` (6%) | trade allowed + alert |
| `SOFT_STOP` | ≥ `PROP_DAILY_SOFT_STOP_PERCENT` (3.5%) | ≥ `PROP_MAX_DRAWDOWN_SOFT_STOP_PERCENT` (7%) | **block new entries** |
| `HARD_STOP` | ≥ `PROP_DAILY_DRAWDOWN_LIMIT_PERCENT` (4%) | ≥ `PROP_MAX_DRAWDOWN_LIMIT_PERCENT` (8%) | **block new entries** |

Also enforced (all → HARD_STOP block on new entries):
- **Weekend rule:** closes after `PROP_FRIDAY_CLOSE_HOUR/MINUTE_UTC` (Fri 20:30
  UTC), stays closed all Saturday, and **re-opens Sunday** from
  `PROP_SUNDAY_OPEN_HOUR/MINUTE_UTC` (21:00 UTC) so weekend setups can be taken.
  Toggle Sunday entirely with `PROP_SUNDAY_TRADING_ENABLED`.
- **News blackout:** blocks inside ±`PROP_NEWS_BLOCK_BEFORE/AFTER_MINUTES` of a
  high-impact event (pass events into `evaluate_prop_guard`; calendar source is
  a documented extension point).
- **Min trading days:** `PROP_MIN_TRADING_DAYS` tracked toward the phase target
  (informational — never blocks entries).

### Telegram anti-spam throttle — `telegram_bot/throttle.py`

Prop-guard alerts are **deduplicated and rate-limited** so a lingering breach
doesn't flood the channel. The same tier+reason is sent at most once per window
(`TELEGRAM_THROTTLE_WARNING_SEC` 30 min, `..._SOFT_STOP_SEC`/`..._HARD_STOP_SEC`
15 min, `..._ERROR_SEC` 5 min). Uses Redis when configured (shared across
workers) with an in-process fallback. Set a window to `0` to disable throttling.

### Execution safety (deployment-hardened)

- **Stale-data guard** (`data_integrity.py`): the pipeline's stage 0 aborts a
  *live* order if the freshest broker quote lags more than `MAX_DATA_LATENCY_MS`
  (default **500 ms**) — prevents late entries during fast sweeps. A Celery beat
  task (`trading.monitor_data_latency`, every 60 s) also watches key symbols.
- **Custom-timeframe (M69) resampler** (`resampler.py`): builds 69-minute bars
  from 1-minute bars with a **bounded, self-purging cache** (hard entry cap +
  TTL). A Celery beat task (`trading.purge_resampler_cache`, **hourly**) releases
  stale frames so the VPS never accumulates dataframe memory before the NY open.

## Which / how many pairs?

**All symbols your MT5 broker exposes** — the platform is *symbol-agnostic*.
There is no hardcoded pair list in the engine: the Broker Intelligence Engine
reads each symbol's specs on demand, and position sizing/execution adapt
automatically. The simulated adapter ships with 22 reference instruments
(EURUSD, GBPUSD, USDJPY, XAUUSD, XAGUSD, US30, NAS100, SPX500, GER40, UK100,
USOIL, NGAS, BTCUSD, ETHUSD, SOLUSD, XRPUSD, ADAUSD, BNBUSD, AVAXUSD, LINKUSD,
DOGEUSD, LTCUSD, MATICUSD) so it runs anywhere; on the live MT5 terminal you get
**every tradable symbol the broker offers** with no code changes. All data and
execution come from MT5 only — no Binance/OKX/Bybit/Coinbase integration.

Every trade persists a `decision_audit` JSON with each pipeline stage's
pass/fail, the full scoring breakdown, the risk checks, and the sizing maths —
so any decision is reconstructable and auditable.

---

## 1. Folder structure

```
trading-platform/
├── backend/                     # Django project (API + engines + realtime)
│   ├── config/                  # Project config (settings, urls, asgi, celery)
│   │   ├── settings.py          # 12-factor settings (env-driven)
│   │   ├── urls.py              # /api/v1 routes + OpenAPI docs
│   │   ├── asgi.py              # HTTP + WebSocket routing (Channels)
│   │   └── celery.py            # Celery app + beat schedule
│   ├── apps/
│   │   ├── core/                # Shared primitives (base models, roles, ws auth)
│   │   │   ├── models.py        # UUID PK, timestamps, soft-delete base model
│   │   │   ├── roles.py         # Role enum + RBAC permission classes
│   │   │   ├── exceptions.py    # Uniform API error envelope
│   │   │   └── ws_auth.py       # JWT auth middleware for WebSockets
│   │   ├── accounts/            # Custom User, JWT auth, profile API, admin
│   │   ├── broker/              # Broker abstraction layer (the engine boundary)
│   │   │   ├── gateway.py       # BrokerGateway protocol + value objects
│   │   │   ├── factory.py       # Adapter resolution + singleton
│   │   │   └── adapters/
│   │   │       ├── simulated.py # Runs anywhere (sandbox/CI/demo)
│   │   │       └── mt5.py       # Live MetaTrader 5 (Windows only)
│   │   └── signals/             # Signal domain (the completed vertical slice)
│   │       ├── models.py        # Signal model
│   │       ├── services.py      # Generation, evaluation, broadcasting (domain)
│   │       ├── views.py         # REST viewset (thin controller)
│   │       ├── consumers.py     # WebSocket consumer
│   │       ├── routing.py       # WS routes
│   │       ├── tasks.py         # Celery tasks
│   │       └── admin.py
│   ├── tests/                   # pytest suite (broker + signals E2E)
│   ├── requirements.txt
│   └── .env.example
├── frontend/                    # Next.js 14 App Router + TS + Tailwind
│   └── src/
│       ├── app/                 # Routes: /, /dashboard, /signals
│       ├── components/          # Sidebar, Providers
│       ├── lib/api.ts           # Typed API + WS client (JWT + auto-refresh)
│       └── store/auth.ts        # Zustand auth store
├── scripts/                     # PowerShell run scripts (per service)
├── deployment/windows/          # NSSM service installer
├── documentation/               # Guides (this file references them)
└── logs/                        # Rotating per-domain log files
```

## 2. Database schema (current)

All domain models inherit `apps.core.models.BaseModel`: **UUID PK**,
`created_at`, `updated_at`, `is_deleted` + `deleted_at` (**soft delete**),
`Meta.ordering`, and indexes.

| Model | Key fields |
|-------|-----------|
| `accounts.User` | `email` (login), `role`, `is_email_verified`, `is_2fa_enabled`, `totp_secret`, `telegram_chat_id` |
| `signals.Signal` | `symbol`, `direction`, `status`, `entry_price`, `stop_loss`, `take_profit`, `confidence`, `strategy`, `rationale`, `created_by`, `published_at`, `closed_at` — computed `risk_reward` |

**Roles:** `super_admin`, `admin`, `developer`, `analyst`, `moderator`,
`trader`, `subscriber`. (Subscription/billing models were intentionally
**omitted** per requirement — the platform has no commercial layer.)

Generate migrations:
```bash
python manage.py makemigrations
python manage.py migrate
```

## 3. API documentation

Interactive docs are generated with **drf-spectacular**:

| URL | Purpose |
|-----|---------|
| `/api/schema/` | OpenAPI 3 schema (YAML) |
| `/api/docs/`   | Swagger UI |
| `/api/redoc/`  | ReDoc |

Endpoints (`/api/v1`):

```
POST   /auth/register/            Create account (defaults to subscriber)
POST   /auth/login/               Obtain JWT access+refresh (+ user profile)
POST   /auth/token/refresh/       Rotate access token
POST   /auth/token/verify/        Verify a token
GET    /auth/me/    PATCH         Current user profile

GET    /signals/                  List signals (filter: ?status= ?symbol=)
POST   /signals/                  Create signal (author roles)
GET    /signals/{id}/             Retrieve
POST   /signals/generate/         Generate from live market data (author roles)
POST   /signals/{id}/cancel/      Cancel a signal (author roles)

GET    /broker/account/           Account summary (balance/equity/margin…)
GET    /broker/quote/?symbol=     Live bid/ask quote
GET    /broker/positions/         Open positions
GET    /broker/symbol/?symbol=    Broker Intelligence: full symbol specification

GET    /trading/scan/             Rank all profile symbols by setup score (liquidity-filtered)
GET    /trading/analyze/?symbol=  Run all 8 scoring engines (read-only)
GET    /trading/backtest/?symbol= Backtest the strategy over historical bars
GET    /trading/trades/           List the user's trades
POST   /trading/trades/execute/   Run the Romeo TPT pipeline (dry-run or live)
POST   /trading/trades/{id}/close/   Close / partial-close a trade
POST   /trading/trades/{id}/modify/  Modify SL/TP
GET    /trading/analytics/        Performance metrics + equity curve
GET    /trading/profile/          Active profile (SMALL/PROP) from live equity
GET/PATCH /trading/risk-profile/  Per-user risk configuration
       /trading/journal/          Trade journal CRUD

POST   /telegram/link/            Begin linking (returns /verify code)
GET    /telegram/subscribers/     List linked chats
PATCH  /telegram/subscribers/{id}/   Update notification preferences
POST   /telegram/webhook/{secret}/   Inbound bot webhook (/verify handler)
```

WebSocket: `ws://HOST/ws/signals/?token=<access_jwt>` — emits
`connection.ready`, `signal.created`, `signal.update`, `signal.closed`.

## 4. Environment configuration

Copy `backend/.env.example` → `backend/.env` and fill in values. Key toggles:

- `BROKER_ADAPTER` — `simulated` (any OS) or `mt5` (Windows + MT5 terminal)
- `POSTGRES_*` — leave `POSTGRES_DB` empty to fall back to SQLite (dev only)
- `USE_REDIS_CHANNELS=True` in production (Redis-backed Channels + Celery)
- `MT5_LOGIN / MT5_PASSWORD / MT5_SERVER / MT5_TERMINAL_PATH` — live broker

Frontend env (optional): `NEXT_PUBLIC_API_BASE`, `NEXT_PUBLIC_WS_BASE`.

## 5. Stack (no Docker)

Redis, PostgreSQL, Python, Node — installed natively. See the installation and
deployment guides in `documentation/`.

## Health & monitoring

| Endpoint | Purpose |
|----------|---------|
| `GET /api/v1/health/` | Liveness (public, always 200 if serving) — use for NSSM/uptime checks |
| `GET /api/v1/health/ready/` | Readiness — verifies DB + Redis + broker; 503 if degraded |

## 🚀 Easiest start (Windows — double-click .cmd files)

No commands to type. At the repo root:
1. `1_setup.cmd` — one-time: venv, deps, database, migrate, create admin.
2. `open_firewall.cmd` — right-click → Run as administrator (opens 8000 & 3000).
3. `START_ALL.cmd` — launches backend + worker + beat + frontend.

Then open `http://194.37.80.107:3000`. Individual parts: `2_backend.cmd`,
`3_worker.cmd`, `4_beat.cmd`, `5_frontend.cmd`. After changing the VPS IP in
`frontend\.env.production`, run `rebuild_frontend.cmd`. (Also open ports 8000 &
3000 in your cloud provider's firewall.)

## ✅ Deployment checklist (VPS 194.37.80.107)

1. Copy `backend/.env.production` → `backend/.env` on the VPS.
2. **Set `DJANGO_DEBUG=false`** (auto-enables HSTS, secure cookies, SSL redirect —
   verified: `check --deploy` then reports 0 issues). Keep `SECURE_SSL_REDIRECT=true`
   only once TLS is in front; use `false` for plain-HTTP bring-up.
3. Set a real `TELEGRAM_WEBHOOK_SECRET`.
4. Confirm PostgreSQL + Redis running; MT5 terminal open & logged in.
5. `pip install -r backend/requirements.txt && pip install MetaTrader5` (Windows).
6. `python manage.py migrate && python manage.py collectstatic --noinput && python manage.py createsuperuser`
7. `frontend/.env.production` → API/WS base at `194.37.80.107:8000`; `npm ci && npm run build`.
8. Start NSSM services: backend (Daphne), Celery worker, Celery beat, frontend.
9. Verify `GET /api/v1/health/ready/` returns `{"status":"ready"}`.
10. **Never commit `.env`** — a `.gitignore` at the repo root already excludes it.

**Status:** 74/74 backend tests pass · OpenAPI 0 errors/0 warnings (42 endpoints)
· `check --deploy` clean under production settings · frontend `next build` clean.

## 6–9. Guides

- **Installation:** `documentation/INSTALLATION.md`
- **Deployment (Windows VPS + NSSM):** `documentation/DEPLOYMENT.md`
- **Testing:** `documentation/TESTING.md`
- **Maintenance:** `documentation/MAINTENANCE.md`

## 10. Future extension points

- **New broker:** implement `BrokerGateway` in `apps/broker/adapters/`, register
  it in `factory._build`. Nothing else changes.
- **AI signal model:** replace the body of
  `signals.services.generate_signal_from_market` with a model call — the
  signature, API, WebSocket and frontend stay identical.
- **New domain (analytics, journal, telegram, notifications, risk):** copy the
  `signals` app layout (models → services → views/serializers → urls →
  optional consumers/tasks/admin) and register under `/api/v1/`.
- **2FA enforcement:** `User.is_2fa_enabled` + `totp_secret` fields already
  exist; add a verifying auth serializer.
- **DB-backed schedules:** swap the static `beat_schedule` for
  `django-celery-beat`.
