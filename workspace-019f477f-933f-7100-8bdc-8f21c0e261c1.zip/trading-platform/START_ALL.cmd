@echo off
REM ============================================================================
REM START_ALL.cmd  -  Launches the whole platform, each part in its own window.
REM
REM PREREQUISITES (must already be running):
REM   * PostgreSQL
REM   * Redis / Memurai
REM   * MetaTrader 5 terminal (open + logged in) if BROKER_ADAPTER=mt5
REM
REM Double-click this file to start everything.
REM ============================================================================
setlocal

echo ============================================================
echo   Institutional Trading Platform - starting all components
echo ============================================================
echo   Make sure PostgreSQL, Redis/Memurai and MT5 are running.
echo.

echo Rebuilding frontend so the latest UI is served (prevents stale build)...
call "%~dp0rebuild_frontend.cmd"

echo Launching Backend (Daphne :8000)...
start "TradeDesk Backend" cmd /k "%~dp02_backend.cmd"
timeout /t 5 /nobreak >nul

echo Launching Celery Worker...
start "TradeDesk Worker" cmd /k "%~dp03_worker.cmd"
timeout /t 3 /nobreak >nul

echo Launching Celery Beat...
start "TradeDesk Beat" cmd /k "%~dp04_beat.cmd"
timeout /t 3 /nobreak >nul

echo Launching Frontend (Next.js :3000)...
start "TradeDesk Frontend" cmd /k "%~dp05_frontend.cmd"

echo.
echo ============================================================
echo  All components launched in separate windows.
echo    Backend  : http://localhost:8000/api/docs/
echo    Frontend : http://localhost:3000
echo    Public   : http://194.37.80.107:3000
echo  Close a window to stop that component.
echo ============================================================
pause
endlocal
