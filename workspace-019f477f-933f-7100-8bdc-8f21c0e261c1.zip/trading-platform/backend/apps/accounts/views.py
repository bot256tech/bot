"""Authentication & profile API views."""
from __future__ import annotations

from drf_spectacular.utils import extend_schema
from rest_framework import generics, permissions
from rest_framework_simplejwt.views import TokenObtainPairView

from .models import User
from .serializers import RegisterSerializer, TokenPairSerializer, UserSerializer


@extend_schema(tags=["auth"])
class RegisterView(generics.CreateAPIView):
    """Register a new user (defaults to the SUBSCRIBER role)."""

    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]


@extend_schema(tags=["auth"])
class LoginView(TokenObtainPairView):
    """Obtain a JWT access/refresh pair. Returns the user profile alongside."""

    serializer_class = TokenPairSerializer
    permission_classes = [permissions.AllowAny]


@extend_schema(tags=["auth"])
class MeView(generics.RetrieveUpdateAPIView):
    """Retrieve or update the currently authenticated user's profile."""

    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self) -> User:
        return self.request.user

    def get_serializer_class(self):
        # Allow updating full_name / telegram_chat_id via a dedicated serializer.
        if self.request.method in ("PUT", "PATCH"):
            return _ProfileUpdateSerializer
        return UserSerializer


from rest_framework import serializers  # noqa: E402


class _ProfileUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ("full_name", "telegram_chat_id")
