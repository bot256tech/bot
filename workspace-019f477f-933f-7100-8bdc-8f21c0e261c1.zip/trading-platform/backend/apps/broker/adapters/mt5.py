"""MetaTrader 5 broker adapter.

Implements the ``BrokerGateway`` contract against the official ``MetaTrader5``
Python package. This package only runs on Windows with a running MT5 terminal,
so the import is performed lazily: the adapter can be imported on any OS and
only fails (clearly) if you actually try to connect without MT5 available.

Configure via environment variables:
    MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, MT5_TERMINAL_PATH (optional)
"""
from __future__ import annotations

from decimal import Decimal

from decouple import config

from apps.broker.gateway import (
    AccountSummary,
    OrderRequest,
    OrderResult,
    OrderSide,
    OrderType,
    Position,
    Quote,
    SymbolInfo,
)
from apps.core.exceptions import BrokerError


def _import_mt5():
    try:
        import MetaTrader5 as mt5  # type: ignore
    except ImportError as exc:  # pragma: no cover - platform dependent
        raise BrokerError(
            "The MetaTrader5 package is not installed. It is only available on "
            "Windows with a running MT5 terminal. Set BROKER_ADAPTER=simulated "
            "for non-Windows environments."
        ) from exc
    return mt5


class MT5Broker:
    """Live MetaTrader 5 gateway."""

    name = "mt5"

    def __init__(self) -> None:
        self._mt5 = None
        self._connected = False
        self._login = config("MT5_LOGIN", default=0, cast=int)
        self._password = config("MT5_PASSWORD", default="")
        self._server = config("MT5_SERVER", default="")
        self._path = config("MT5_TERMINAL_PATH", default="")

    # -- lifecycle ------------------------------------------------------- #
    def connect(self) -> bool:
        mt5 = _import_mt5()
        self._mt5 = mt5
        kwargs = {}
        if self._path:
            kwargs["path"] = self._path
        if self._login:
            kwargs.update(login=self._login, password=self._password, server=self._server)
        if not mt5.initialize(**kwargs):
            raise BrokerError(f"MT5 initialize failed: {mt5.last_error()}")
        self._connected = True
        return True

    def disconnect(self) -> None:
        if self._mt5:
            self._mt5.shutdown()
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected and self._mt5 is not None

    def list_symbols(self) -> list[str]:
        """All symbols advertised by the broker (Market Watch + full list)."""
        mt5 = self._require()
        symbols = mt5.symbols_get() or []
        return [s.name for s in symbols]

    def _require(self):
        if not self.is_connected():
            raise BrokerError("MT5 gateway is not connected.")
        return self._mt5

    # -- market data ----------------------------------------------------- #
    def symbol_info(self, symbol: str) -> SymbolInfo:
        mt5 = self._require()
        info = mt5.symbol_info(symbol)
        if info is None:
            raise BrokerError(f"Unknown symbol: {symbol}")
        # Ensure the symbol is selected in Market Watch so specs are populated.
        if not info.visible:
            mt5.symbol_select(symbol, True)
            info = mt5.symbol_info(symbol)

        # Decode supported filling modes bitmask.
        filling: list[str] = []
        mode = getattr(info, "filling_mode", 0)
        if mode & getattr(mt5, "SYMBOL_FILLING_FOK", 1):
            filling.append("FOK")
        if mode & getattr(mt5, "SYMBOL_FILLING_IOC", 2):
            filling.append("IOC")
        if not filling:
            filling = ["IOC"]

        return SymbolInfo(
            symbol=symbol,
            digits=info.digits,
            point=Decimal(str(info.point)),
            contract_size=Decimal(str(info.trade_contract_size)),
            tick_size=Decimal(str(info.trade_tick_size or info.point)),
            tick_value=Decimal(str(info.trade_tick_value)),
            min_volume=Decimal(str(info.volume_min)),
            max_volume=Decimal(str(info.volume_max)),
            volume_step=Decimal(str(info.volume_step)),
            spread_points=int(info.spread),
            trade_allowed=info.trade_mode != mt5.SYMBOL_TRADE_MODE_DISABLED,
            filling_modes=tuple(filling),
            currency_base=info.currency_base,
            currency_profit=info.currency_profit,
            currency_margin=info.currency_margin,
            margin_initial=Decimal(str(getattr(info, "margin_initial", 0) or 0)),
        )

    def get_quote(self, symbol: str) -> Quote:
        mt5 = self._require()
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            raise BrokerError(f"No tick data for {symbol}")
        return Quote(
            symbol=symbol,
            bid=Decimal(str(tick.bid)),
            ask=Decimal(str(tick.ask)),
            timestamp=float(tick.time),
        )

    def get_candles(self, symbol: str, timeframe: str = "M5", count: int = 200):
        from apps.broker.gateway import Bar

        mt5 = self._require()
        tf_map = {
            "M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5,
            "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30,
            "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4,
            "D1": mt5.TIMEFRAME_D1, "W1": mt5.TIMEFRAME_W1, "MN1": mt5.TIMEFRAME_MN1,
        }
        tf = tf_map.get(timeframe.upper(), mt5.TIMEFRAME_M5)
        rates = mt5.copy_rates_from_pos(symbol, tf, 0, count)
        if rates is None:
            raise BrokerError(f"No history for {symbol} {timeframe}")
        bars = []
        for r in rates:
            bars.append(
                Bar(
                    time=int(r["time"]),
                    open=Decimal(str(r["open"])),
                    high=Decimal(str(r["high"])),
                    low=Decimal(str(r["low"])),
                    close=Decimal(str(r["close"])),
                    volume=Decimal(str(r["tick_volume"])),
                )
            )
        return bars

    # -- account --------------------------------------------------------- #
    def account_summary(self) -> AccountSummary:
        mt5 = self._require()
        acc = mt5.account_info()
        if acc is None:
            raise BrokerError("Unable to read MT5 account info.")
        term = mt5.terminal_info()
        return AccountSummary(
            login=str(acc.login),
            balance=Decimal(str(acc.balance)),
            equity=Decimal(str(acc.equity)),
            margin=Decimal(str(acc.margin)),
            free_margin=Decimal(str(acc.margin_free)),
            margin_level=Decimal(str(acc.margin_level or 0)),
            currency=acc.currency,
            leverage=acc.leverage,
            connected=True,
            server=acc.server,
            broker_name=acc.company,
            trade_allowed=bool(getattr(term, "trade_allowed", True)) and bool(acc.trade_allowed),
        )

    # -- trading --------------------------------------------------------- #
    def place_order(self, request: OrderRequest) -> OrderResult:
        mt5 = self._require()
        tick = mt5.symbol_info_tick(request.symbol)
        is_buy = request.side == OrderSide.BUY
        order_type = mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL
        price = float(request.price) if request.price else (tick.ask if is_buy else tick.bid)

        mt5_request = {
            "action": mt5.TRADE_ACTION_DEAL
            if request.order_type == OrderType.MARKET
            else mt5.TRADE_ACTION_PENDING,
            "symbol": request.symbol,
            "volume": float(request.volume),
            "type": order_type,
            "price": price,
            "deviation": 20,
            "magic": 20260708,
            "comment": request.comment or "trading-platform",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        if request.stop_loss is not None:
            mt5_request["sl"] = float(request.stop_loss)
        if request.take_profit is not None:
            mt5_request["tp"] = float(request.take_profit)

        result = mt5.order_send(mt5_request)
        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            msg = getattr(result, "comment", "order_send returned None")
            return OrderResult(False, None, None, f"Order rejected: {msg}")
        return OrderResult(
            True, str(result.order), Decimal(str(result.price)), "Order filled."
        )

    def close_position(self, ticket: str, volume: Decimal | None = None) -> OrderResult:
        mt5 = self._require()
        positions = mt5.positions_get(ticket=int(ticket))
        if not positions:
            return OrderResult(False, ticket, None, "Position not found.")
        pos = positions[0]
        is_buy = pos.type == mt5.POSITION_TYPE_BUY
        tick = mt5.symbol_info_tick(pos.symbol)
        close_type = mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY
        price = tick.bid if is_buy else tick.ask
        close_vol = (
            float(volume) if volume and float(volume) < pos.volume else pos.volume
        )
        result = mt5.order_send(
            {
                "action": mt5.TRADE_ACTION_DEAL,
                "symbol": pos.symbol,
                "volume": close_vol,
                "type": close_type,
                "position": int(ticket),
                "price": price,
                "deviation": 20,
                "magic": 20260708,
                "comment": "close",
                "type_time": mt5.ORDER_TIME_GTC,
                "type_filling": mt5.ORDER_FILLING_IOC,
            }
        )
        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            return OrderResult(False, ticket, None, "Close rejected.")
        partial = close_vol < pos.volume
        return OrderResult(
            True,
            ticket,
            Decimal(str(result.price)),
            "Partial close." if partial else "Position closed.",
        )

    def modify_position(
        self,
        ticket: str,
        stop_loss: Decimal | None = None,
        take_profit: Decimal | None = None,
    ) -> OrderResult:
        mt5 = self._require()
        positions = mt5.positions_get(ticket=int(ticket))
        if not positions:
            return OrderResult(False, ticket, None, "Position not found.")
        pos = positions[0]
        request = {
            "action": mt5.TRADE_ACTION_SLTP,
            "symbol": pos.symbol,
            "position": int(ticket),
            "sl": float(stop_loss) if stop_loss is not None else pos.sl,
            "tp": float(take_profit) if take_profit is not None else pos.tp,
        }
        result = mt5.order_send(request)
        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            return OrderResult(False, ticket, None, "Modify rejected.")
        return OrderResult(True, ticket, Decimal(str(pos.price_current)), "Position modified.")

    def open_positions(self) -> list[Position]:
        mt5 = self._require()
        positions = mt5.positions_get() or []
        out: list[Position] = []
        for p in positions:
            side = OrderSide.BUY if p.type == mt5.POSITION_TYPE_BUY else OrderSide.SELL
            out.append(
                Position(
                    ticket=str(p.ticket),
                    symbol=p.symbol,
                    side=side,
                    volume=Decimal(str(p.volume)),
                    open_price=Decimal(str(p.price_open)),
                    current_price=Decimal(str(p.price_current)),
                    profit=Decimal(str(p.profit)),
                    stop_loss=Decimal(str(p.sl)) if p.sl else None,
                    take_profit=Decimal(str(p.tp)) if p.tp else None,
                )
            )
        return out
