"""In-memory simulated broker adapter.

Implements the full ``BrokerGateway`` contract without any external dependency
so the platform runs, tests and demos on any OS (including this Linux sandbox
and CI). Prices follow a deterministic random walk seeded per symbol so tests
are reproducible.
"""
from __future__ import annotations

import random
import threading
import time
from decimal import Decimal

from apps.broker.gateway import (
    AccountSummary,
    OrderRequest,
    OrderResult,
    OrderSide,
    Position,
    Quote,
    SymbolInfo,
)

# Reasonable starting mid-prices for common instruments.
_BASE_PRICES: dict[str, float] = {
    "EURUSD": 1.0850,
    "GBPUSD": 1.2700,
    "USDJPY": 157.20,
    "XAUUSD": 2350.0,
    "XAGUSD": 30.50,
    "US30": 39000.0,
    "NAS100": 18500.0,
    "SPX500": 5400.0,
    "GER40": 18400.0,
    "UK100": 8200.0,
    "USOIL": 82.0,
    "NGAS": 2.80,
    "BTCUSD": 62000.0,
    "ETHUSD": 3400.0,
    "SOLUSD": 145.0,
    "XRPUSD": 0.52,
    "ADAUSD": 0.45,
    "BNBUSD": 580.0,
    "AVAXUSD": 28.0,
    "LINKUSD": 15.0,
    "DOGEUSD": 0.13,
    "LTCUSD": 85.0,
    "MATICUSD": 0.72,
}
_DEFAULT_PRICE = 100.0


def _asset_class(symbol: str) -> str:
    s = symbol.upper()
    crypto = ("BTC", "ETH", "SOL", "XRP", "ADA", "BNB", "AVAX", "LINK", "DOGE", "LTC", "MATIC")
    indices = ("US30", "NAS100", "SPX500", "GER40", "UK100", "US500", "JP225")
    metals = ("XAU", "XAG", "XPT", "XPD")
    energy = ("OIL", "NGAS", "USOIL", "UKOIL", "GAS")
    if any(c in s for c in crypto):
        return "crypto"
    if any(i in s for i in indices):
        return "index"
    if any(m in s for m in metals):
        return "metal"
    if any(e in s for e in energy):
        return "energy"
    return "forex"


def _symbol_spec(symbol: str) -> dict:
    """Per-asset-class specification mimicking real broker reporting.

    ``tick_value`` is the profit (in account currency) of a 1-point move on a
    1.0-lot position. ``margin_initial`` is per-lot required margin (0 => derive
    from leverage & contract size).
    """
    s = symbol.upper()
    cls = _asset_class(s)
    if cls == "crypto":
        return {
            "digits": 2,
            "base": s.replace("USD", ""),
            "contract_size": Decimal("1"),
            "tick_value": Decimal("0.01"),  # 1 unit, 0.01 point
            "min_volume": Decimal("0.01"),
            "max_volume": Decimal("50"),
            "volume_step": Decimal("0.01"),
            "spread_points": 200,
            "margin_initial": Decimal("0"),  # derive from leverage
        }
    if cls == "index":
        return {
            "digits": 2,
            "base": s,
            "contract_size": Decimal("1"),
            "tick_value": Decimal("0.01"),
            "min_volume": Decimal("0.10"),
            "max_volume": Decimal("200"),
            "volume_step": Decimal("0.10"),
            "spread_points": 150,
            "margin_initial": Decimal("0"),
        }
    if cls == "metal":
        return {
            "digits": 2,
            "base": s.replace("USD", ""),
            "contract_size": Decimal("100"),  # 100 oz per lot
            "tick_value": Decimal("1"),  # $1 per 0.01 move on 1 lot of 100oz
            "min_volume": Decimal("0.01"),
            "max_volume": Decimal("100"),
            "volume_step": Decimal("0.01"),
            "spread_points": 30,
            "margin_initial": Decimal("0"),
        }
    if cls == "energy":
        return {
            "digits": 2,
            "base": s,
            "contract_size": Decimal("1000"),
            "tick_value": Decimal("10"),
            "min_volume": Decimal("0.01"),
            "max_volume": Decimal("100"),
            "volume_step": Decimal("0.01"),
            "spread_points": 30,
            "margin_initial": Decimal("0"),
        }
    # forex
    digits = 3 if s.endswith("JPY") else 5
    return {
        "digits": digits,
        "base": s[:3],
        "contract_size": Decimal("100000"),
        # 1 point on 1 std lot: ~$1 for 5-digit, ~$0.93 for JPY (approx as $1).
        "tick_value": Decimal("1"),
        "min_volume": Decimal("0.01"),
        "max_volume": Decimal("100"),
        "volume_step": Decimal("0.01"),
        "spread_points": 10,
        "margin_initial": Decimal("0"),
    }


class SimulatedBroker:
    """Thread-safe simulated broker with a random-walk price feed."""

    name = "simulated"

    def __init__(self, seed: int = 42) -> None:
        self._connected = False
        self._lock = threading.RLock()
        self._rng = random.Random(seed)
        self._mids: dict[str, float] = dict(_BASE_PRICES)
        self._positions: dict[str, Position] = {}
        self._ticket_seq = 1000
        self._balance = Decimal("100000.00")
        self._leverage = 100

    # -- lifecycle ------------------------------------------------------- #
    def connect(self) -> bool:
        with self._lock:
            self._connected = True
        return True

    def disconnect(self) -> None:
        with self._lock:
            self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    def list_symbols(self) -> list[str]:
        """All symbols the simulated broker knows about."""
        return list(_BASE_PRICES.keys())

    # -- market data ----------------------------------------------------- #
    def _mid(self, symbol: str) -> float:
        mid = self._mids.get(symbol, _DEFAULT_PRICE)
        # Random walk of +/- ~0.05%.
        mid *= 1 + self._rng.uniform(-0.0005, 0.0005)
        self._mids[symbol] = mid
        return mid

    def symbol_info(self, symbol: str) -> SymbolInfo:
        """Return a realistic, per-asset-class spec (as a broker would report)."""
        spec = _symbol_spec(symbol)
        digits = spec["digits"]
        point = Decimal(1).scaleb(-digits)
        return SymbolInfo(
            symbol=symbol,
            digits=digits,
            point=point,
            contract_size=spec["contract_size"],
            tick_size=point,
            tick_value=spec["tick_value"],
            min_volume=spec["min_volume"],
            max_volume=spec["max_volume"],
            volume_step=spec["volume_step"],
            spread_points=spec["spread_points"],
            trade_allowed=True,
            filling_modes=("IOC", "FOK"),
            currency_base=spec["base"],
            currency_profit="USD",
            currency_margin="USD",
            margin_initial=spec["margin_initial"],
        )

    def get_quote(self, symbol: str) -> Quote:
        with self._lock:
            mid = self._mid(symbol)
        spread = mid * 0.0001
        return Quote(
            symbol=symbol,
            bid=Decimal(str(round(mid - spread / 2, 5))),
            ask=Decimal(str(round(mid + spread / 2, 5))),
            timestamp=time.time(),
        )

    def get_candles(self, symbol: str, timeframe: str = "M5", count: int = 200) -> list["Bar"]:
        """Deterministic synthetic OHLC series (seeded random walk)."""
        from apps.broker.gateway import Bar

        tf_seconds = {
            "M1": 60, "M5": 300, "M15": 900, "M30": 1800,
            "H1": 3600, "H4": 14400, "D1": 86400,
        }.get(timeframe.upper(), 300)

        rng = random.Random(hash((symbol, timeframe)) & 0xFFFFFFFF)
        base = _BASE_PRICES.get(symbol, _DEFAULT_PRICE)
        digits = self.symbol_info(symbol).digits
        q = Decimal(1).scaleb(-digits)

        bars: list[Bar] = []
        price = base
        now = int(time.time())
        start = now - tf_seconds * count
        for i in range(count):
            drift = rng.uniform(-0.002, 0.002)
            o = price
            c = price * (1 + drift)
            hi = max(o, c) * (1 + abs(rng.uniform(0, 0.001)))
            lo = min(o, c) * (1 - abs(rng.uniform(0, 0.001)))
            bars.append(
                Bar(
                    time=start + i * tf_seconds,
                    open=Decimal(str(o)).quantize(q),
                    high=Decimal(str(hi)).quantize(q),
                    low=Decimal(str(lo)).quantize(q),
                    close=Decimal(str(c)).quantize(q),
                    volume=Decimal(str(rng.randint(100, 1000))),
                )
            )
            price = c
        return bars

    # -- account --------------------------------------------------------- #
    def account_summary(self) -> AccountSummary:
        with self._lock:
            floating = sum((p.profit for p in self._positions.values()), Decimal("0"))
            equity = self._balance + floating
            margin = self._used_margin()
            margin_level = (
                (equity / margin * 100).quantize(Decimal("0.01"))
                if margin > 0
                else Decimal("0")
            )
            return AccountSummary(
                login="SIM-0001",
                balance=self._balance,
                equity=equity,
                margin=margin,
                free_margin=equity - margin,
                margin_level=margin_level,
                currency="USD",
                leverage=self._leverage,
                connected=self._connected,
                server="Simulated-Server",
                broker_name="Simulated Broker Ltd",
                trade_allowed=True,
            )

    def _used_margin(self) -> Decimal:
        total = Decimal("0")
        for pos in self._positions.values():
            info = self.symbol_info(pos.symbol)
            notional = pos.open_price * pos.volume * info.contract_size
            total += (notional / self._leverage).quantize(Decimal("0.01"))
        return total

    # -- trading --------------------------------------------------------- #
    def place_order(self, request: OrderRequest) -> OrderResult:
        if not self._connected:
            return OrderResult(False, None, None, "Broker not connected.")
        with self._lock:
            quote = self.get_quote(request.symbol)
            price = quote.ask if request.side == OrderSide.BUY else quote.bid
            self._ticket_seq += 1
            ticket = str(self._ticket_seq)
            self._positions[ticket] = Position(
                ticket=ticket,
                symbol=request.symbol,
                side=request.side,
                volume=request.volume,
                open_price=price,
                current_price=price,
                profit=Decimal("0"),
                stop_loss=request.stop_loss,
                take_profit=request.take_profit,
            )
            return OrderResult(True, ticket, price, "Order filled (simulated).")

    def close_position(self, ticket: str, volume: Decimal | None = None) -> OrderResult:
        with self._lock:
            pos = self._positions.get(ticket)
            if pos is None:
                return OrderResult(False, ticket, None, "Position not found.")
            quote = self.get_quote(pos.symbol)
            close_price = quote.bid if pos.side == OrderSide.BUY else quote.ask

            close_vol = volume if volume and volume < pos.volume else pos.volume
            realised = self._pnl(pos, close_price, close_vol)
            self._balance += realised

            if close_vol >= pos.volume:
                self._positions.pop(ticket, None)
                return OrderResult(True, ticket, close_price, "Position closed (simulated).")
            # Partial close: shrink the remaining position.
            self._positions[ticket] = Position(
                ticket=pos.ticket,
                symbol=pos.symbol,
                side=pos.side,
                volume=(pos.volume - close_vol),
                open_price=pos.open_price,
                current_price=close_price,
                profit=Decimal("0"),
                stop_loss=pos.stop_loss,
                take_profit=pos.take_profit,
            )
            return OrderResult(True, ticket, close_price, "Partial close (simulated).")

    def modify_position(
        self,
        ticket: str,
        stop_loss: Decimal | None = None,
        take_profit: Decimal | None = None,
    ) -> OrderResult:
        with self._lock:
            pos = self._positions.get(ticket)
            if pos is None:
                return OrderResult(False, ticket, None, "Position not found.")
            self._positions[ticket] = Position(
                ticket=pos.ticket,
                symbol=pos.symbol,
                side=pos.side,
                volume=pos.volume,
                open_price=pos.open_price,
                current_price=pos.current_price,
                profit=pos.profit,
                stop_loss=stop_loss if stop_loss is not None else pos.stop_loss,
                take_profit=take_profit if take_profit is not None else pos.take_profit,
            )
            return OrderResult(True, ticket, pos.current_price, "Position modified.")

    def _pnl(self, pos: Position, price: Decimal, volume: Decimal) -> Decimal:
        """P&L in account currency using the symbol's tick value & size."""
        info = self.symbol_info(pos.symbol)
        direction = 1 if pos.side == OrderSide.BUY else -1
        points = (price - pos.open_price) / info.tick_size * direction
        pnl = points * info.tick_value * volume
        return Decimal(str(round(pnl, 2)))

    def open_positions(self) -> list[Position]:
        with self._lock:
            refreshed: list[Position] = []
            for ticket, pos in self._positions.items():
                quote = self.get_quote(pos.symbol)
                current = quote.bid if pos.side == OrderSide.BUY else quote.ask
                profit = self._pnl(pos, current, pos.volume)
                updated = Position(
                    ticket=pos.ticket,
                    symbol=pos.symbol,
                    side=pos.side,
                    volume=pos.volume,
                    open_price=pos.open_price,
                    current_price=current,
                    profit=profit,
                    stop_loss=pos.stop_loss,
                    take_profit=pos.take_profit,
                )
                self._positions[ticket] = updated
                refreshed.append(updated)
            return refreshed
