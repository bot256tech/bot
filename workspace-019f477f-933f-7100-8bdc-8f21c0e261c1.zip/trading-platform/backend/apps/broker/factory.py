"""Broker gateway factory & process-wide singleton.

Resolves the concrete adapter from ``settings.BROKER_ADAPTER`` and caches a
single connected instance per process. Dependency-injection friendly: callers
receive the abstract ``BrokerGateway``, never a concrete class.
"""
from __future__ import annotations

import threading

from django.conf import settings

from apps.broker.gateway import BrokerGateway
from apps.core.exceptions import BrokerError

_lock = threading.Lock()
_instance: BrokerGateway | None = None


def _build(adapter_name: str) -> BrokerGateway:
    if adapter_name == "simulated":
        from apps.broker.adapters.simulated import SimulatedBroker

        return SimulatedBroker()
    if adapter_name == "mt5":
        from apps.broker.adapters.mt5 import MT5Broker

        return MT5Broker()
    raise BrokerError(f"Unknown broker adapter: {adapter_name!r}")


def get_broker(*, connect: bool = True) -> BrokerGateway:
    """Return the process-wide broker gateway singleton."""
    global _instance
    with _lock:
        if _instance is None:
            _instance = _build(settings.BROKER_ADAPTER)
        if connect and not _instance.is_connected():
            _instance.connect()
        return _instance


def reset_broker() -> None:
    """Drop the cached instance (used by tests)."""
    global _instance
    with _lock:
        if _instance is not None:
            try:
                _instance.disconnect()
            except Exception:  # pragma: no cover - defensive
                pass
        _instance = None
