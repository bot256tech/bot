"""Broker abstraction layer.

Defines the ``BrokerGateway`` protocol that every broker adapter must implement,
together with the value objects exchanged across the boundary. The trading and
signal engines depend only on this abstraction, never on a concrete broker,
which keeps the domain independent of MetaTrader 5 (or any future broker).
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Protocol, runtime_checkable


class OrderSide(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"


@dataclass(frozen=True, slots=True)
class Quote:
    """A live bid/ask quote for a symbol."""

    symbol: str
    bid: Decimal
    ask: Decimal
    timestamp: float  # epoch seconds

    @property
    def spread(self) -> Decimal:
        return self.ask - self.bid


@dataclass(frozen=True, slots=True)
class SymbolInfo:
    """Complete, broker-reported specification for a tradable symbol.

    Every field is read from the broker (never hardcoded) so position sizing and
    execution adapt automatically to any instrument or account.
    """

    symbol: str
    digits: int
    point: Decimal
    contract_size: Decimal
    tick_size: Decimal
    tick_value: Decimal
    min_volume: Decimal
    max_volume: Decimal
    volume_step: Decimal
    spread_points: int
    trade_allowed: bool
    filling_modes: tuple[str, ...]
    currency_base: str
    currency_profit: str
    currency_margin: str
    # Broker margin model inputs.
    margin_initial: Decimal  # per lot; 0 => derive from leverage & contract size
    volume_min_step_ok: bool = True


@dataclass(frozen=True, slots=True)
class OrderRequest:
    symbol: str
    side: OrderSide
    volume: Decimal
    order_type: OrderType = OrderType.MARKET
    price: Decimal | None = None
    stop_loss: Decimal | None = None
    take_profit: Decimal | None = None
    comment: str = ""


@dataclass(frozen=True, slots=True)
class OrderResult:
    accepted: bool
    order_id: str | None
    filled_price: Decimal | None
    message: str


@dataclass(frozen=True, slots=True)
class Bar:
    """A single OHLC bar returned by the broker's history feed."""

    time: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal


@dataclass(frozen=True, slots=True)
class Position:
    ticket: str
    symbol: str
    side: OrderSide
    volume: Decimal
    open_price: Decimal
    current_price: Decimal
    profit: Decimal
    stop_loss: Decimal | None
    take_profit: Decimal | None


@dataclass(frozen=True, slots=True)
class AccountSummary:
    login: str
    balance: Decimal
    equity: Decimal
    margin: Decimal
    free_margin: Decimal
    margin_level: Decimal  # % (equity/margin*100); 0 when no open margin
    currency: str
    leverage: int
    connected: bool
    server: str = ""
    broker_name: str = ""
    trade_allowed: bool = True


@runtime_checkable
class BrokerGateway(Protocol):
    """Contract implemented by every broker adapter."""

    name: str

    def connect(self) -> bool: ...

    def disconnect(self) -> None: ...

    def is_connected(self) -> bool: ...

    def account_summary(self) -> AccountSummary: ...

    def symbol_info(self, symbol: str) -> SymbolInfo: ...

    def get_quote(self, symbol: str) -> Quote: ...

    def get_candles(self, symbol: str, timeframe: str, count: int) -> list[Bar]: ...

    def place_order(self, request: OrderRequest) -> OrderResult: ...

    def close_position(self, ticket: str, volume: Decimal | None = None) -> OrderResult: ...

    def modify_position(
        self,
        ticket: str,
        stop_loss: Decimal | None = None,
        take_profit: Decimal | None = None,
    ) -> OrderResult: ...

    def open_positions(self) -> list[Position]: ...
