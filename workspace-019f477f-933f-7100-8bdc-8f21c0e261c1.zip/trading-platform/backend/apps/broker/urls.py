"""Broker URL routes."""
from django.urls import path

from .views import (
    AccountSummaryView,
    OpenPositionsView,
    QuoteView,
    SymbolInfoView,
)

app_name = "broker"

urlpatterns = [
    path("account/", AccountSummaryView.as_view(), name="account"),
    path("quote/", QuoteView.as_view(), name="quote"),
    path("positions/", OpenPositionsView.as_view(), name="positions"),
    path("symbol/", SymbolInfoView.as_view(), name="symbol"),
]
