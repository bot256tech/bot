"""Broker API: account summary, quotes, and open positions."""
from __future__ import annotations

from dataclasses import asdict

from drf_spectacular.utils import (
    OpenApiParameter,
    OpenApiResponse,
    extend_schema,
    inline_serializer,
)
from rest_framework import permissions, serializers
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.broker.factory import get_broker

_AccountSerializer = inline_serializer(
    "AccountSummary",
    {
        "login": serializers.CharField(),
        "balance": serializers.CharField(),
        "equity": serializers.CharField(),
        "margin": serializers.CharField(),
        "free_margin": serializers.CharField(),
        "margin_level": serializers.CharField(),
        "currency": serializers.CharField(),
        "leverage": serializers.IntegerField(),
        "connected": serializers.BooleanField(),
        "server": serializers.CharField(),
        "broker_name": serializers.CharField(),
        "trade_allowed": serializers.BooleanField(),
    },
)
_QuoteSerializer = inline_serializer(
    "Quote",
    {
        "symbol": serializers.CharField(),
        "bid": serializers.CharField(),
        "ask": serializers.CharField(),
        "spread": serializers.CharField(),
        "timestamp": serializers.FloatField(),
    },
)
class _PositionSerializer(serializers.Serializer):
    ticket = serializers.CharField()
    symbol = serializers.CharField()
    side = serializers.CharField()
    volume = serializers.CharField()
    open_price = serializers.CharField()
    current_price = serializers.CharField()
    profit = serializers.CharField()
    stop_loss = serializers.CharField(allow_null=True)
    take_profit = serializers.CharField(allow_null=True)


def _serialize(obj) -> dict:
    """Convert a dataclass value object to JSON-safe primitives."""
    data = asdict(obj)
    return {k: (str(v) if hasattr(v, "quantize") else v) for k, v in data.items()}


@extend_schema(tags=["broker"], responses=_AccountSerializer)
class AccountSummaryView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        broker = get_broker()
        return Response(_serialize(broker.account_summary()))


@extend_schema(
    tags=["broker"],
    parameters=[OpenApiParameter("symbol", str, required=True)],
    responses=_QuoteSerializer,
)
class QuoteView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        symbol = request.query_params.get("symbol", "EURUSD")
        broker = get_broker()
        quote = _serialize(broker.get_quote(symbol))
        quote["spread"] = str(broker.get_quote(symbol).spread)
        return Response(quote)


@extend_schema(tags=["broker"], responses=OpenApiResponse(response=_PositionSerializer(many=True)))
class OpenPositionsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        broker = get_broker()
        return Response([_serialize(p) for p in broker.open_positions()])


_SymbolInfoSerializer = inline_serializer(
    "SymbolInfo",
    {
        "symbol": serializers.CharField(),
        "digits": serializers.IntegerField(),
        "point": serializers.CharField(),
        "contract_size": serializers.CharField(),
        "tick_size": serializers.CharField(),
        "tick_value": serializers.CharField(),
        "min_volume": serializers.CharField(),
        "max_volume": serializers.CharField(),
        "volume_step": serializers.CharField(),
        "spread_points": serializers.IntegerField(),
        "trade_allowed": serializers.BooleanField(),
        "filling_modes": serializers.ListField(child=serializers.CharField()),
        "currency_base": serializers.CharField(),
        "currency_profit": serializers.CharField(),
        "currency_margin": serializers.CharField(),
        "margin_initial": serializers.CharField(),
    },
)


@extend_schema(
    tags=["broker"],
    parameters=[OpenApiParameter("symbol", str, required=True)],
    description="Broker Intelligence: full broker-reported specification for a symbol.",
    responses=_SymbolInfoSerializer,
)
class SymbolInfoView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        symbol = request.query_params.get("symbol", "EURUSD")
        broker = get_broker()
        info = broker.symbol_info(symbol)
        data = _serialize(info)
        data["filling_modes"] = list(info.filling_modes)
        return Response(data)
