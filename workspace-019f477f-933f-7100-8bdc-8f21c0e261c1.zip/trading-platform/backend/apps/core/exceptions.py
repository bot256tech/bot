"""Centralised API exception handling.

Wraps DRF's default handler to produce a consistent error envelope and to log
unhandled exceptions to the error log.
"""
from __future__ import annotations

import logging

from rest_framework.response import Response
from rest_framework.views import exception_handler

logger = logging.getLogger("trading")


class DomainError(Exception):
    """Base class for domain/application layer errors surfaced to the API."""

    status_code = 400
    default_detail = "A domain error occurred."

    def __init__(self, detail: str | None = None, status_code: int | None = None):
        self.detail = detail or self.default_detail
        if status_code is not None:
            self.status_code = status_code
        super().__init__(self.detail)


class BrokerError(DomainError):
    default_detail = "Broker operation failed."
    status_code = 502


def api_exception_handler(exc, context):
    """Return a uniform ``{"error": {...}}`` envelope for all API errors."""
    if isinstance(exc, DomainError):
        logger.warning("Domain error: %s", exc.detail)
        return Response(
            {"error": {"detail": exc.detail, "type": exc.__class__.__name__}},
            status=exc.status_code,
        )

    response = exception_handler(exc, context)
    if response is not None:
        response.data = {
            "error": {
                "detail": response.data,
                "type": exc.__class__.__name__,
            }
        }
        return response

    # Truly unhandled -> log with stack trace and return generic 500.
    logger.exception("Unhandled server error", exc_info=exc)
    return Response(
        {"error": {"detail": "Internal server error.", "type": "ServerError"}},
        status=500,
    )
