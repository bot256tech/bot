"""Health-check endpoints for monitoring, NSSM and load-balancer probes.

    GET /api/v1/health/        Liveness  - process is up (always 200 if serving)
    GET /api/v1/health/ready/  Readiness - DB + Redis + broker reachable
"""
from __future__ import annotations

from django.db import connection
from drf_spectacular.utils import extend_schema, inline_serializer
from rest_framework import permissions, serializers
from rest_framework.response import Response
from rest_framework.views import APIView

_HealthSerializer = inline_serializer(
    "Health",
    {
        "status": serializers.CharField(),
        "checks": serializers.DictField(),
    },
)


@extend_schema(tags=["system"], responses=_HealthSerializer, auth=[])
class LivenessView(APIView):
    """Liveness probe - returns 200 whenever the process can serve requests."""

    permission_classes = [permissions.AllowAny]
    authentication_classes: list = []

    def get(self, request):
        return Response({"status": "ok", "checks": {"process": True}})


@extend_schema(tags=["system"], responses=_HealthSerializer, auth=[])
class ReadinessView(APIView):
    """Readiness probe - verifies critical dependencies are reachable."""

    permission_classes = [permissions.AllowAny]
    authentication_classes: list = []

    def get(self, request):
        checks: dict[str, bool] = {}

        # Database
        try:
            with connection.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            checks["database"] = True
        except Exception:
            checks["database"] = False

        # Redis (best-effort; only marked failed if configured and unreachable)
        try:
            import redis
            from decouple import config

            url = config("REDIS_URL", default="")
            if url:
                redis.Redis.from_url(url, socket_connect_timeout=2).ping()
                checks["redis"] = True
            else:
                checks["redis"] = None  # not configured -> not required
        except Exception:
            checks["redis"] = False

        # Broker gateway
        try:
            from apps.broker.factory import get_broker

            checks["broker"] = get_broker().is_connected()
        except Exception:
            checks["broker"] = False

        required = [v for k, v in checks.items() if v is not None]
        ok = all(required)
        return Response(
            {"status": "ready" if ok else "degraded", "checks": checks},
            status=200 if ok else 503,
        )
