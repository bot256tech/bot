"""Role definitions and DRF permission classes for role-based access control.

Roles are stored on the User model as a single string field. A simple
hierarchy lets higher roles inherit the capabilities of lower ones where
that makes sense (e.g. SUPER_ADMIN implies ADMIN).
"""
from __future__ import annotations

from django.db import models
from rest_framework.permissions import BasePermission


class Role(models.TextChoices):
    SUPER_ADMIN = "super_admin", "Super Admin"
    ADMIN = "admin", "Admin"
    DEVELOPER = "developer", "Developer"
    ANALYST = "analyst", "Analyst"
    MODERATOR = "moderator", "Moderator"
    TRADER = "trader", "Trader"
    SUBSCRIBER = "subscriber", "Subscriber"


# Roles that have full administrative authority over the platform.
ADMIN_ROLES = frozenset({Role.SUPER_ADMIN, Role.ADMIN})

# Roles allowed to create/modify signals.
SIGNAL_AUTHOR_ROLES = frozenset(
    {Role.SUPER_ADMIN, Role.ADMIN, Role.ANALYST, Role.TRADER}
)


class HasRole(BasePermission):
    """Generic permission factory: `HasRole.of(Role.ADMIN, Role.ANALYST)`."""

    required_roles: frozenset[str] = frozenset()

    @classmethod
    def of(cls, *roles: str) -> type["HasRole"]:
        return type(
            "HasRoleSpecific",
            (cls,),
            {"required_roles": frozenset(roles)},
        )

    def has_permission(self, request, view) -> bool:
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if user.role == Role.SUPER_ADMIN:
            return True
        return user.role in self.required_roles


class IsAdmin(BasePermission):
    def has_permission(self, request, view) -> bool:
        user = request.user
        return bool(user and user.is_authenticated and user.role in ADMIN_ROLES)


class IsSignalAuthor(BasePermission):
    """Write access to signals; read access is open to any authenticated user."""

    def has_permission(self, request, view) -> bool:
        if request.method in ("GET", "HEAD", "OPTIONS"):
            return bool(request.user and request.user.is_authenticated)
        user = request.user
        return bool(
            user and user.is_authenticated and user.role in SIGNAL_AUTHOR_ROLES
        )
