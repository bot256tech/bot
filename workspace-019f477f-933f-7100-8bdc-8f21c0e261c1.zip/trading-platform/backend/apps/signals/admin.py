"""Admin registration for signals."""
from django.contrib import admin

from .models import Signal


@admin.register(Signal)
class SignalAdmin(admin.ModelAdmin):
    list_display = (
        "symbol",
        "direction",
        "status",
        "entry_price",
        "stop_loss",
        "take_profit",
        "confidence",
        "strategy",
        "created_at",
    )
    list_filter = ("status", "direction", "strategy")
    search_fields = ("symbol", "strategy", "rationale")
    readonly_fields = ("id", "created_at", "updated_at", "published_at", "closed_at")
    date_hierarchy = "created_at"
