"""WebSocket consumer for realtime signal delivery.

Clients connect to ``ws://host/ws/signals/?token=<access_jwt>``. Only
authenticated users may subscribe. The consumer joins the ``signals`` group;
the service layer broadcasts create/update/close events to that group.
"""
from __future__ import annotations

from channels.generic.websocket import AsyncJsonWebsocketConsumer

from .services import SIGNAL_GROUP


class SignalConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self) -> None:
        user = self.scope.get("user")
        if not user or not getattr(user, "is_authenticated", False):
            await self.close(code=4401)  # unauthorized
            return
        await self.channel_layer.group_add(SIGNAL_GROUP, self.channel_name)
        await self.accept()
        await self.send_json({"event": "connection.ready", "data": {"group": SIGNAL_GROUP}})

    async def disconnect(self, code: int) -> None:
        await self.channel_layer.group_discard(SIGNAL_GROUP, self.channel_name)

    async def signal_message(self, message: dict) -> None:
        """Handler for group_send messages of type ``signal_message``."""
        await self.send_json({"event": message["event"], "data": message["data"]})
