"""Signal domain models.

A ``Signal`` is a tradeable recommendation for a symbol with entry, stop-loss
and take-profit levels, a direction and a lifecycle status. Signals are the
core artefact of the platform's signal-generation feature.
"""
from __future__ import annotations

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models

from apps.core.models import BaseModel


class SignalDirection(models.TextChoices):
    BUY = "buy", "Buy"
    SELL = "sell", "Sell"


class SignalStatus(models.TextChoices):
    PENDING = "pending", "Pending"  # generated, not yet active
    ACTIVE = "active", "Active"  # live / awaiting outcome
    HIT_TP = "hit_tp", "Take Profit Hit"
    HIT_SL = "hit_sl", "Stop Loss Hit"
    EXPIRED = "expired", "Expired"
    CANCELLED = "cancelled", "Cancelled"


class Signal(BaseModel):
    """A trading signal."""

    symbol = models.CharField(max_length=20, db_index=True)
    direction = models.CharField(max_length=4, choices=SignalDirection.choices)
    status = models.CharField(
        max_length=12,
        choices=SignalStatus.choices,
        default=SignalStatus.PENDING,
        db_index=True,
    )

    entry_price = models.DecimalField(
        max_digits=18, decimal_places=6, validators=[MinValueValidator(0)]
    )
    stop_loss = models.DecimalField(max_digits=18, decimal_places=6)
    take_profit = models.DecimalField(max_digits=18, decimal_places=6)

    confidence = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0,
        help_text="Model/analyst confidence 0-100.",
    )
    strategy = models.CharField(max_length=64, blank=True, db_index=True)
    rationale = models.TextField(blank=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="signals",
    )
    published_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta(BaseModel.Meta):
        indexes = [
            models.Index(fields=["symbol", "status"]),
            models.Index(fields=["strategy", "status"]),
        ]

    def __str__(self) -> str:
        return f"{self.direction.upper()} {self.symbol} @ {self.entry_price} [{self.status}]"

    @property
    def risk_reward(self):
        """Reward-to-risk ratio based on entry/SL/TP."""
        risk = abs(self.entry_price - self.stop_loss)
        reward = abs(self.take_profit - self.entry_price)
        if risk == 0:
            return None
        return round(reward / risk, 2)
