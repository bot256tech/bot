"""Serializers for the signals domain."""
from __future__ import annotations

from rest_framework import serializers

from .models import Signal, SignalDirection


class SignalSerializer(serializers.ModelSerializer):
    risk_reward = serializers.SerializerMethodField()
    created_by_email = serializers.EmailField(
        source="created_by.email", read_only=True, default=None
    )

    class Meta:
        model = Signal
        fields = (
            "id",
            "symbol",
            "direction",
            "status",
            "entry_price",
            "stop_loss",
            "take_profit",
            "confidence",
            "strategy",
            "rationale",
            "risk_reward",
            "created_by_email",
            "published_at",
            "closed_at",
            "created_at",
            "updated_at",
        )
        read_only_fields = (
            "id",
            "status",
            "risk_reward",
            "created_by_email",
            "published_at",
            "closed_at",
            "created_at",
            "updated_at",
        )

    def get_risk_reward(self, obj: Signal) -> str | None:
        rr = obj.risk_reward
        return str(rr) if rr is not None else None

    def validate(self, attrs):
        direction = attrs.get("direction")
        entry = attrs.get("entry_price")
        sl = attrs.get("stop_loss")
        tp = attrs.get("take_profit")
        if None in (direction, entry, sl, tp):
            return attrs
        if direction == SignalDirection.BUY:
            if not (sl < entry < tp):
                raise serializers.ValidationError(
                    "For a BUY signal: stop_loss < entry_price < take_profit."
                )
        else:
            if not (tp < entry < sl):
                raise serializers.ValidationError(
                    "For a SELL signal: take_profit < entry_price < stop_loss."
                )
        return attrs
