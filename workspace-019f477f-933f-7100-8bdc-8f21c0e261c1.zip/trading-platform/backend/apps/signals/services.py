"""Signal domain/application services.

Encapsulates the business logic for generating signals from live market data,
publishing them, evaluating open signals against current prices, and
broadcasting changes over WebSockets. Views and tasks call into this layer;
they contain no business logic themselves (thin controllers).
"""
from __future__ import annotations

import logging
from decimal import Decimal

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.utils import timezone

from apps.broker.factory import get_broker
from apps.broker.gateway import BrokerGateway

from .models import Signal, SignalDirection, SignalStatus
from .serializers import SignalSerializer

logger = logging.getLogger("trading")

SIGNAL_GROUP = "signals"


def broadcast_signal(signal: Signal, event: str = "signal.update") -> None:
    """Push a signal change to all connected WebSocket clients."""
    layer = get_channel_layer()
    if layer is None:  # pragma: no cover - only if channels misconfigured
        return
    payload = SignalSerializer(signal).data
    async_to_sync(layer.group_send)(
        SIGNAL_GROUP,
        {"type": "signal_message", "event": event, "data": payload},
    )


def publish_signal(signal: Signal) -> Signal:
    """Transition a pending signal to active and broadcast it."""
    signal.status = SignalStatus.ACTIVE
    signal.published_at = timezone.now()
    signal.save(update_fields=["status", "published_at", "updated_at"])
    logger.info("Signal published: %s", signal)
    broadcast_signal(signal, event="signal.created")
    # Fan out to Telegram subscribers (best-effort; never blocks publishing).
    try:
        from apps.telegram_bot.services import broadcast_signal as tg_broadcast

        tg_broadcast(signal)
    except Exception:  # pragma: no cover - defensive
        logger.exception("Telegram signal broadcast failed")
    return signal


def generate_signal_from_market(
    symbol: str,
    *,
    strategy: str = "momentum",
    rr_ratio: Decimal = Decimal("2.0"),
    risk_fraction: Decimal = Decimal("0.002"),
    broker: BrokerGateway | None = None,
    created_by=None,
) -> Signal:
    """Generate a signal from a live quote using a simple momentum rule.

    The rule is intentionally transparent and deterministic given the price
    feed: direction is chosen from the mid vs. ask/bid skew, the stop is placed
    a ``risk_fraction`` away from entry, and the target at ``rr_ratio`` times
    the risk. This is a real, working generator that can be swapped for an
    AI/ML model later without changing any caller.
    """
    broker = broker or get_broker()
    quote = broker.get_quote(symbol)
    mid = (quote.bid + quote.ask) / 2

    # Momentum proxy: if ask-side pressure, go long; else short.
    direction = (
        SignalDirection.BUY if quote.ask - mid <= mid - quote.bid else SignalDirection.SELL
    )
    entry = quote.ask if direction == SignalDirection.BUY else quote.bid
    risk = (mid * risk_fraction).quantize(Decimal("0.000001"))

    if direction == SignalDirection.BUY:
        stop_loss = entry - risk
        take_profit = entry + risk * rr_ratio
    else:
        stop_loss = entry + risk
        take_profit = entry - risk * rr_ratio

    signal = Signal.objects.create(
        symbol=symbol,
        direction=direction,
        entry_price=entry.quantize(Decimal("0.000001")),
        stop_loss=stop_loss.quantize(Decimal("0.000001")),
        take_profit=take_profit.quantize(Decimal("0.000001")),
        confidence=Decimal("60.00"),
        strategy=strategy,
        rationale=f"Auto-generated {strategy} signal from live {symbol} quote.",
        created_by=created_by,
    )
    return publish_signal(signal)


def evaluate_active_signals(broker: BrokerGateway | None = None) -> int:
    """Check active signals against current prices; close TP/SL hits.

    Returns the number of signals whose status changed.
    """
    broker = broker or get_broker()
    changed = 0
    active = Signal.objects.filter(status=SignalStatus.ACTIVE)
    # Cache quotes per symbol to avoid redundant calls.
    quote_cache: dict[str, Decimal] = {}

    # Auto-expire: signals older than SETUP_EXPIRY_MINUTES that never hit TP/SL.
    from datetime import timedelta

    from decouple import config

    expiry_minutes = config("SETUP_EXPIRY_MINUTES", default=480, cast=int)
    cutoff = timezone.now() - timedelta(minutes=expiry_minutes)

    for signal in active:
        # Expire stale signals first (based on when they were published).
        published = signal.published_at or signal.created_at
        if published and published < cutoff:
            signal.status = SignalStatus.EXPIRED
            signal.closed_at = timezone.now()
            signal.save(update_fields=["status", "closed_at", "updated_at"])
            broadcast_signal(signal, event="signal.closed")
            changed += 1
            continue

        if signal.symbol not in quote_cache:
            try:
                q = broker.get_quote(signal.symbol)
                quote_cache[signal.symbol] = (q.bid + q.ask) / 2
            except Exception:
                continue  # skip symbols with no quote this cycle
        price = quote_cache[signal.symbol]

        new_status: str | None = None
        if signal.direction == SignalDirection.BUY:
            if price >= signal.take_profit:
                new_status = SignalStatus.HIT_TP
            elif price <= signal.stop_loss:
                new_status = SignalStatus.HIT_SL
        else:
            if price <= signal.take_profit:
                new_status = SignalStatus.HIT_TP
            elif price >= signal.stop_loss:
                new_status = SignalStatus.HIT_SL

        if new_status:
            signal.status = new_status
            signal.closed_at = timezone.now()
            signal.save(update_fields=["status", "closed_at", "updated_at"])
            broadcast_signal(signal, event="signal.closed")
            changed += 1
            logger.info("Signal %s -> %s at price %s", signal.id, new_status, price)

    return changed


def generate_signal_from_engines(
    symbol: str,
    *,
    timeframe: str = "M15",
    rr_ratio: Decimal = Decimal("2.0"),
    broker: BrokerGateway | None = None,
    created_by=None,
    min_score: Decimal = Decimal("0"),
) -> Signal | None:
    """Generate a signal using the REAL 8-engine score (not naive momentum).

    - Confidence = the actual composite score (0-100), not a hardcoded 60.
    - Direction = the engines' aligned bias.
    - Entry/SL/TP anchored on the CRT range when available, else the live quote.
    Returns None if the setup does not clear ``min_score`` or has no bias.
    """
    from apps.trading.engines.base import Candle
    from apps.trading.engines.scoring import ScoringEngine
    from apps.trading.services import _candles  # reuse the resampling-aware loader

    broker = broker or get_broker()
    candles = _candles(broker, symbol, timeframe, 200)
    # Signals use the strict core gate (CRT+Liquidity+KOD+CISD required).
    scored = ScoringEngine().score(candles, require_core=True)
    score = Decimal(str(scored["score"]))
    bias = scored["bias"]

    if bias == "neutral" or not scored.get("core_ok") or score < min_score:
        return None

    quote = broker.get_quote(symbol)
    direction = SignalDirection.BUY if bias == "bullish" else SignalDirection.SELL
    entry = quote.ask if direction == SignalDirection.BUY else quote.bid

    # Prefer the CRT range for SL/TP; fall back to a volatility-based stop.
    crt = next((b for b in scored["breakdown"] if b["engine"] == "crt"), {})
    d = crt.get("details", {}) if crt else {}
    crt_high = Decimal(str(d["crt_high"])) if d.get("crt_high") not in (None, "None") else None
    crt_low = Decimal(str(d["crt_low"])) if d.get("crt_low") not in (None, "None") else None

    if direction == SignalDirection.BUY:
        stop_loss = crt_low if crt_low and crt_low < entry else entry * Decimal("0.998")
        take_profit = entry + (entry - stop_loss) * rr_ratio
    else:
        stop_loss = crt_high if crt_high and crt_high > entry else entry * Decimal("1.002")
        take_profit = entry - (stop_loss - entry) * rr_ratio

    q = Decimal("0.000001")
    signal = Signal.objects.create(
        symbol=symbol,
        direction=direction,
        entry_price=entry.quantize(q),
        stop_loss=stop_loss.quantize(q),
        take_profit=take_profit.quantize(q),
        confidence=score,  # REAL score, not hardcoded
        strategy="8-engine",
        rationale=(
            f"{bias.upper()} setup on {symbol} {timeframe}. Score {score} "
            f"(alignment {scored.get('alignment')}). Engines: "
            + ", ".join(
                f"{b['engine']}={b['score']}" for b in scored["breakdown"] if b["detected"]
            )
        ),
        created_by=created_by,
    )
    return publish_signal(signal)


def cleanup_signals(*, statuses: list[str] | None = None) -> int:
    """Soft-delete finished signals (expired/cancelled/closed) to declutter.

    Returns the number removed. Active/pending signals are never touched.
    """
    statuses = statuses or [
        SignalStatus.EXPIRED, SignalStatus.CANCELLED,
        SignalStatus.HIT_TP, SignalStatus.HIT_SL,
    ]
    qs = Signal.objects.filter(status__in=statuses)
    count = qs.count()
    for sig in qs:
        sig.delete()  # soft delete (BaseModel)
    logger.info("Cleaned up %d finished signals", count)
    return count
