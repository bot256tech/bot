"""Celery tasks for autonomous signal generation and evaluation.

Register these on a beat schedule in production (see deployment guide) so the
platform continuously monitors the market and updates signal outcomes.
"""
from __future__ import annotations

import logging

from celery import shared_task

from . import services

logger = logging.getLogger("trading")


@shared_task(name="signals.generate", bind=True, max_retries=3, default_retry_delay=10)
def generate_signal_task(self, symbol: str, strategy: str = "momentum"):
    """Generate a single signal from live market data."""
    try:
        signal = services.generate_signal_from_market(symbol, strategy=strategy)
        return str(signal.id)
    except Exception as exc:  # pragma: no cover - retried
        logger.exception("Signal generation failed for %s", symbol)
        raise self.retry(exc=exc)


@shared_task(name="signals.evaluate")
def evaluate_signals_task() -> int:
    """Evaluate all active signals against current prices."""
    return services.evaluate_active_signals()
