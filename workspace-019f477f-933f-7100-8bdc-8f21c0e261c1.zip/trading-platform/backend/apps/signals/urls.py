"""Signal URL routes."""
from rest_framework.routers import DefaultRouter

from .views import SignalViewSet

app_name = "signals"

router = DefaultRouter()
router.register("", SignalViewSet, basename="signal")

urlpatterns = router.urls
