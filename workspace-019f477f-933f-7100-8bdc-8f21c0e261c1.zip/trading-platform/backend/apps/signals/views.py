"""Signal API views (thin controllers over the service layer)."""
from __future__ import annotations

from drf_spectacular.utils import OpenApiExample, extend_schema
from rest_framework import filters, viewsets
from rest_framework.decorators import action
from rest_framework.request import Request
from rest_framework.response import Response

from apps.core.roles import IsSignalAuthor

from . import services
from .models import Signal, SignalStatus
from .serializers import SignalSerializer


@extend_schema(tags=["signals"])
class SignalViewSet(viewsets.ModelViewSet):
    """CRUD + generation for trading signals.

    - Read access: any authenticated user.
    - Write access: analysts, traders and admins (see ``IsSignalAuthor``).
    """

    serializer_class = SignalSerializer
    permission_classes = [IsSignalAuthor]
    filter_backends = [filters.OrderingFilter, filters.SearchFilter]
    search_fields = ["symbol", "strategy"]
    ordering_fields = ["created_at", "confidence", "symbol"]

    def get_queryset(self):
        qs = Signal.objects.all()
        status_param = self.request.query_params.get("status")
        symbol = self.request.query_params.get("symbol")
        if status_param:
            qs = qs.filter(status=status_param)
        if symbol:
            qs = qs.filter(symbol=symbol)
        return qs

    def perform_create(self, serializer):
        signal = serializer.save(created_by=self.request.user)
        services.publish_signal(signal)

    @extend_schema(
        request={
            "application/json": {
                "type": "object",
                "properties": {
                    "symbol": {"type": "string"},
                    "strategy": {"type": "string"},
                },
                "required": ["symbol"],
            }
        },
        examples=[OpenApiExample("Generate EURUSD", value={"symbol": "EURUSD"})],
    )
    @action(detail=False, methods=["post"], url_path="generate")
    def generate(self, request: Request) -> Response:
        """Generate a signal from live market data using the REAL 8-engine score."""
        symbol = str(request.data.get("symbol", ""))
        timeframe = str(request.data.get("timeframe", "M15"))
        if not symbol:
            return Response({"error": {"detail": "symbol is required."}}, status=400)
        # Use the engine-based generator (real score/bias/confidence). Falls back
        # to the momentum generator only if the engines produce no directional
        # setup, so the button always returns something.
        signal = services.generate_signal_from_engines(
            symbol, timeframe=timeframe, created_by=request.user
        )
        if signal is None:
            signal = services.generate_signal_from_market(
                symbol, strategy="momentum", created_by=request.user
            )
        return Response(SignalSerializer(signal).data, status=201)

    @action(detail=True, methods=["post"], url_path="cancel")
    def cancel(self, request: Request, pk=None) -> Response:
        """Cancel an active/pending signal (manual remove)."""
        signal = self.get_object()
        signal.status = SignalStatus.CANCELLED
        signal.save(update_fields=["status", "updated_at"])
        services.broadcast_signal(signal, event="signal.closed")
        return Response(SignalSerializer(signal).data)

    @action(detail=False, methods=["post"], url_path="cleanup")
    def cleanup(self, request: Request) -> Response:
        """Remove all finished (expired/cancelled/closed) signals to declutter."""
        removed = services.cleanup_signals()
        return Response({"removed": removed})
