"""Admin registration for Telegram subscribers."""
from django.contrib import admin

from .models import TelegramSubscriber


@admin.register(TelegramSubscriber)
class TelegramSubscriberAdmin(admin.ModelAdmin):
    list_display = ("chat_id", "user", "username", "is_verified",
                    "receive_signals", "receive_trades", "created_at")
    list_filter = ("is_verified", "receive_signals", "receive_trades")
    search_fields = ("chat_id", "username", "user__email")
