"""Minimal Telegram Bot API client (stdlib only, no third-party deps).

Sends messages via the Bot API. Network calls are isolated here so they can be
mocked in tests and the rest of the platform depends only on ``send_message``.
"""
from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request

from decouple import config

logger = logging.getLogger("trading")

_API = "https://api.telegram.org/bot{token}/{method}"


def _token() -> str:
    return config("TELEGRAM_BOT_TOKEN", default="")


def is_configured() -> bool:
    return bool(_token())


def call(method: str, payload: dict, timeout: int = 10) -> dict:
    """Call a Bot API method. Returns the parsed response ``result`` or raises."""
    token = _token()
    if not token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is not configured.")
    url = _API.format(token=token, method=method)
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode())
    except urllib.error.URLError as exc:  # pragma: no cover - network dependent
        logger.error("Telegram API error (%s): %s", method, exc)
        raise
    if not body.get("ok"):
        raise RuntimeError(f"Telegram API returned error: {body}")
    return body.get("result", {})


def send_message(chat_id: str, text: str, parse_mode: str = "HTML") -> dict:
    """Send a text message to a chat."""
    return call(
        "sendMessage",
        {"chat_id": chat_id, "text": text, "parse_mode": parse_mode,
         "disable_web_page_preview": True},
    )
