"""Telegram integration models."""
from __future__ import annotations

import secrets

from django.conf import settings
from django.db import models

from apps.core.models import BaseModel


class TelegramSubscriber(BaseModel):
    """A Telegram chat linked to a platform user for notifications."""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="telegram_subscribers",
    )
    chat_id = models.CharField(max_length=64, db_index=True)
    username = models.CharField(max_length=128, blank=True)

    # Notification preferences.
    receive_signals = models.BooleanField(default=True)
    receive_trades = models.BooleanField(default=True)
    receive_errors = models.BooleanField(default=False)

    is_verified = models.BooleanField(default=False)
    verification_code = models.CharField(max_length=12, blank=True, db_index=True)

    class Meta(BaseModel.Meta):
        constraints = [
            models.UniqueConstraint(
                fields=["user", "chat_id"], name="uniq_user_chat"
            )
        ]

    def __str__(self) -> str:
        return f"TG:{self.chat_id} -> {self.user_id}"

    @staticmethod
    def new_code() -> str:
        return secrets.token_hex(4)
