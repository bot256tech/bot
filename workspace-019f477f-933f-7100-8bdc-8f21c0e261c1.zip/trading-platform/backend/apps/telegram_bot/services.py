"""Telegram delivery services: linking, verification, and broadcasts."""
from __future__ import annotations

import logging

from . import client
from .models import TelegramSubscriber

logger = logging.getLogger("trading")


def start_link(user) -> TelegramSubscriber:
    """Create an unverified subscriber record and return the verification code.

    The user sends ``/verify <code>`` to the bot; the webhook confirms it and
    fills in the real chat_id (see ``confirm_link``).
    """
    code = TelegramSubscriber.new_code()
    sub = TelegramSubscriber.objects.create(
        user=user, chat_id=f"pending-{code}", verification_code=code,
        is_verified=False,
    )
    return sub


def confirm_link(code: str, chat_id: str, username: str = "") -> bool:
    """Confirm a pending link from an incoming ``/verify`` command."""
    try:
        sub = TelegramSubscriber.objects.get(verification_code=code, is_verified=False)
    except TelegramSubscriber.DoesNotExist:
        return False
    sub.chat_id = str(chat_id)
    sub.username = username
    sub.is_verified = True
    sub.verification_code = ""
    sub.save(update_fields=["chat_id", "username", "is_verified",
                            "verification_code", "updated_at"])
    if client.is_configured():
        try:
            client.send_message(chat_id, "✅ Your account is now linked.")
        except Exception:  # pragma: no cover - network
            logger.exception("Failed to send link confirmation")
    return True


def _broadcast(text: str, pref_field: str) -> int:
    """Send ``text`` to all verified subscribers opted-in to ``pref_field``."""
    if not client.is_configured():
        logger.info("Telegram not configured; skipping broadcast.")
        return 0
    subs = TelegramSubscriber.objects.filter(is_verified=True, **{pref_field: True})
    sent = 0
    for sub in subs:
        try:
            client.send_message(sub.chat_id, text)
            sent += 1
        except Exception:  # pragma: no cover - network
            logger.exception("Failed to send to chat %s", sub.chat_id)
    return sent


def broadcast_signal(signal) -> int:
    rr = signal.risk_reward
    text = (
        f"📡 <b>New Signal</b>\n"
        f"<b>{signal.direction.upper()} {signal.symbol}</b>\n"
        f"Entry: <code>{signal.entry_price}</code>\n"
        f"SL: <code>{signal.stop_loss}</code>\n"
        f"TP: <code>{signal.take_profit}</code>\n"
        f"R:R: {rr if rr is not None else '—'} · "
        f"Confidence: {signal.confidence}%\n"
        f"Strategy: {signal.strategy or 'n/a'}"
    )
    return _broadcast(text, "receive_signals")


def broadcast_trade(trade) -> int:
    text = (
        f"💹 <b>Trade {trade.status.upper()}</b>\n"
        f"{trade.side.upper()} {trade.symbol} · {trade.volume} lots\n"
        f"Entry: <code>{trade.entry_price}</code> · Score: {trade.score}"
    )
    return _broadcast(text, "receive_trades")


def broadcast_error(message: str) -> int:
    return _broadcast(f"⚠️ <b>System Alert</b>\n{message}", "receive_errors")


# --------------------------------------------------------------------------- #
# Prop-guard alerts (throttled to avoid spamming the channel)
# --------------------------------------------------------------------------- #
def broadcast_prop_guard(tier: str, reasons: list[str], checks: dict) -> int:
    """Send a prop-guard alert, throttled per tier so the channel isn't spammed.

    Respects the per-alert env toggles and suppresses duplicate alerts within a
    time window (see ``telegram_bot.throttle``). Returns the number of chats the
    message was actually delivered to (0 if throttled or disabled).
    """
    from decouple import config

    from . import throttle

    tier = tier.upper()
    if tier == "OK":
        return 0

    # Per-alert toggles from the environment.
    if tier == "WARNING" and not config("TELEGRAM_RISK_ALERTS_ENABLED", default=True, cast=bool):
        return 0
    if tier in ("SOFT_STOP", "HARD_STOP") and not config(
        "TELEGRAM_RISK_ALERTS_ENABLED", default=True, cast=bool
    ):
        return 0

    category = {
        "WARNING": "prop_warning",
        "SOFT_STOP": "prop_soft_stop",
        "HARD_STOP": "prop_hard_stop",
    }.get(tier, "error")

    # Fingerprint: same tier + same primary reason within the window = suppressed.
    primary = reasons[0] if reasons else tier
    key = f"propguard:{tier}:{primary[:48]}"
    if not throttle.allow(key, category=category):
        logger.info("Prop-guard %s alert throttled (anti-spam): %s", tier, primary)
        return 0

    icon = {"WARNING": "🟡", "SOFT_STOP": "🟠", "HARD_STOP": "🔴"}.get(tier, "⚠️")
    body = "\n".join(f"• {r}" for r in reasons) or "See dashboard."
    text = (
        f"{icon} <b>Prop Guard: {tier.replace('_', ' ')}</b>\n"
        f"{body}\n"
        f"Daily loss: {checks.get('daily_loss_percent', '?')}% · "
        f"Drawdown: {checks.get('max_drawdown_percent', '?')}%"
    )
    return _broadcast(text, "receive_errors")
