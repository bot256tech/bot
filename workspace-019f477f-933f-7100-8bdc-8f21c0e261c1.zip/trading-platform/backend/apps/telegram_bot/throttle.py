"""Anti-spam throttle for Telegram broadcasts.

Prevents flooding the channel with repeated prop-guard warnings / soft-stops
(and any other high-frequency alert). An alert identified by ``key`` is only
allowed through once per ``ttl`` seconds. Uses Redis when configured so the
throttle is shared across worker processes; otherwise falls back to an
in-process cache (fine for a single-process deployment).
"""
from __future__ import annotations

import threading
import time

from decouple import config

# Default suppression windows (seconds) per alert category.
DEFAULT_TTL = {
    "prop_warning": config("TELEGRAM_THROTTLE_WARNING_SEC", default=1800, cast=int),
    "prop_soft_stop": config("TELEGRAM_THROTTLE_SOFT_STOP_SEC", default=900, cast=int),
    "prop_hard_stop": config("TELEGRAM_THROTTLE_HARD_STOP_SEC", default=900, cast=int),
    "error": config("TELEGRAM_THROTTLE_ERROR_SEC", default=300, cast=int),
}

_lock = threading.Lock()
_local_cache: dict[str, float] = {}


def _redis():
    try:
        import redis  # type: ignore

        url = config("REDIS_URL", default="")
        if not url:
            return None
        return redis.Redis.from_url(url)
    except Exception:  # pragma: no cover - redis optional
        return None


def allow(key: str, *, ttl: int | None = None, category: str = "error") -> bool:
    """Return True if this alert may be sent now, and mark it as sent.

    Subsequent calls with the same ``key`` return False until ``ttl`` elapses.
    """
    window = ttl if ttl is not None else DEFAULT_TTL.get(category, 300)
    if window <= 0:
        return True

    client = _redis()
    if client is not None:
        try:
            # SET key NX EX ttl -> True only if the key did not already exist.
            return bool(client.set(f"tg:throttle:{key}", "1", nx=True, ex=window))
        except Exception:  # pragma: no cover - fall back on any redis error
            pass

    now = time.time()
    with _lock:
        # Opportunistic cleanup to keep the local cache bounded.
        if len(_local_cache) > 512:
            for k in [k for k, exp in _local_cache.items() if exp <= now]:
                _local_cache.pop(k, None)
        exp = _local_cache.get(key)
        if exp is not None and exp > now:
            return False
        _local_cache[key] = now + window
        return True


def reset() -> None:
    """Clear the in-process cache (tests)."""
    with _lock:
        _local_cache.clear()
