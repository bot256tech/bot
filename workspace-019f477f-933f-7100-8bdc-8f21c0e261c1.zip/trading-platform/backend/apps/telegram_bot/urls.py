"""Telegram URL routes."""
from django.urls import path

from .views import LinkView, PreferencesView, SubscribersView, WebhookView

app_name = "telegram"

urlpatterns = [
    path("link/", LinkView.as_view(), name="link"),
    path("subscribers/", SubscribersView.as_view(), name="subscribers"),
    path("subscribers/<uuid:pk>/", PreferencesView.as_view(), name="preferences"),
    path("webhook/<str:secret>/", WebhookView.as_view(), name="webhook"),
]
