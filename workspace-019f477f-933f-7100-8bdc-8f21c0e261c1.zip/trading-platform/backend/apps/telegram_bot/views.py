"""Telegram API: linking, preferences, and inbound webhook."""
from __future__ import annotations

from drf_spectacular.utils import extend_schema, inline_serializer
from rest_framework import permissions, serializers
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services
from .models import TelegramSubscriber


class SubscriberSerializer(serializers.ModelSerializer):
    class Meta:
        model = TelegramSubscriber
        fields = ("id", "chat_id", "username", "receive_signals",
                  "receive_trades", "receive_errors", "is_verified", "created_at")
        read_only_fields = ("id", "chat_id", "username", "is_verified", "created_at")


@extend_schema(
    tags=["telegram"],
    request=None,
    responses=inline_serializer("TelegramLink", {
        "verification_code": serializers.CharField(),
        "instructions": serializers.CharField(),
    }),
)
class LinkView(APIView):
    """Begin linking: returns a code to send to the bot as ``/verify <code>``."""

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        sub = services.start_link(request.user)
        return Response({
            "verification_code": sub.verification_code,
            "instructions": f"Open the bot in Telegram and send: /verify {sub.verification_code}",
        }, status=201)


@extend_schema(tags=["telegram"], responses=SubscriberSerializer(many=True))
class SubscribersView(APIView):
    """List and update the current user's Telegram subscriptions."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        subs = TelegramSubscriber.objects.filter(user=request.user)
        return Response(SubscriberSerializer(subs, many=True).data)


@extend_schema(tags=["telegram"], request=SubscriberSerializer, responses=SubscriberSerializer)
class PreferencesView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        sub = TelegramSubscriber.objects.get(id=pk, user=request.user)
        s = SubscriberSerializer(sub, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response(s.data)


@extend_schema(tags=["telegram"], request=None, responses=None)
class WebhookView(APIView):
    """Inbound Telegram webhook. Handles the ``/verify <code>`` command.

    Configure with setWebhook pointing here; secured by a URL secret path token
    (TELEGRAM_WEBHOOK_SECRET) checked against the ``secret`` kwarg.
    """

    permission_classes = [permissions.AllowAny]
    authentication_classes: list = []

    def post(self, request, secret=None):
        from decouple import config

        expected = config("TELEGRAM_WEBHOOK_SECRET", default="")
        if expected and secret != expected:
            return Response({"error": {"detail": "Invalid webhook secret."}}, status=403)

        message = request.data.get("message", {}) or {}
        text = (message.get("text") or "").strip()
        chat = message.get("chat", {}) or {}
        chat_id = chat.get("id")
        username = chat.get("username", "")

        if text.startswith("/verify") and chat_id is not None:
            parts = text.split()
            if len(parts) == 2 and services.confirm_link(parts[1], str(chat_id), username):
                return Response({"ok": True, "linked": True})
            return Response({"ok": True, "linked": False})
        return Response({"ok": True})
