"""Admin registration for the trading domain."""
from django.contrib import admin

from .models import RiskProfile, Trade, TradeJournalEntry


@admin.register(Trade)
class TradeAdmin(admin.ModelAdmin):
    list_display = ("symbol", "side", "status", "volume", "entry_price",
                    "score", "realized_pnl", "user", "created_at")
    list_filter = ("status", "side", "mode", "symbol")
    search_fields = ("symbol", "broker_ticket", "user__email")
    readonly_fields = ("id", "decision_audit", "created_at", "updated_at")
    date_hierarchy = "created_at"


@admin.register(TradeJournalEntry)
class TradeJournalAdmin(admin.ModelAdmin):
    list_display = ("trade", "created_at")
    search_fields = ("trade__symbol", "reason")


@admin.register(RiskProfile)
class RiskProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "mode", "base_risk_percent", "max_daily_loss_percent",
                    "max_open_trades", "emergency_stop")
    list_filter = ("mode", "emergency_stop")
