"""Performance Analytics Engine.

Computes trading performance metrics from closed trades: win/loss rate, profit
factor, expectancy, average RR, drawdown, and an equity curve. Pure functions
over trade data so they are fully testable and deterministic.
"""
from __future__ import annotations

from decimal import Decimal

from .models import Trade, TradeStatus


def _q(v: Decimal) -> str:
    return str(v.quantize(Decimal("0.01")))


def compute_metrics(trades: list[Trade]) -> dict:
    """Return a full analytics payload for a set of (ideally closed) trades."""
    closed = [t for t in trades if t.status == TradeStatus.CLOSED]
    total = len(closed)
    if total == 0:
        return {
            "total_trades": 0,
            "win_rate": "0",
            "loss_rate": "0",
            "profit_factor": "0",
            "expectancy": "0",
            "avg_rr": "0",
            "gross_profit": "0",
            "gross_loss": "0",
            "net_profit": "0",
            "max_drawdown": "0",
            "equity_curve": [],
            "by_symbol": {},
        }

    wins = [t for t in closed if t.realized_pnl > 0]
    losses = [t for t in closed if t.realized_pnl < 0]
    gross_profit = sum((t.realized_pnl for t in wins), Decimal("0"))
    gross_loss = abs(sum((t.realized_pnl for t in losses), Decimal("0")))
    net = gross_profit - gross_loss

    win_rate = Decimal(len(wins)) / Decimal(total) * 100
    loss_rate = Decimal(len(losses)) / Decimal(total) * 100
    profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else Decimal("0")

    avg_win = (gross_profit / len(wins)) if wins else Decimal("0")
    avg_loss = (gross_loss / len(losses)) if losses else Decimal("0")
    p_win = Decimal(len(wins)) / Decimal(total)
    expectancy = p_win * avg_win - (1 - p_win) * avg_loss

    # Average realised reward:risk using each trade's planned RR.
    rrs = []
    for t in closed:
        if t.stop_loss and t.entry_price:
            risk = abs(t.entry_price - t.stop_loss)
            reward = abs((t.take_profit or t.entry_price) - t.entry_price)
            if risk > 0:
                rrs.append(reward / risk)
    avg_rr = (sum(rrs, Decimal("0")) / len(rrs)) if rrs else Decimal("0")

    # Equity curve + max drawdown from cumulative P&L (chronological).
    ordered = sorted(closed, key=lambda t: t.closed_at or t.created_at)
    equity = Decimal("0")
    peak = Decimal("0")
    max_dd = Decimal("0")
    curve = []
    for t in ordered:
        equity += t.realized_pnl
        peak = max(peak, equity)
        dd = peak - equity
        max_dd = max(max_dd, dd)
        curve.append({
            "time": (t.closed_at or t.created_at).isoformat(),
            "equity": _q(equity),
            "trade_pnl": _q(t.realized_pnl),
            "symbol": t.symbol,
        })

    # Per-symbol performance.
    by_symbol: dict[str, dict] = {}
    for t in closed:
        s = by_symbol.setdefault(t.symbol, {"trades": 0, "wins": 0, "net": Decimal("0")})
        s["trades"] += 1
        s["wins"] += 1 if t.realized_pnl > 0 else 0
        s["net"] += t.realized_pnl
    by_symbol_out = {
        k: {
            "trades": v["trades"],
            "win_rate": _q(Decimal(v["wins"]) / Decimal(v["trades"]) * 100),
            "net": _q(v["net"]),
        }
        for k, v in by_symbol.items()
    }

    return {
        "total_trades": total,
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": _q(win_rate),
        "loss_rate": _q(loss_rate),
        "profit_factor": _q(profit_factor),
        "expectancy": _q(expectancy),
        "avg_rr": _q(avg_rr),
        "gross_profit": _q(gross_profit),
        "gross_loss": _q(gross_loss),
        "net_profit": _q(net),
        "max_drawdown": _q(max_dd),
        "equity_curve": curve,
        "by_symbol": by_symbol_out,
    }
