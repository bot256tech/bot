"""Backtesting Engine.

Replays historical OHLC bars bar-by-bar through the scoring pipeline, simulates
entries when the score clears a threshold, and manages each position to its stop
or target on subsequent bars. Produces the same performance metrics shape as the
live analytics engine so results are directly comparable.

Deterministic and side-effect free: given the same bars it always yields the
same result, which makes it suitable for walk-forward and Monte-Carlo drivers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .base import Bias, Candle
from .scoring import ScoringEngine


@dataclass(frozen=True, slots=True)
class BacktestConfig:
    min_score: Decimal = Decimal("60")
    warmup_bars: int = 50            # bars needed before the first decision
    rr_ratio: Decimal = Decimal("2.0")
    risk_per_trade: Decimal = Decimal("100")   # currency risked per trade
    stop_lookback: int = 5           # bars used to place the protective stop
    max_hold_bars: int = 50          # force-exit if neither SL nor TP hit
    allow_shorts: bool = True


@dataclass
class _OpenTrade:
    direction: str
    entry: Decimal
    stop: Decimal
    target: Decimal
    entry_index: int


@dataclass
class BacktestResult:
    trades: list[dict] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)


def _place_levels(direction: str, entry: Decimal, window: list[Candle],
                  rr: Decimal) -> tuple[Decimal, Decimal]:
    if direction == "bullish":
        stop = min(c.low for c in window)
        risk = entry - stop
        return stop, entry + risk * rr
    stop = max(c.high for c in window)
    risk = stop - entry
    return stop, entry - risk * rr


def run_backtest(bars: list[Candle], config: BacktestConfig | None = None) -> BacktestResult:
    """Replay ``bars`` through the pipeline and return trades + metrics."""
    cfg = config or BacktestConfig()
    scorer = ScoringEngine()
    result = BacktestResult()
    open_trade: _OpenTrade | None = None

    for i in range(cfg.warmup_bars, len(bars)):
        current = bars[i]

        # 1. Manage an open position against this bar.
        if open_trade is not None:
            outcome = _check_exit(open_trade, current, i, cfg)
            if outcome is not None:
                result.trades.append(outcome)
                open_trade = None
            # One position at a time (portfolio-safe for a single symbol).
            if open_trade is not None:
                continue

        # 2. Look for a new entry on closed history up to this bar.
        history = bars[: i + 1]
        # Backtesting is research over history: use graded scoring (no hard core
        # gate) so the strategy is measurable on all bars.
        scored = scorer.score(history, require_core=False)
        score = Decimal(str(scored["score"]))
        bias = scored["bias"]
        if score < cfg.min_score or bias == "neutral":
            continue
        if bias == "bearish" and not cfg.allow_shorts:
            continue

        entry = current.close
        window = bars[max(0, i - cfg.stop_lookback): i + 1]
        stop, target = _place_levels(bias, entry, window, cfg.rr_ratio)
        # Guard against degenerate levels.
        if (bias == "bullish" and stop >= entry) or (bias == "bearish" and stop <= entry):
            continue
        open_trade = _OpenTrade(bias, entry, stop, target, i)

    # Force-close any position still open at the end.
    if open_trade is not None:
        last = bars[-1]
        result.trades.append(_settle(open_trade, last.close, len(bars) - 1, "eod", cfg))

    result.metrics = _metrics(result.trades)
    return result


def _check_exit(t: _OpenTrade, bar: Candle, index: int, cfg: BacktestConfig) -> dict | None:
    held = index - t.entry_index
    if t.direction == "bullish":
        if bar.low <= t.stop:
            return _settle(t, t.stop, index, "sl", cfg)
        if bar.high >= t.target:
            return _settle(t, t.target, index, "tp", cfg)
    else:
        if bar.high >= t.stop:
            return _settle(t, t.stop, index, "sl", cfg)
        if bar.low <= t.target:
            return _settle(t, t.target, index, "tp", cfg)
    if held >= cfg.max_hold_bars:
        return _settle(t, bar.close, index, "timeout", cfg)
    return None


def _settle(t: _OpenTrade, exit_price: Decimal, index: int, reason: str,
            cfg: BacktestConfig) -> dict:
    risk_dist = abs(t.entry - t.stop)
    direction = 1 if t.direction == "bullish" else -1
    move = (exit_price - t.entry) * direction
    r_multiple = (move / risk_dist) if risk_dist > 0 else Decimal("0")
    pnl = (r_multiple * cfg.risk_per_trade).quantize(Decimal("0.01"))
    return {
        "direction": t.direction,
        "entry": str(t.entry),
        "exit": str(exit_price),
        "stop": str(t.stop),
        "target": str(t.target),
        "reason": reason,
        "bars_held": index - t.entry_index,
        "r_multiple": str(r_multiple.quantize(Decimal("0.01"))),
        "pnl": str(pnl),
    }


def _metrics(trades: list[dict]) -> dict:
    total = len(trades)
    if total == 0:
        return {"total_trades": 0, "win_rate": "0", "profit_factor": "0",
                "net_profit": "0", "max_drawdown": "0", "expectancy": "0"}
    pnls = [Decimal(t["pnl"]) for t in trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]
    gross_p = sum(wins, Decimal("0"))
    gross_l = abs(sum(losses, Decimal("0")))
    net = gross_p - gross_l
    equity = Decimal("0")
    peak = Decimal("0")
    max_dd = Decimal("0")
    for p in pnls:
        equity += p
        peak = max(peak, equity)
        max_dd = max(max_dd, peak - equity)
    p_win = Decimal(len(wins)) / Decimal(total)
    avg_w = (gross_p / len(wins)) if wins else Decimal("0")
    avg_l = (gross_l / len(losses)) if losses else Decimal("0")
    expectancy = p_win * avg_w - (1 - p_win) * avg_l
    return {
        "total_trades": total,
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": str((p_win * 100).quantize(Decimal("0.01"))),
        "profit_factor": str((gross_p / gross_l).quantize(Decimal("0.01"))) if gross_l else "0",
        "net_profit": str(net.quantize(Decimal("0.01"))),
        "max_drawdown": str(max_dd.quantize(Decimal("0.01"))),
        "expectancy": str(expectancy.quantize(Decimal("0.01"))),
    }
