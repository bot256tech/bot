"""Strategy engine framework.

Defines the shared contracts every strategy module implements so the execution
pipeline (Romeo TPT sequence) can compose them deterministically. Each engine is
independent, side-effect free, and operates on immutable OHLC candle data — this
guarantees auditable, non-repainting analysis (engines only ever see *closed*
candles that the caller passes in).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Protocol


class Bias(str, Enum):
    BULLISH = "bullish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"


@dataclass(frozen=True, slots=True)
class Candle:
    """A single *closed* OHLC candle. Engines never receive forming candles."""

    time: int  # epoch seconds of the candle open
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal = Decimal("0")

    @property
    def is_bullish(self) -> bool:
        return self.close > self.open

    @property
    def is_bearish(self) -> bool:
        return self.close < self.open

    @property
    def body(self) -> Decimal:
        return abs(self.close - self.open)

    @property
    def range(self) -> Decimal:
        return self.high - self.low


@dataclass(frozen=True, slots=True)
class EngineResult:
    """Uniform output from any strategy engine.

    ``detected`` says whether the engine's pattern is present; ``bias`` is the
    directional implication; ``score`` is the engine's contribution (0..1);
    ``details`` carries structured, JSON-safe evidence for auditing/AI narration.
    """

    engine: str
    detected: bool
    bias: Bias = Bias.NEUTRAL
    score: Decimal = Decimal("0")
    details: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {
            "engine": self.engine,
            "detected": self.detected,
            "bias": self.bias.value,
            "score": str(self.score),
            "details": self.details,
        }


class StrategyEngine(Protocol):
    """Contract implemented by every strategy module."""

    name: str

    def analyze(self, candles: list[Candle]) -> EngineResult: ...
