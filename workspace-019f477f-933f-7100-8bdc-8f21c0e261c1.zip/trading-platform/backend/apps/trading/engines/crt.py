"""CRT (Candle Range Theory) Engine.

Identifies the CRT range from a reference candle (the range candle), then detects
expansion vs. compression and the internal/external range boundaries used as
liquidity objectives in the Romeo TPT sequence.

CRT model:
    - Candle 1 = the range (defines CRT High / CRT Low).
    - Candle 2 = the manipulation (sweeps one side of the range).
    - Candle 3 = the distribution (expands toward the opposite side).
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult


class CRTEngine:
    name = "crt"

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 3:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        range_candle = candles[-3]
        manipulation = candles[-2]
        distribution = candles[-1]

        crt_high = range_candle.high
        crt_low = range_candle.low
        crt_mid = (crt_high + crt_low) / 2
        crt_size = crt_high - crt_low
        if crt_size <= 0:
            return EngineResult(self.name, False, details={"reason": "degenerate range"})

        swept_high = manipulation.high > crt_high and manipulation.close < crt_high
        swept_low = manipulation.low < crt_low and manipulation.close > crt_low

        bias = Bias.NEUTRAL
        detected = False
        target = None
        if swept_low and distribution.close > crt_mid:
            bias = Bias.BULLISH           # swept lows -> expand up
            detected = True
            target = crt_high             # external liquidity objective
        elif swept_high and distribution.close < crt_mid:
            bias = Bias.BEARISH           # swept highs -> expand down
            detected = True
            target = crt_low

        # Expansion vs compression of the distribution candle vs the range.
        expansion = distribution.range > crt_size
        phase = "expansion" if expansion else "compression"

        return EngineResult(
            self.name,
            detected,
            bias=bias,
            score=Decimal("0.9") if detected else Decimal("0"),
            details={
                "crt_high": str(crt_high),
                "crt_low": str(crt_low),
                "crt_mid": str(crt_mid),
                "internal_range": [str(crt_low), str(crt_high)],
                "swept_high": swept_high,
                "swept_low": swept_low,
                "phase": phase,
                "target_liquidity": str(target) if target is not None else None,
            },
        )
