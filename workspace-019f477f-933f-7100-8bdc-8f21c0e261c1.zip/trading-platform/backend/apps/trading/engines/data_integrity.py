"""Data integrity guards for the execution pipeline.

Protects against the "stale data" trap: during fast liquidity sweeps the broker
price stream can lag. If the freshest quote/bar is older than the configured
threshold, the trade calculation is aborted rather than executed on historical
prices.

The threshold defaults to 500 ms (per the deployment requirement) and is
configurable via ``MAX_DATA_LATENCY_MS``.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from decouple import config

from apps.broker.gateway import BrokerGateway

# Default maximum acceptable latency between the broker's last tick and "now".
DEFAULT_MAX_LATENCY_MS = config("MAX_DATA_LATENCY_MS", default=500, cast=int)


@dataclass(frozen=True, slots=True)
class LatencyReport:
    fresh: bool
    latency_ms: float
    quote_time: float
    now: float
    threshold_ms: int
    reason: str


class StaleDataError(Exception):
    """Raised when market data is too stale to trade on safely."""


def check_quote_freshness(
    broker: BrokerGateway,
    symbol: str,
    *,
    threshold_ms: int | None = None,
    now: float | None = None,
) -> LatencyReport:
    """Return a latency report for the freshest quote of ``symbol``.

    ``now`` is injectable for deterministic testing.
    """
    threshold = threshold_ms if threshold_ms is not None else DEFAULT_MAX_LATENCY_MS
    current = now if now is not None else time.time()
    quote = broker.get_quote(symbol)
    quote_ts = float(quote.timestamp)

    # If the broker returns no usable tick time (0, or a wildly wrong value from
    # a symbol not selected in Market Watch), treat it as UNKNOWN rather than
    # "stale" so it doesn't spam warnings or block trading with garbage numbers.
    # A sane tick must be within ~1 day of now.
    if quote_ts <= 0 or abs(current - quote_ts) > 86400:
        return LatencyReport(
            fresh=True,  # don't block on unknown; the trade's own gate still applies
            latency_ms=0.0,
            quote_time=quote_ts,
            now=current,
            threshold_ms=threshold,
            reason="No reliable tick timestamp (symbol may not be in Market Watch).",
        )

    latency_ms = max(0.0, (current - quote_ts) * 1000.0)
    fresh = latency_ms <= threshold
    return LatencyReport(
        fresh=fresh,
        latency_ms=round(latency_ms, 2),
        quote_time=quote_ts,
        now=current,
        threshold_ms=threshold,
        reason="OK" if fresh else (
            f"Market data latency {latency_ms:.0f}ms exceeds "
            f"{threshold}ms threshold; aborting to avoid a late entry."
        ),
    )


def require_fresh_quote(
    broker: BrokerGateway, symbol: str, *, threshold_ms: int | None = None
) -> LatencyReport:
    """Raise ``StaleDataError`` if the quote is stale; otherwise return the report."""
    report = check_quote_freshness(broker, symbol, threshold_ms=threshold_ms)
    if not report.fresh:
        raise StaleDataError(report.reason)
    return report
