"""Execution Engine — the Romeo TPT sequence orchestrator.

Runs the full, deterministic decision pipeline and (optionally) places the trade
through the broker gateway. Every stage records an auditable entry so the exact
reasoning behind any trade can be reconstructed.

Sequence:
    scoring (CRT -> sweep -> rejection -> CISD -> KOD -> structure)
        -> HTF alignment (caller supplies bias) -> session/news gate
        -> risk evaluation -> position sizing -> execute
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from apps.broker.gateway import BrokerGateway, OrderRequest, OrderSide, OrderType
from apps.core.exceptions import DomainError

from .base import Candle
from .data_integrity import StaleDataError, check_quote_freshness
from .position_sizing import calculate_position_size
from .risk import RiskConfig, evaluate as risk_evaluate
from .scoring import ScoringEngine


@dataclass(frozen=True, slots=True)
class ExecutionContext:
    symbol: str
    candles: list[Candle]
    htf_bias: str = "neutral"          # from higher-timeframe filter
    session_open: bool = True          # from session engine
    news_blackout: bool = False        # from news filter
    min_score: Decimal = Decimal("60")
    risk_config: RiskConfig = field(default_factory=RiskConfig)
    peak_equity: Decimal | None = None
    realised_pnl_today: Decimal = Decimal("0")
    place_order: bool = False          # False => signal-only / dry-run
    risk_base: str = "balance"
    max_latency_ms: int | None = None  # override the stale-data threshold
    enforce_latency: bool = True       # abort on stale data (disable for dry-runs)
    # --- Profile-driven gates (Small Account / Prop Firm) ---
    profile_name: str = ""             # "SMALL" | "PROP" | "" (unset)
    require_htf_match: bool = False    # profile requires LTF to match HTF bias
    max_daily_trades: int = 0          # 0 = unlimited
    trades_today: int = 0              # how many already taken today
    symbol_allowed: bool = True        # symbol is inside the profile's universe
    # Prop-guard verdict (tiered soft-stop/warning + time/news gates). When the
    # profile is PROP the service computes this and attaches it; the pipeline
    # blocks on SOFT_STOP / HARD_STOP.
    prop_guard: object | None = None


@dataclass(frozen=True, slots=True)
class ExecutionDecision:
    executed: bool
    accepted: bool
    reason: str
    score: Decimal
    bias: str
    side: str | None
    lot_size: Decimal
    entry: Decimal | None
    stop_loss: Decimal | None
    take_profit: Decimal | None
    broker_ticket: str | None
    audit: dict


def run_pipeline(
    ctx: ExecutionContext, broker: BrokerGateway
) -> ExecutionDecision:
    """Execute the deterministic Romeo TPT decision pipeline."""
    audit: dict = {"stages": []}

    def stage(name: str, passed: bool, **data):
        audit["stages"].append({"stage": name, "passed": passed, **data})

    # 0. Data integrity gate — never trade on stale prices (the "stale data trap").
    #    Only enforced when actually placing an order; dry-runs skip the abort.
    if ctx.place_order and ctx.enforce_latency:
        report = check_quote_freshness(
            broker, ctx.symbol, threshold_ms=ctx.max_latency_ms
        )
        audit["latency"] = {
            "latency_ms": report.latency_ms,
            "threshold_ms": report.threshold_ms,
            "fresh": report.fresh,
        }
        stage("data_integrity", passed=report.fresh, latency_ms=report.latency_ms,
              threshold_ms=report.threshold_ms)
        if not report.fresh:
            return _reject(audit, report.reason, Decimal("0"), "neutral")

    # 1. Scoring (runs all strategy engines with the STRICT core gate — a live
    #    trade requires CRT+Liquidity+KOD+CISD confluence).
    scoring = ScoringEngine().score(
        ctx.candles, htf_bias=ctx.htf_bias, require_core=True
    )
    score = Decimal(str(scoring["score"]))
    bias = scoring["bias"]
    audit["scoring"] = scoring
    core_ok = bool(scoring.get("core_ok"))
    stage("scoring", passed=(core_ok and score >= ctx.min_score),
          score=str(score), bias=bias, core_ok=core_ok)

    if not core_ok or bias == "neutral":
        return _reject(audit, "Core confluence (CRT+Liquidity+KOD+CISD) not met.", score, bias)
    if score < ctx.min_score:
        return _reject(audit, "Score below minimum threshold.", score, bias)

    # 1b. Profile gates (Small Account / Prop Firm): symbol universe, daily trade
    #     cap, and score threshold already applied via ctx.min_score.
    if ctx.profile_name:
        audit["profile"] = ctx.profile_name
        stage("symbol_universe", passed=ctx.symbol_allowed, symbol=ctx.symbol,
              profile=ctx.profile_name)
        if not ctx.symbol_allowed:
            return _reject(audit, f"{ctx.symbol} not in {ctx.profile_name} execution universe.",
                           score, bias)

        within_daily = ctx.max_daily_trades == 0 or ctx.trades_today < ctx.max_daily_trades
        stage("max_daily_trades", passed=within_daily,
              taken=ctx.trades_today, limit=ctx.max_daily_trades)
        if not within_daily:
            return _reject(audit, f"Daily trade limit reached "
                           f"({ctx.trades_today}/{ctx.max_daily_trades}).", score, bias)

    # 2. HTF alignment. Prop profile requires a strict match; otherwise only a
    #    non-contradiction is required.
    if ctx.require_htf_match:
        htf_ok = ctx.htf_bias == bias
    else:
        htf_ok = ctx.htf_bias in ("neutral", bias)
    stage("htf_alignment", passed=htf_ok, htf_bias=ctx.htf_bias, signal_bias=bias,
          strict=ctx.require_htf_match)
    if not htf_ok:
        reason = ("Signal must match higher-timeframe bias (prop rule)."
                  if ctx.require_htf_match
                  else "Signal contradicts higher-timeframe bias.")
        return _reject(audit, reason, score, bias)

    # 3. Session + news gate.
    stage("session", passed=ctx.session_open, session_open=ctx.session_open)
    stage("news", passed=not ctx.news_blackout, news_blackout=ctx.news_blackout)
    if not ctx.session_open:
        return _reject(audit, "Outside allowed trading session.", score, bias)
    if ctx.news_blackout:
        return _reject(audit, "High-impact news blackout active.", score, bias)

    # 4. Broker intelligence + market data.
    info = broker.symbol_info(ctx.symbol)
    quote = broker.get_quote(ctx.symbol)
    account = broker.account_summary()
    side = OrderSide.BUY if bias == "bullish" else OrderSide.SELL

    # Derive entry/SL/TP from the CRT engine details when available, else quote.
    crt = next((b for b in scoring["breakdown"] if b["engine"] == "crt"), {})
    entry = quote.ask if side == OrderSide.BUY else quote.bid
    crt_high = _dec(crt.get("details", {}).get("crt_high"))
    crt_low = _dec(crt.get("details", {}).get("crt_low"))
    if side == OrderSide.BUY:
        stop_loss = crt_low if crt_low else entry - info.point * 200
        take_profit = crt_high if crt_high and crt_high > entry else entry + (entry - stop_loss) * 2
    else:
        stop_loss = crt_high if crt_high else entry + info.point * 200
        take_profit = crt_low if crt_low and crt_low < entry else entry - (stop_loss - entry) * 2

    # 5. Risk evaluation.
    peak = ctx.peak_equity or account.equity
    verdict = risk_evaluate(
        ctx.risk_config,
        account=account,
        open_positions=broker.open_positions(),
        peak_equity=peak,
        realised_pnl_today=ctx.realised_pnl_today,
        confidence=score,
    )
    audit["risk"] = {"checks": verdict.checks, "reason": verdict.reason,
                     "risk_percent": str(verdict.effective_risk_percent)}
    stage("risk", passed=verdict.allowed, reason=verdict.reason)
    if not verdict.allowed:
        return _reject(audit, verdict.reason, score, bias, side=side.value,
                       entry=entry, sl=stop_loss, tp=take_profit)

    # 5b. Prop-guard: tiered soft-stop/warning + Friday/weekend/news gates.
    #     WARNING allows the trade; SOFT_STOP / HARD_STOP block it.
    if ctx.prop_guard is not None:
        pg = ctx.prop_guard
        audit["prop_guard"] = pg.as_dict()
        stage("prop_guard", passed=pg.allowed, tier=pg.tier, reasons=pg.reasons)
        if not pg.allowed:
            reason = f"Prop guard {pg.tier}: " + " ".join(pg.reasons)
            return _reject(audit, reason, score, bias, side=side.value,
                           entry=entry, sl=stop_loss, tp=take_profit)

    # 6. Position sizing.
    sizing = calculate_position_size(
        symbol=ctx.symbol,
        entry_price=entry,
        stop_loss=stop_loss,
        risk_percent=verdict.effective_risk_percent,
        account=account,
        info=info,
        risk_base=ctx.risk_base,
    )
    audit["sizing"] = {
        "risk_amount": str(sizing.risk_amount),
        "raw_lot_size": str(sizing.raw_lot_size),
        "final_lot_size": str(sizing.final_lot_size),
        "margin_required": str(sizing.margin_required),
        "reason": sizing.reason,
    }
    stage("sizing", passed=sizing.executable, lot=str(sizing.final_lot_size),
          reason=sizing.reason)
    if not sizing.executable:
        return _reject(audit, sizing.reason, score, bias, side=side.value,
                       entry=entry, sl=stop_loss, tp=take_profit)

    decision = ExecutionDecision(
        executed=False,
        accepted=True,
        reason="OK",
        score=score,
        bias=bias,
        side=side.value,
        lot_size=sizing.final_lot_size,
        entry=entry,
        stop_loss=stop_loss,
        take_profit=take_profit,
        broker_ticket=None,
        audit=audit,
    )

    # 7. Execute (only in auto mode / place_order=True).
    if not ctx.place_order:
        stage("execution", passed=True, note="signal-only (dry-run)")
        return decision

    result = broker.place_order(
        OrderRequest(
            symbol=ctx.symbol,
            side=side,
            volume=sizing.final_lot_size,
            order_type=OrderType.MARKET,
            stop_loss=stop_loss,
            take_profit=take_profit,
            comment="romeo-tpt",
        )
    )
    stage("execution", passed=result.accepted, message=result.message,
          ticket=result.order_id)
    if not result.accepted:
        raise DomainError(f"Broker rejected order: {result.message}", status_code=502)

    return ExecutionDecision(
        executed=True,
        accepted=True,
        reason=result.message,
        score=score,
        bias=bias,
        side=side.value,
        lot_size=sizing.final_lot_size,
        entry=result.filled_price or entry,
        stop_loss=stop_loss,
        take_profit=take_profit,
        broker_ticket=result.order_id,
        audit=audit,
    )


def _dec(v) -> Decimal | None:
    return Decimal(str(v)) if v not in (None, "None", "") else None


def _reject(audit, reason, score, bias, *, side=None, entry=None, sl=None, tp=None):
    return ExecutionDecision(
        executed=False, accepted=False, reason=reason, score=score, bias=bias,
        side=side, lot_size=Decimal("0"), entry=entry, stop_loss=sl,
        take_profit=tp, broker_ticket=None, audit=audit,
    )
