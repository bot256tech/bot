"""Fair Value Gap (FVG) Engine.

Detects 3-candle imbalances (fair value gaps):
    - Bullish FVG: candle[i-1].high < candle[i+1].low  (gap between them).
    - Bearish FVG: candle[i-1].low  > candle[i+1].high.

Also reports Consequent Encroachment (the 50% midpoint of the gap), and each
gap's mitigation state (price traded back into it), invalidation (fully filled),
and relative strength (gap size vs. average range).
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult


class FairValueGapEngine:
    name = "fvg"

    def __init__(self, min_strength: Decimal = Decimal("0.2")) -> None:
        # Minimum gap size as a fraction of average candle range to be tradable.
        self.min_strength = min_strength

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 4:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        avg_range = sum((c.range for c in candles[-10:]), Decimal("0")) / min(10, len(candles))
        if avg_range <= 0:
            return EngineResult(self.name, False, details={"reason": "flat market"})

        gaps: list[dict] = []
        for i in range(1, len(candles) - 1):
            a, c = candles[i - 1], candles[i + 1]
            if a.high < c.low:  # bullish FVG
                gap = {"type": "bullish", "top": c.low, "bottom": a.high, "index": i}
            elif a.low > c.high:  # bearish FVG
                gap = {"type": "bearish", "top": a.low, "bottom": c.high, "index": i}
            else:
                continue

            size = gap["top"] - gap["bottom"]
            gap["strength"] = (size / avg_range) if avg_range else Decimal("0")
            gap["ce"] = (gap["top"] + gap["bottom"]) / 2  # consequent encroachment
            after = candles[i + 2:]
            gap["mitigated"] = self._mitigated(gap, after)
            gap["filled"] = self._filled(gap, after)
            if gap["strength"] >= self.min_strength:
                gaps.append(gap)

        current = candles[-1].close
        # Nearest unfilled gap price is trading into.
        active = [g for g in gaps if not g["filled"]]
        chosen = None
        for g in reversed(active):
            if g["bottom"] <= current <= g["top"]:
                chosen = g
                break
        if chosen is None and active:
            chosen = active[-1]

        detected = chosen is not None
        bias = Bias.NEUTRAL
        if chosen:
            bias = Bias.BULLISH if chosen["type"] == "bullish" else Bias.BEARISH

        return EngineResult(
            self.name,
            detected,
            bias=bias,
            score=Decimal("0.75") if detected else Decimal("0"),
            details={
                "gaps": [self._fmt(g) for g in gaps[-5:]],
                "active_gap": self._fmt(chosen) if chosen else None,
            },
        )

    def _mitigated(self, gap: dict, after: list[Candle]) -> bool:
        for c in after:
            if gap["bottom"] <= c.low <= gap["top"] or gap["bottom"] <= c.high <= gap["top"]:
                return True
        return False

    def _filled(self, gap: dict, after: list[Candle]) -> bool:
        # Fully filled: a candle trades entirely through the gap.
        for c in after:
            if c.low <= gap["bottom"] and c.high >= gap["top"]:
                return True
            if gap["type"] == "bullish" and c.close < gap["bottom"]:
                return True
            if gap["type"] == "bearish" and c.close > gap["top"]:
                return True
        return False

    @staticmethod
    def _fmt(g: dict) -> dict:
        return {
            "type": g["type"],
            "top": str(g["top"]),
            "bottom": str(g["bottom"]),
            "ce": str(g["ce"]),
            "strength": str(g["strength"].quantize(Decimal("0.01"))),
            "mitigated": g["mitigated"],
            "filled": g["filled"],
        }
