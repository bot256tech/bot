"""KOD (Kill-Off Delivery) Engine.

The KOD candle is the final confirmation in the Romeo TPT sequence. It only
validates AFTER a liquidity sweep and requires:
    1. A liquidity sweep occurred (wick beyond a swing extreme).
    2. A strong rejection (long wick against the swept side).
    3. Close back inside the range.
    4. A large opposing candle (body dominates recent range).
    5. Full candle confirmation (the caller only ever passes closed candles).
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult


class KODEngine:
    name = "kod"

    def __init__(self, min_wick_ratio: Decimal = Decimal("0.5")) -> None:
        # Rejection wick must be at least this fraction of the candle range.
        self.min_wick_ratio = min_wick_ratio

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 4:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        kod = candles[-1]
        prior = candles[-4:-1]
        prior_high = max(c.high for c in prior)
        prior_low = min(c.low for c in prior)
        rng = kod.range
        if rng <= 0:
            return EngineResult(self.name, False, details={"reason": "degenerate candle"})

        upper_wick = kod.high - max(kod.open, kod.close)
        lower_wick = min(kod.open, kod.close) - kod.low

        # Bullish KOD: swept prior lows, strong lower-wick rejection, bullish close.
        swept_low = kod.low < prior_low and kod.close > prior_low
        bull_reject = (lower_wick / rng) >= self.min_wick_ratio
        bullish = swept_low and bull_reject and kod.is_bullish

        # Bearish KOD: swept prior highs, strong upper-wick rejection, bearish close.
        swept_high = kod.high > prior_high and kod.close < prior_high
        bear_reject = (upper_wick / rng) >= self.min_wick_ratio
        bearish = swept_high and bear_reject and kod.is_bearish

        avg_prior_body = sum((c.body for c in prior), Decimal("0")) / len(prior)
        large_opposing = kod.body >= avg_prior_body

        detected = (bullish or bearish) and large_opposing
        bias = Bias.BULLISH if bullish else (Bias.BEARISH if bearish else Bias.NEUTRAL)

        return EngineResult(
            self.name,
            detected,
            bias=bias,
            score=Decimal("0.95") if detected else Decimal("0"),
            details={
                "swept_low": swept_low,
                "swept_high": swept_high,
                "lower_wick_ratio": str((lower_wick / rng).quantize(Decimal("0.01"))),
                "upper_wick_ratio": str((upper_wick / rng).quantize(Decimal("0.01"))),
                "large_opposing_candle": large_opposing,
                "close_back_inside": bool(swept_low or swept_high),
            },
        )
