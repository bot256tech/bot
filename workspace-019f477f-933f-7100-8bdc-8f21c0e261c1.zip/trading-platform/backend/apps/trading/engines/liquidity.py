"""Liquidity Engine.

Detects buy-side / sell-side liquidity pools (equal highs/lows) and liquidity
sweeps — a wick that takes out a prior swing extreme and closes back inside.
Deterministic and based only on closed candles (no repainting).
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult


def _swing_highs(candles: list[Candle], lookback: int = 2) -> list[int]:
    idx: list[int] = []
    for i in range(lookback, len(candles) - lookback):
        h = candles[i].high
        if all(h >= candles[i - j].high for j in range(1, lookback + 1)) and all(
            h >= candles[i + j].high for j in range(1, lookback + 1)
        ):
            idx.append(i)
    return idx


def _swing_lows(candles: list[Candle], lookback: int = 2) -> list[int]:
    idx: list[int] = []
    for i in range(lookback, len(candles) - lookback):
        low = candles[i].low
        if all(low <= candles[i - j].low for j in range(1, lookback + 1)) and all(
            low <= candles[i + j].low for j in range(1, lookback + 1)
        ):
            idx.append(i)
    return idx


class LiquidityEngine:
    name = "liquidity"

    def __init__(self, tolerance: Decimal = Decimal("0.0005")) -> None:
        # Relative tolerance for "equal" highs/lows (0.05% by default).
        self.tolerance = tolerance

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 6:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        highs = _swing_highs(candles)
        lows = _swing_lows(candles)
        last = candles[-1]

        buy_side = [candles[i].high for i in highs]     # liquidity above (BSL)
        sell_side = [candles[i].low for i in lows]      # liquidity below (SSL)

        equal_highs = self._equal_levels(buy_side)
        equal_lows = self._equal_levels(sell_side)

        # Sweep detection on the most recent candle. Consider all confirmed
        # swings that occurred strictly before the last candle.
        last_idx = len(candles) - 1
        swept_high = None
        swept_low = None
        for i in highs:
            if i >= last_idx:
                continue
            level = candles[i].high
            if last.high > level and last.close < level:
                swept_high = level
        for i in lows:
            if i >= last_idx:
                continue
            level = candles[i].low
            if last.low < level and last.close > level:
                swept_low = level

        detected = bool(swept_high or swept_low)
        bias = Bias.NEUTRAL
        score = Decimal("0")
        if swept_high:
            bias = Bias.BEARISH  # sweep of highs => reversal down
            score = Decimal("0.9")
        elif swept_low:
            bias = Bias.BULLISH  # sweep of lows => reversal up
            score = Decimal("0.9")

        return EngineResult(
            self.name,
            detected,
            bias=bias,
            score=score,
            details={
                "equal_highs": [str(x) for x in equal_highs],
                "equal_lows": [str(x) for x in equal_lows],
                "swept_high": str(swept_high) if swept_high else None,
                "swept_low": str(swept_low) if swept_low else None,
                "buy_side_liquidity": str(max(buy_side)) if buy_side else None,
                "sell_side_liquidity": str(min(sell_side)) if sell_side else None,
            },
        )

    def _equal_levels(self, levels: list[Decimal]) -> list[Decimal]:
        equal: list[Decimal] = []
        for i in range(len(levels)):
            for j in range(i + 1, len(levels)):
                a, b = levels[i], levels[j]
                if a == 0:
                    continue
                if abs(a - b) / a <= self.tolerance:
                    equal.append(a)
        return sorted(set(equal))
