"""Order Block Engine.

Detects institutional order blocks — the last opposing candle before a strong
displacement move that breaks structure. Classifies bullish/bearish blocks,
whether they've been mitigated (price returned into the block), breaker blocks
(a failed block flipped to the opposite side) and invalid blocks (fully traded
through). Deterministic, closed-candle only.
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult


class OrderBlockEngine:
    name = "order_block"

    def __init__(self, displacement_factor: Decimal = Decimal("1.5")) -> None:
        # The displacement candle body must exceed this multiple of the average
        # body to qualify as institutional participation.
        self.displacement_factor = displacement_factor

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 6:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        avg_body = sum((c.body for c in candles[-10:]), Decimal("0")) / min(10, len(candles))
        if avg_body <= 0:
            return EngineResult(self.name, False, details={"reason": "flat market"})

        last = candles[-1]
        current_price = last.close

        blocks: list[dict] = []
        # Scan for the last opposing candle before a displacement move.
        for i in range(len(candles) - 3, 0, -1):
            disp = candles[i + 1]
            if disp.body < avg_body * self.displacement_factor:
                continue
            origin = candles[i]
            if disp.is_bullish and origin.is_bearish:
                block = {
                    "type": "bullish",
                    "high": origin.high,
                    "low": origin.low,
                    "index": i,
                }
            elif disp.is_bearish and origin.is_bullish:
                block = {
                    "type": "bearish",
                    "high": origin.high,
                    "low": origin.low,
                    "index": i,
                }
            else:
                continue

            # Mitigation / invalidation based on subsequent price action.
            after = candles[i + 2:]
            block["mitigated"] = self._mitigated(block, after)
            block["invalid"] = self._invalid(block, after)
            block["breaker"] = block["invalid"]  # a fully-broken block becomes a breaker
            blocks.append(block)
            if len(blocks) >= 3:
                break

        # The nearest un-invalidated block that price is trading toward.
        active = [b for b in blocks if not b["invalid"]]
        detected = False
        bias = Bias.NEUTRAL
        chosen = None
        for b in active:
            in_block = b["low"] <= current_price <= b["high"]
            if in_block or (not b["mitigated"]):
                chosen = b
                detected = True
                bias = Bias.BULLISH if b["type"] == "bullish" else Bias.BEARISH
                break

        return EngineResult(
            self.name,
            detected,
            bias=bias,
            score=Decimal("0.85") if detected else Decimal("0"),
            details={
                "blocks": [self._fmt(b) for b in blocks],
                "active_block": self._fmt(chosen) if chosen else None,
            },
        )

    def _mitigated(self, block: dict, after: list[Candle]) -> bool:
        for c in after:
            if block["low"] <= c.low <= block["high"] or block["low"] <= c.high <= block["high"]:
                return True
        return False

    def _invalid(self, block: dict, after: list[Candle]) -> bool:
        # Bullish block invalid if price closes decisively below its low; bearish
        # invalid if price closes decisively above its high.
        for c in after:
            if block["type"] == "bullish" and c.close < block["low"]:
                return True
            if block["type"] == "bearish" and c.close > block["high"]:
                return True
        return False

    @staticmethod
    def _fmt(b: dict) -> dict:
        return {
            "type": b["type"],
            "high": str(b["high"]),
            "low": str(b["low"]),
            "mitigated": b["mitigated"],
            "invalid": b["invalid"],
            "breaker": b["breaker"],
        }
