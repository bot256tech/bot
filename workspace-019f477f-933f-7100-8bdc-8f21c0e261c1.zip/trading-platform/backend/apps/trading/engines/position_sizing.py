"""Automatic position-sizing engine.

Computes an executable lot size for ANY instrument (Forex, Indices, Metals,
Energy, Crypto) using only broker-reported specifications — never hardcoded
leverage or contract size. If the broker changes leverage/specs, the next call
automatically reflects it.

The maths is deterministic and fully auditable: every intermediate value is
returned so a trade decision can be logged and reconstructed.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_DOWN, Decimal

from apps.broker.gateway import AccountSummary, SymbolInfo


@dataclass(frozen=True, slots=True)
class SizingResult:
    """Full, auditable breakdown of a position-size calculation."""

    symbol: str
    risk_percent: Decimal
    risk_amount: Decimal            # account currency to risk
    stop_distance_price: Decimal    # |entry - stop| in price terms
    stop_distance_points: Decimal   # in symbol points/ticks
    value_per_point_per_lot: Decimal
    raw_lot_size: Decimal           # before broker rounding/limits
    rounded_lot_size: Decimal       # snapped to volume_step
    margin_required: Decimal        # for the final lot size
    max_lot_by_margin: Decimal      # cap imposed by free margin
    final_lot_size: Decimal         # executable, respecting all constraints
    executable: bool
    reason: str


def _quantize_to_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        return value
    steps = (value / step).to_integral_value(rounding=ROUND_DOWN)
    return (steps * step).quantize(step)


def required_margin_per_lot(
    price: Decimal, info: SymbolInfo, leverage: int
) -> Decimal:
    """Margin for 1.0 lot.

    Prefers the broker-reported ``margin_initial``; otherwise derives it from
    notional / leverage.
    """
    if info.margin_initial and info.margin_initial > 0:
        return info.margin_initial
    lev = Decimal(leverage) if leverage else Decimal("1")
    notional = price * info.contract_size
    return (notional / lev).quantize(Decimal("0.01"))


def calculate_position_size(
    *,
    symbol: str,
    entry_price: Decimal,
    stop_loss: Decimal,
    risk_percent: Decimal,
    account: AccountSummary,
    info: SymbolInfo,
    risk_base: str = "balance",  # "balance" | "equity" | "free_margin"
) -> SizingResult:
    """Return an executable lot size and a full audit trail.

    Formula:
        risk_amount        = risk_base * risk_percent / 100
        value_per_point    = tick_value / tick_size  (per lot, per 1.0 price unit)
        loss_per_lot       = stop_distance_price * value_per_point
        raw_lots           = risk_amount / loss_per_lot
        final_lots         = snap(raw_lots) bounded by [min, max, margin cap]
    """
    base_map = {
        "balance": account.balance,
        "equity": account.equity,
        "free_margin": account.free_margin,
    }
    base = base_map.get(risk_base, account.balance)
    risk_amount = (base * risk_percent / Decimal("100")).quantize(Decimal("0.01"))

    stop_distance_price = abs(entry_price - stop_loss)
    if stop_distance_price <= 0:
        return SizingResult(
            symbol, risk_percent, risk_amount, Decimal("0"), Decimal("0"),
            Decimal("0"), Decimal("0"), Decimal("0"), Decimal("0"),
            Decimal("0"), Decimal("0"), False, "Invalid stop-loss (zero distance).",
        )

    # Value of a 1.0 price-unit move on a 1.0-lot position.
    value_per_price_unit = info.tick_value / info.tick_size
    loss_per_lot = stop_distance_price * value_per_price_unit
    if loss_per_lot <= 0:
        return SizingResult(
            symbol, risk_percent, risk_amount, stop_distance_price, Decimal("0"),
            value_per_price_unit, Decimal("0"), Decimal("0"), Decimal("0"),
            Decimal("0"), Decimal("0"), False, "Non-positive risk per lot.",
        )

    raw_lots = risk_amount / loss_per_lot

    # Snap down to broker volume step, then clamp to min/max.
    rounded = _quantize_to_step(raw_lots, info.volume_step)
    rounded = max(rounded, Decimal("0"))
    rounded = min(rounded, info.max_volume) if info.max_volume else rounded

    # Margin cap: cannot exceed free margin.
    margin_per_lot = required_margin_per_lot(entry_price, info, account.leverage)
    max_lot_by_margin = (
        _quantize_to_step(account.free_margin / margin_per_lot, info.volume_step)
        if margin_per_lot > 0
        else rounded
    )
    final = min(rounded, max_lot_by_margin)

    stop_points = (stop_distance_price / info.tick_size).quantize(Decimal("0.01"))

    if final < info.min_volume:
        margin_required = (margin_per_lot * info.min_volume).quantize(Decimal("0.01"))
        return SizingResult(
            symbol, risk_percent, risk_amount, stop_distance_price, stop_points,
            value_per_price_unit, raw_lots, rounded, margin_required,
            max_lot_by_margin, Decimal("0"), False,
            f"Computed size {final} below broker minimum {info.min_volume}.",
        )

    margin_required = (margin_per_lot * final).quantize(Decimal("0.01"))
    return SizingResult(
        symbol=symbol,
        risk_percent=risk_percent,
        risk_amount=risk_amount,
        stop_distance_price=stop_distance_price,
        stop_distance_points=stop_points,
        value_per_point_per_lot=value_per_price_unit,
        raw_lot_size=raw_lots.quantize(Decimal("0.0001")),
        rounded_lot_size=rounded,
        margin_required=margin_required,
        max_lot_by_margin=max_lot_by_margin,
        final_lot_size=final,
        executable=True,
        reason="OK",
    )
