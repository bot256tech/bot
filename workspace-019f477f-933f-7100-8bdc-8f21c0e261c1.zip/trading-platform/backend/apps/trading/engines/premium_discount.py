"""Premium / Discount Engine.

Establishes the dealing range from the swing high/low of the analysed window and
locates current price within it. Below the 50% equilibrium is *discount* (favour
longs); above is *premium* (favour shorts). Also reports the optimal-trade-entry
(OTE) zone (62%-79% retracement) which the Romeo TPT methodology favours.
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult


class PremiumDiscountEngine:
    name = "premium_discount"

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 5:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        window = candles[-50:] if len(candles) > 50 else candles
        range_high = max(c.high for c in window)
        range_low = min(c.low for c in window)
        size = range_high - range_low
        if size <= 0:
            return EngineResult(self.name, False, details={"reason": "degenerate range"})

        equilibrium = (range_high + range_low) / 2
        price = candles[-1].close
        position = (price - range_low) / size  # 0 = low, 1 = high

        # OTE zones (Fibonacci): discount OTE 0.21-0.38 from low for longs,
        # premium OTE 0.62-0.79 from low for shorts.
        in_discount = position < Decimal("0.5")
        in_premium = position > Decimal("0.5")
        discount_ote = Decimal("0.205") <= position <= Decimal("0.385")
        premium_ote = Decimal("0.615") <= position <= Decimal("0.795")

        bias = Bias.NEUTRAL
        score = Decimal("0")
        if discount_ote:
            bias, score = Bias.BULLISH, Decimal("0.8")
        elif premium_ote:
            bias, score = Bias.BEARISH, Decimal("0.8")
        elif in_discount:
            bias, score = Bias.BULLISH, Decimal("0.5")
        elif in_premium:
            bias, score = Bias.BEARISH, Decimal("0.5")

        zone = (
            "discount_ote" if discount_ote
            else "premium_ote" if premium_ote
            else "discount" if in_discount
            else "premium" if in_premium
            else "equilibrium"
        )

        return EngineResult(
            self.name,
            detected=score > 0,
            bias=bias,
            score=score,
            details={
                "range_high": str(range_high),
                "range_low": str(range_low),
                "equilibrium": str(equilibrium),
                "position": str(position.quantize(Decimal("0.001"))),
                "zone": zone,
            },
        )
