"""Trading Profile Engine (Auto-Profile: Small Account vs Prop Firm).

Resolves the active trading profile from live broker equity and exposes a single
``ResolvedProfile`` that the execution pipeline consumes. All thresholds are read
from the environment (the ``PROP_*`` / ``SMALL_*`` / ``AUTO_*`` keys) so they can
be tuned per deployment without code changes.

Rule (per the deployment requirement):
    equity <  SMALL_ACCOUNT_THRESHOLD  -> SMALL  (growth-focused, with safety caps)
    equity >= SMALL_ACCOUNT_THRESHOLD  -> PROP   (strict prop-firm protection)

When ``AUTO_PROFILE_ENABLED`` is false, ``TRADING_PROFILE`` forces the profile.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from decouple import Csv, config

from .risk import RiskConfig


def _dec(key: str, default: str) -> Decimal:
    return Decimal(str(config(key, default=default)))


@dataclass(frozen=True, slots=True)
class ResolvedProfile:
    """The fully-resolved, active trading profile for a decision."""

    name: str                       # "SMALL" | "PROP"
    risk_config: RiskConfig         # consumed by the Risk Engine
    min_score: Decimal              # setup score gate
    min_quality_score: Decimal      # execution quality gate
    max_daily_trades: int
    require_htf_match: bool
    execution_symbols: tuple[str, ...]
    allow_all_symbols: bool
    # Prop-only fields (0/empty for small accounts).
    daily_drawdown_limit_percent: Decimal
    max_drawdown_limit_percent: Decimal
    phase_target_percent: Decimal
    account_equity: Decimal

    def symbol_allowed(self, symbol: str) -> bool:
        if self.allow_all_symbols:
            return True
        return symbol.upper() in {s.upper() for s in self.execution_symbols}


def _small_profile(equity: Decimal) -> ResolvedProfile:
    rc = RiskConfig(
        mode=config("SMALL_RISK_MODE", default="fixed"),
        base_risk_percent=_dec("SMALL_RISK_PERCENT", "0.75"),
        min_risk_percent=_dec("SMALL_MIN_RISK_PERCENT", "0.25"),
        max_risk_percent=_dec("SMALL_MAX_RISK_PERCENT", "1.5"),
        # Growth-focused but NOT reckless — safety caps per requirement.
        max_daily_loss_percent=_dec("SMALL_MAX_DAILY_LOSS_PERCENT", "8.0"),
        max_weekly_loss_percent=_dec("SMALL_MAX_WEEKLY_LOSS_PERCENT", "15.0"),
        max_monthly_loss_percent=_dec("SMALL_MAX_MONTHLY_LOSS_PERCENT", "30.0"),
        max_open_trades=config("SMALL_MAX_OPEN_TRADES", default=3, cast=int),
        max_total_exposure_percent=_dec("SMALL_MAX_EXPOSURE_PERCENT", "60.0"),
        max_drawdown_percent=_dec("SMALL_MAX_DRAWDOWN_PERCENT", "20.0"),
        emergency_stop=config("EMERGENCY_STOP", default=False, cast=bool),
    )
    return ResolvedProfile(
        name="SMALL",
        risk_config=rc,
        min_score=_dec("SMALL_MIN_SCORE", "85"),
        min_quality_score=_dec("SMALL_MIN_QUALITY_SCORE", "75"),
        max_daily_trades=config("SMALL_MAX_DAILY_TRADES", default=15, cast=int),
        require_htf_match=config("SMALL_REQUIRE_HTF_DIRECTION_MATCH", default=False, cast=bool),
        execution_symbols=tuple(config("SMALL_EXECUTION_SYMBOLS", default="", cast=Csv())),
        allow_all_symbols=config("ALLOW_EXECUTION_ALL_SYMBOLS", default=False, cast=bool),
        daily_drawdown_limit_percent=Decimal("0"),
        max_drawdown_limit_percent=_dec("SMALL_MAX_DRAWDOWN_PERCENT", "20.0"),
        phase_target_percent=Decimal("0"),
        account_equity=equity,
    )


def _prop_profile(equity: Decimal) -> ResolvedProfile:
    # Prop firms enforce hard daily & overall drawdown; map those onto the risk
    # engine's loss/drawdown limits so a breach blocks new trades.
    daily_dd = _dec("PROP_DAILY_DRAWDOWN_LIMIT_PERCENT", "4.0")
    max_dd = _dec("PROP_MAX_DRAWDOWN_LIMIT_PERCENT", "8.0")
    rc = RiskConfig(
        mode=config("PROP_RISK_MODE", default="fixed"),
        base_risk_percent=_dec("PROP_RISK_PERCENT", "0.25"),
        min_risk_percent=_dec("PROP_MIN_RISK_PERCENT", "0.10"),
        max_risk_percent=_dec("PROP_MAX_RISK_PERCENT", "0.50"),
        # Use the prop DAILY drawdown as the daily loss limit.
        max_daily_loss_percent=daily_dd,
        max_weekly_loss_percent=_dec("PROP_WEEKLY_LOSS_PERCENT", "6.0"),
        max_monthly_loss_percent=max_dd,
        max_open_trades=config("PROP_MAX_OPEN_TRADES", default=3, cast=int),
        max_total_exposure_percent=_dec("PROP_MAX_EXPOSURE_PERCENT", "30.0"),
        # Overall prop drawdown maps to the risk engine's max drawdown.
        max_drawdown_percent=max_dd,
        emergency_stop=config("EMERGENCY_STOP", default=False, cast=bool),
    )
    phase = config("PROP_FIRM_PHASE", default="PHASE_1")
    phase_target = (
        _dec("PROP_PHASE_1_TARGET_PERCENT", "8.0")
        if phase == "PHASE_1"
        else _dec("PROP_PHASE_2_TARGET_PERCENT", "5.0")
    )
    return ResolvedProfile(
        name="PROP",
        risk_config=rc,
        min_score=_dec("PROP_MIN_SCORE", "85"),
        min_quality_score=_dec("PROP_MIN_QUALITY_SCORE", "85"),
        max_daily_trades=config("PROP_MAX_DAILY_TRADES", default=10, cast=int),
        require_htf_match=config("PROP_REQUIRE_HTF_DIRECTION_MATCH", default=True, cast=bool),
        execution_symbols=tuple(config("PROP_EXECUTION_SYMBOLS", default="", cast=Csv())),
        allow_all_symbols=config("ALLOW_EXECUTION_ALL_SYMBOLS", default=False, cast=bool),
        daily_drawdown_limit_percent=daily_dd,
        max_drawdown_limit_percent=max_dd,
        phase_target_percent=phase_target,
        account_equity=equity,
    )


def resolve_profile(equity: Decimal) -> ResolvedProfile:
    """Return the active profile for the given live account equity."""
    if not config("AUTO_PROFILE_ENABLED", default=True, cast=bool):
        forced = config("TRADING_PROFILE", default="PROP_FIRM").upper()
        return _small_profile(equity) if forced.startswith("SMALL") else _prop_profile(equity)

    threshold = _dec("SMALL_ACCOUNT_THRESHOLD", "1000")
    return _small_profile(equity) if equity < threshold else _prop_profile(equity)
