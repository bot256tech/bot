"""Prop-Firm Guard Engine.

Enforces the tiered prop-firm rules that sit ON TOP of the base Risk Engine:

    - Drawdown tiers: WARNING -> SOFT_STOP -> HARD_STOP for both the daily loss
      and the overall (max) drawdown.
    - Friday / weekend close: block new entries after the configured Friday
      cutoff (UTC) and all weekend.
    - News blackout: block entries inside +/- a window around high-impact events.
    - Minimum trading days: informational tracking toward the phase requirement.

All thresholds come from the ``PROP_*`` environment keys. The engine is pure and
time-injectable so it is fully testable.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone as dt_timezone
from decimal import Decimal

from decouple import config


def _dec(key: str, default: str) -> Decimal:
    return Decimal(str(config(key, default=default)))


# Tier severity ordering (higher = more severe).
TIER_OK = "OK"
TIER_WARNING = "WARNING"
TIER_SOFT_STOP = "SOFT_STOP"
TIER_HARD_STOP = "HARD_STOP"
_TIER_RANK = {TIER_OK: 0, TIER_WARNING: 1, TIER_SOFT_STOP: 2, TIER_HARD_STOP: 3}


@dataclass(frozen=True, slots=True)
class NewsEvent:
    """A scheduled high-impact economic event (UTC epoch seconds)."""

    time: float
    title: str = ""
    impact: str = "high"


@dataclass(frozen=True, slots=True)
class PropGuardVerdict:
    """Combined prop-guard verdict for opening a new trade."""

    allowed: bool
    tier: str                      # OK | WARNING | SOFT_STOP | HARD_STOP
    reasons: list[str] = field(default_factory=list)
    checks: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {"allowed": self.allowed, "tier": self.tier,
                "reasons": self.reasons, "checks": self.checks}


def _worse(a: str, b: str) -> str:
    return a if _TIER_RANK[a] >= _TIER_RANK[b] else b


def _drawdown_tier(pct: Decimal, warning: Decimal, soft: Decimal, hard: Decimal) -> str:
    if pct >= hard:
        return TIER_HARD_STOP
    if pct >= soft:
        return TIER_SOFT_STOP
    if pct >= warning:
        return TIER_WARNING
    return TIER_OK


def evaluate_prop_guard(
    *,
    balance: Decimal,
    equity: Decimal,
    peak_equity: Decimal,
    realised_pnl_today: Decimal,
    trading_days_completed: int = 0,
    now: datetime | None = None,
    news_events: list[NewsEvent] | None = None,
) -> PropGuardVerdict:
    """Return a tiered prop-guard verdict. WARNING allows trading; SOFT/HARD block."""
    now = now or datetime.now(dt_timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=dt_timezone.utc)
    checks: dict = {}
    reasons: list[str] = []
    tier = TIER_OK

    base = balance if balance > 0 else Decimal("1")

    # --- Daily loss drawdown tiers ---
    daily_loss_pct = (-realised_pnl_today / base * 100) if realised_pnl_today < 0 else Decimal("0")
    daily_tier = _drawdown_tier(
        daily_loss_pct,
        _dec("PROP_DAILY_WARNING_PERCENT", "3.0"),
        _dec("PROP_DAILY_SOFT_STOP_PERCENT", "3.5"),
        _dec("PROP_DAILY_DRAWDOWN_LIMIT_PERCENT", "4.0"),
    )
    checks["daily_loss_percent"] = str(daily_loss_pct.quantize(Decimal("0.01")))
    checks["daily_tier"] = daily_tier
    if daily_tier != TIER_OK:
        reasons.append(f"Daily loss {daily_loss_pct:.2f}% -> {daily_tier}.")
    tier = _worse(tier, daily_tier)

    # --- Overall (max) drawdown tiers, measured from peak equity ---
    max_dd_pct = (
        (peak_equity - equity) / peak_equity * 100 if peak_equity > 0 else Decimal("0")
    )
    max_dd_pct = max(max_dd_pct, Decimal("0"))
    max_tier = _drawdown_tier(
        max_dd_pct,
        _dec("PROP_MAX_DRAWDOWN_WARNING_PERCENT", "6.0"),
        _dec("PROP_MAX_DRAWDOWN_SOFT_STOP_PERCENT", "7.0"),
        _dec("PROP_MAX_DRAWDOWN_LIMIT_PERCENT", "8.0"),
    )
    checks["max_drawdown_percent"] = str(max_dd_pct.quantize(Decimal("0.01")))
    checks["max_drawdown_tier"] = max_tier
    if max_tier != TIER_OK:
        reasons.append(f"Overall drawdown {max_dd_pct:.2f}% -> {max_tier}.")
    tier = _worse(tier, max_tier)

    # --- Friday / weekend close ---
    if config("PROP_WEEKEND_CLOSE_ENABLED", default=True, cast=bool):
        blocked, why = _friday_weekend_block(now)
        checks["time_block"] = blocked
        if blocked:
            reasons.append(why)
            tier = _worse(tier, TIER_HARD_STOP)

    # --- News blackout window ---
    if news_events:
        in_window, why = _news_block(now, news_events)
        checks["news_block"] = in_window
        if in_window:
            reasons.append(why)
            tier = _worse(tier, TIER_HARD_STOP)

    # --- Minimum trading days (informational; never blocks entries) ---
    min_days = config("PROP_MIN_TRADING_DAYS", default=5, cast=int)
    checks["trading_days_completed"] = trading_days_completed
    checks["min_trading_days"] = min_days
    checks["min_days_met"] = trading_days_completed >= min_days

    # WARNING still allows trading; SOFT_STOP and HARD_STOP block new entries.
    allowed = _TIER_RANK[tier] < _TIER_RANK[TIER_SOFT_STOP]
    return PropGuardVerdict(allowed=allowed, tier=tier, reasons=reasons, checks=checks)


def _friday_weekend_block(now: datetime) -> tuple[bool, str]:
    """Weekend rule: close Friday (after cutoff), stay closed Saturday, RE-OPEN
    Sunday from the configured Sunday-open hour so weekend setups can be taken.

    Config:
      PROP_FRIDAY_CLOSE_HOUR_UTC / _MINUTE_UTC  - Friday cutoff (default 20:30)
      PROP_SUNDAY_OPEN_HOUR_UTC  / _MINUTE_UTC  - Sunday re-open (default 21:00)
      PROP_SUNDAY_TRADING_ENABLED               - allow Sunday at all (default true)
    """
    weekday = now.weekday()  # Mon=0 .. Sat=5 .. Sun=6

    if weekday == 5:  # Saturday: always closed
        return True, "Market closed (Saturday)."

    if weekday == 6:  # Sunday: closed until the Sunday open, then tradeable
        if not config("PROP_SUNDAY_TRADING_ENABLED", default=True, cast=bool):
            return True, "Sunday trading disabled."
        open_h = config("PROP_SUNDAY_OPEN_HOUR_UTC", default=21, cast=int)
        open_m = config("PROP_SUNDAY_OPEN_MINUTE_UTC", default=0, cast=int)
        if (now.hour, now.minute) < (open_h, open_m):
            return True, f"Before Sunday open ({open_h:02d}:{open_m:02d} UTC)."
        return False, ""  # Sunday session open

    if weekday == 4:  # Friday: open until the cutoff, then closed
        close_h = config("PROP_FRIDAY_CLOSE_HOUR_UTC", default=20, cast=int)
        close_m = config("PROP_FRIDAY_CLOSE_MINUTE_UTC", default=30, cast=int)
        if (now.hour, now.minute) >= (close_h, close_m):
            return True, f"After Friday close ({close_h:02d}:{close_m:02d} UTC)."

    return False, ""


def _news_block(now: datetime, events: list[NewsEvent]) -> tuple[bool, str]:
    before = config("PROP_NEWS_BLOCK_BEFORE_MINUTES", default=15, cast=int) * 60
    after = config("PROP_NEWS_BLOCK_AFTER_MINUTES", default=15, cast=int) * 60
    ts = now.timestamp()
    for ev in events:
        if ev.impact != "high":
            continue
        if ev.time - before <= ts <= ev.time + after:
            return True, f"High-impact news blackout ({ev.title or 'event'})."
    return False, ""
