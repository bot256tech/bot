"""Custom timeframe resampler (e.g. the "M69" 69-minute bars).

Aggregates 1-minute bars into arbitrary N-minute bars deterministically. To keep
the Django background worker's memory bounded (the "resampler memory leak" trap),
computed frames are held in a small LRU-style cache with a hard entry cap and a
time-to-live; ``purge_stale`` is called hourly by a Celery beat task so old
dataframes are released well before the New York open.

No pandas dependency — aggregation is done with plain Python/Decimal so memory
behaviour is explicit and predictable.
"""
from __future__ import annotations

import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from decimal import Decimal

from .base import Candle


@dataclass(frozen=True, slots=True)
class _CacheEntry:
    created_at: float
    bars: tuple[Candle, ...]


class CustomResampler:
    """Thread-safe resampler with a bounded, self-purging cache."""

    def __init__(
        self,
        period_minutes: int = 69,
        *,
        max_entries: int = 64,
        ttl_seconds: int = 3600,
    ) -> None:
        if period_minutes <= 0:
            raise ValueError("period_minutes must be positive")
        self.period_minutes = period_minutes
        self.max_entries = max_entries
        self.ttl_seconds = ttl_seconds
        self._cache: "OrderedDict[str, _CacheEntry]" = OrderedDict()
        self._lock = threading.RLock()

    # -- core aggregation ------------------------------------------------ #
    def resample(self, one_min_bars: list[Candle]) -> list[Candle]:
        """Aggregate 1-minute bars into ``period_minutes`` bars.

        Bars are grouped by ``floor(bar.time / period_seconds)`` so buckets are
        stable and reproducible regardless of the starting offset.
        """
        if not one_min_bars:
            return []
        period_seconds = self.period_minutes * 60
        buckets: "OrderedDict[int, list[Candle]]" = OrderedDict()
        for bar in sorted(one_min_bars, key=lambda b: b.time):
            key = (bar.time // period_seconds) * period_seconds
            buckets.setdefault(key, []).append(bar)

        out: list[Candle] = []
        for start, group in buckets.items():
            out.append(
                Candle(
                    time=start,
                    open=group[0].open,
                    high=max(b.high for b in group),
                    low=min(b.low for b in group),
                    close=group[-1].close,
                    volume=sum((b.volume for b in group), Decimal("0")),
                )
            )
        return out

    # -- cached access with bounded memory ------------------------------ #
    def resample_cached(
        self, symbol: str, one_min_bars: list[Candle], *, now: float | None = None
    ) -> list[Candle]:
        current = now if now is not None else time.time()
        # Cache key includes the last bar time so new data invalidates the entry.
        last_time = one_min_bars[-1].time if one_min_bars else 0
        key = f"{symbol}:{self.period_minutes}:{len(one_min_bars)}:{last_time}"
        with self._lock:
            self._purge_locked(current)
            hit = self._cache.get(key)
            if hit is not None:
                self._cache.move_to_end(key)
                return list(hit.bars)
            bars = tuple(self.resample(one_min_bars))
            self._cache[key] = _CacheEntry(created_at=current, bars=bars)
            self._cache.move_to_end(key)
            # Enforce the hard entry cap (evict oldest).
            while len(self._cache) > self.max_entries:
                self._cache.popitem(last=False)
            return list(bars)

    def purge_stale(self, now: float | None = None) -> int:
        """Release cache entries older than the TTL. Returns entries removed."""
        current = now if now is not None else time.time()
        with self._lock:
            return self._purge_locked(current)

    def _purge_locked(self, current: float) -> int:
        removed = 0
        for key in list(self._cache.keys()):
            if current - self._cache[key].created_at > self.ttl_seconds:
                del self._cache[key]
                removed += 1
        return removed

    @property
    def cache_size(self) -> int:
        with self._lock:
            return len(self._cache)

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()


# Process-wide singleton for the M69 resampler used by tasks.
m69_resampler = CustomResampler(period_minutes=69)
