"""Risk Engine.

Evaluates whether a new trade is permitted given account state and configured
limits, and computes the effective risk percentage for the trade. Every check
returns a structured, auditable verdict.

Supported risk modes:
    - fixed        : constant risk %
    - dynamic      : scales risk down as drawdown grows
    - confidence   : scales risk with the signal's confidence/score
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from apps.broker.gateway import AccountSummary, Position


@dataclass(frozen=True, slots=True)
class RiskConfig:
    mode: str = "fixed"                       # fixed | dynamic | confidence
    base_risk_percent: Decimal = Decimal("1.0")
    min_risk_percent: Decimal = Decimal("0.25")
    max_risk_percent: Decimal = Decimal("2.0")
    max_daily_loss_percent: Decimal = Decimal("5.0")
    max_weekly_loss_percent: Decimal = Decimal("10.0")
    max_monthly_loss_percent: Decimal = Decimal("20.0")
    max_open_trades: int = 10
    max_total_exposure_percent: Decimal = Decimal("40.0")   # margin/equity
    max_drawdown_percent: Decimal = Decimal("25.0")
    emergency_stop: bool = False


@dataclass(frozen=True, slots=True)
class RiskVerdict:
    allowed: bool
    effective_risk_percent: Decimal
    checks: dict[str, bool] = field(default_factory=dict)
    reason: str = "OK"


def _drawdown_percent(account: AccountSummary, peak_equity: Decimal) -> Decimal:
    if peak_equity <= 0:
        return Decimal("0")
    dd = (peak_equity - account.equity) / peak_equity * Decimal("100")
    return max(dd, Decimal("0")).quantize(Decimal("0.01"))


def effective_risk(
    config: RiskConfig,
    *,
    account: AccountSummary,
    peak_equity: Decimal,
    confidence: Decimal = Decimal("60"),
) -> Decimal:
    """Compute the risk % to use for this trade based on the configured mode."""
    base = Decimal(str(config.base_risk_percent))
    if config.mode == "fixed":
        risk = base
    elif config.mode == "dynamic":
        dd = _drawdown_percent(account, peak_equity)
        # Halve risk once drawdown exceeds half the max allowed.
        factor = Decimal("1.0")
        if config.max_drawdown_percent > 0:
            ratio = dd / config.max_drawdown_percent
            factor = max(Decimal("0.25"), Decimal("1.0") - ratio)
        risk = base * factor
    elif config.mode == "confidence":
        # Map confidence 0..100 onto [min, max].
        span = config.max_risk_percent - config.min_risk_percent
        risk = config.min_risk_percent + span * (confidence / Decimal("100"))
    else:
        risk = base
    return max(config.min_risk_percent, min(config.max_risk_percent, risk)).quantize(
        Decimal("0.01")
    )


def evaluate(
    config: RiskConfig,
    *,
    account: AccountSummary,
    open_positions: list[Position],
    peak_equity: Decimal,
    realised_pnl_today: Decimal = Decimal("0"),
    realised_pnl_week: Decimal = Decimal("0"),
    realised_pnl_month: Decimal = Decimal("0"),
    confidence: Decimal = Decimal("60"),
) -> RiskVerdict:
    """Return a full risk verdict for opening a new trade."""
    checks: dict[str, bool] = {}
    reasons: list[str] = []

    if config.emergency_stop:
        return RiskVerdict(False, Decimal("0"), {"emergency_stop": False},
                           "Emergency stop is active.")

    if not account.trade_allowed:
        return RiskVerdict(False, Decimal("0"), {"trade_allowed": False},
                           "Broker/account trading is disabled.")

    balance = account.balance if account.balance > 0 else Decimal("1")

    # Daily/weekly/monthly loss limits (losses are negative).
    daily_loss = (-realised_pnl_today / balance * 100) if realised_pnl_today < 0 else Decimal("0")
    weekly_loss = (-realised_pnl_week / balance * 100) if realised_pnl_week < 0 else Decimal("0")
    monthly_loss = (-realised_pnl_month / balance * 100) if realised_pnl_month < 0 else Decimal("0")

    checks["daily_loss"] = daily_loss < config.max_daily_loss_percent
    checks["weekly_loss"] = weekly_loss < config.max_weekly_loss_percent
    checks["monthly_loss"] = monthly_loss < config.max_monthly_loss_percent
    checks["max_open_trades"] = len(open_positions) < config.max_open_trades

    exposure_pct = (
        account.margin / account.equity * 100 if account.equity > 0 else Decimal("0")
    )
    checks["exposure"] = exposure_pct < config.max_total_exposure_percent

    dd = _drawdown_percent(account, peak_equity)
    checks["drawdown"] = dd < config.max_drawdown_percent

    if not checks["daily_loss"]:
        reasons.append(f"Daily loss limit reached ({daily_loss:.2f}%).")
    if not checks["weekly_loss"]:
        reasons.append(f"Weekly loss limit reached ({weekly_loss:.2f}%).")
    if not checks["monthly_loss"]:
        reasons.append(f"Monthly loss limit reached ({monthly_loss:.2f}%).")
    if not checks["max_open_trades"]:
        reasons.append(f"Max open trades reached ({len(open_positions)}).")
    if not checks["exposure"]:
        reasons.append(f"Exposure limit reached ({exposure_pct:.2f}%).")
    if not checks["drawdown"]:
        reasons.append(f"Max drawdown reached ({dd:.2f}%).")

    allowed = all(checks.values())
    risk_pct = (
        effective_risk(config, account=account, peak_equity=peak_equity,
                       confidence=confidence)
        if allowed
        else Decimal("0")
    )
    return RiskVerdict(
        allowed=allowed,
        effective_risk_percent=risk_pct,
        checks=checks,
        reason="OK" if allowed else " ".join(reasons),
    )
