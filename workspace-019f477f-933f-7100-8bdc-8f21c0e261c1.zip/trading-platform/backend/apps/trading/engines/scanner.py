"""Market Scanner Engine.

Scans the ENTIRE active-profile symbol universe (not a hardcoded short list),
applies liquidity filters (spread + tick volume), runs the scoring engine on
each tradable symbol, and returns the opportunities ranked by score.

This is what powers the dashboard "scan" so you see the best setups across all
pairs — Forex, metals, indices, energy and crypto — rather than only a couple of
symbols. Symbols with an unfavorable spread or thin volume are skipped so only
tradable, liquid opportunities surface.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from decimal import Decimal

from decouple import config

from apps.broker.gateway import BrokerGateway

from .base import Candle
from .scoring import ScoringEngine

logger = logging.getLogger("trading")


@dataclass(frozen=True, slots=True)
class ScanRow:
    symbol: str
    tradable: bool
    score: Decimal
    bias: str
    spread_points: int
    spread_ok: bool
    volume_ok: bool
    reason: str

    def as_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "tradable": self.tradable,
            "score": str(self.score),
            "bias": self.bias,
            "spread_points": self.spread_points,
            "spread_ok": self.spread_ok,
            "volume_ok": self.volume_ok,
            "reason": self.reason,
        }


def _liquidity_ok(broker: BrokerGateway, symbol: str) -> tuple[bool, bool, int, str]:
    """Return (spread_ok, volume_ok, spread_points, reason) for a symbol."""
    info = broker.symbol_info(symbol)
    if not info.trade_allowed:
        return False, False, info.spread_points, "trading disabled by broker"

    # Spread filter: reject if the live spread is far above the symbol's typical.
    quote = broker.get_quote(symbol)
    tick = info.tick_size if info.tick_size > 0 else info.point
    live_spread_points = int((quote.ask - quote.bid) / tick) if tick > 0 else 0
    multiplier = Decimal(str(config("MAX_SPREAD_MULTIPLIER", default="2.5")))
    max_abs = config("MAX_SYMBOL_SPREAD_POINTS", default=0, cast=int)
    baseline = info.spread_points if info.spread_points > 0 else live_spread_points or 1
    spread_ceiling = int(baseline * multiplier)
    spread_ok = live_spread_points <= spread_ceiling
    if max_abs > 0:
        spread_ok = spread_ok and live_spread_points <= max_abs

    # Volume/liquidity filter: recent bars must show non-trivial tick volume.
    bars = broker.get_candles(symbol, "M5", 20)
    avg_vol = (
        sum((b.volume for b in bars), Decimal("0")) / len(bars) if bars else Decimal("0")
    )
    min_vol = Decimal(str(config("MIN_AVG_TICK_VOLUME", default="1")))
    volume_ok = avg_vol >= min_vol

    reason = "ok"
    if not spread_ok:
        reason = f"spread {live_spread_points} > ceiling {spread_ceiling}"
    elif not volume_ok:
        reason = f"low volume ({avg_vol:.0f} < {min_vol})"
    return spread_ok, volume_ok, live_spread_points, reason


def scan_universe(
    broker: BrokerGateway,
    symbols: list[str],
    *,
    timeframe: str = "M5",
    min_score: Decimal = Decimal("0"),
    max_results: int = 100,
) -> list[ScanRow]:
    """Scan every symbol, filter by liquidity, score, and rank by score desc."""
    rows: list[ScanRow] = []
    scorer = ScoringEngine()

    for symbol in symbols:
        try:
            spread_ok, volume_ok, spread_pts, reason = _liquidity_ok(broker, symbol)
            tradable = spread_ok and volume_ok
            if not tradable:
                rows.append(ScanRow(symbol, False, Decimal("0"), "neutral",
                                    spread_pts, spread_ok, volume_ok, reason))
                continue

            bars = broker.get_candles(symbol, timeframe, 200)
            candles = [Candle(b.time, b.open, b.high, b.low, b.close, b.volume) for b in bars]
            # Scanner shows graded scores for monitoring (no hard core gate);
            # signal/execution paths use require_core=True for strict quality.
            result = scorer.score(candles, require_core=False)
            score = Decimal(str(result["score"]))
            rows.append(ScanRow(
                symbol=symbol,
                tradable=True,
                score=score,
                bias=result["bias"],
                spread_points=spread_pts,
                spread_ok=True,
                volume_ok=True,
                reason="ok",
            ))
        except Exception as exc:  # pragma: no cover - a bad symbol shouldn't kill the scan
            logger.warning("Scan failed for %s: %s", symbol, exc)
            rows.append(ScanRow(symbol, False, Decimal("0"), "neutral", 0,
                                False, False, f"error: {exc}"))

    # Rank: tradable first, then by score desc.
    rows.sort(key=lambda r: (r.tradable, r.score), reverse=True)
    filtered = [r for r in rows if not r.tradable or r.score >= min_score]
    return filtered[:max_results]
