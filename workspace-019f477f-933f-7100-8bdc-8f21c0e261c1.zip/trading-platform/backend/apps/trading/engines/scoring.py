"""Signal Scoring Engine — additive points out of 100 with a strict core gate.

Design (synthesises the Romeo TPT reference model with graded confluence):

* Score is ADDITIVE POINTS OUT OF 100. Each confluence that is present adds its
  fixed points, so a genuine multi-engine setup reaches a real, meaningful high
  score (75 = signal, 85 = execute are both reachable — unlike the old
  normalised model that capped around 57).

* The FOUR CORE confluences are a STRICT GATE: CRT, Liquidity sweep, KOD and
  CISD must all be present and agree on direction, otherwise the setup is
  rejected (score 0). This keeps signal quality high.

* The optional confluences (HTF alignment, structure, order block / FVG,
  premium-discount, session, volatility) are GRADED — full points when strongly
  present, partial when neutral/weak — so we stay productive (spot enough
  setups per day) without dropping quality.

Weights sum to 100.
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult
from .crt import CRTEngine
from .fvg import FairValueGapEngine
from .kod import KODEngine
from .liquidity import LiquidityEngine
from .order_block import OrderBlockEngine
from .premium_discount import PremiumDiscountEngine
from .structure import CISDEngine, MarketStructureEngine

# Points awarded per confluence (must sum to 100).
POINTS: dict[str, Decimal] = {
    "crt": Decimal("12"),
    "liquidity": Decimal("15"),
    "kod": Decimal("12"),
    "cisd": Decimal("12"),
    "market_structure": Decimal("10"),
    "order_block": Decimal("8"),
    "fvg": Decimal("6"),
    "premium_discount": Decimal("6"),
    # Non-engine contextual points (filled by the caller when available).
    "htf": Decimal("15"),
    "volatility": Decimal("4"),
}

# The strict core: all four must be present + directionally aligned, or reject.
CORE = ("crt", "liquidity", "kod", "cisd")


class ScoringEngine:
    def __init__(self, weights: dict[str, Decimal] | None = None) -> None:
        # ``weights`` kept for API compatibility; POINTS drives the model.
        self.points = weights or dict(POINTS)
        self.engines = [
            CRTEngine(),
            LiquidityEngine(),
            KODEngine(),
            CISDEngine(),
            MarketStructureEngine(),
            OrderBlockEngine(),
            FairValueGapEngine(),
            PremiumDiscountEngine(),
        ]

    def score(
        self,
        candles: list[Candle],
        *,
        htf_bias: str = "neutral",
        require_core: bool = True,
    ) -> dict:
        """Return additive score, bias, per-confluence breakdown and gate status.

        ``htf_bias`` is the higher-timeframe bias supplied by the caller
        ("bullish"/"bearish"/"neutral"); it contributes the HTF points.
        ``require_core`` enforces the strict CRT+Liquidity+KOD+CISD gate.
        """
        results: dict[str, EngineResult] = {e.name: e.analyze(candles) for e in self.engines}

        # Determine the intended direction from the aligned core engines.
        bull = sum(1 for n in CORE if results[n].detected and results[n].bias == Bias.BULLISH)
        bear = sum(1 for n in CORE if results[n].detected and results[n].bias == Bias.BEARISH)
        if bull > bear:
            direction = Bias.BULLISH
        elif bear > bull:
            direction = Bias.BEARISH
        else:
            direction = Bias.NEUTRAL

        # --- Strict core gate ---
        core_present = {
            n: (results[n].detected and results[n].bias in (direction, Bias.NEUTRAL))
            for n in CORE
        }
        core_ok = direction != Bias.NEUTRAL and all(core_present.values())

        awarded: dict[str, str] = {}
        total = Decimal("0")

        def add(name: str, pts: Decimal):
            nonlocal total
            total += pts
            awarded[name] = str(pts.quantize(Decimal("0.01")))

        if require_core and not core_ok:
            # Gate failed: no tradable setup. Report which core parts are missing.
            return {
                "score": "0.00",
                "bias": direction.value,
                "core_ok": False,
                "gate": {n: core_present.get(n, False) for n in CORE},
                "awarded": {},
                "breakdown": [results[e.name].as_dict() for e in self.engines],
            }

        # If direction is neutral there is nothing to score.
        if direction == Bias.NEUTRAL:
            return {
                "score": "0.00",
                "bias": "neutral",
                "core_ok": False,
                "gate": {n: core_present.get(n, False) for n in CORE},
                "awarded": {},
                "breakdown": [results[e.name].as_dict() for e in self.engines],
            }

        # --- Core points ---
        # When gated (require_core), all four are present -> full points.
        # When NOT gated (scanner/monitoring), award each present+aligned core
        # engine its points so the ranking still reflects partial confluence.
        for n in CORE:
            if core_present.get(n):
                add(n, self.points[n])

        # --- Graded optional engine confluences ---
        for name in ("market_structure", "order_block", "fvg", "premium_discount"):
            r = results[name]
            pts = self.points[name]
            if not r.detected:
                continue
            if r.bias == direction:
                add(name, pts)                 # full — agrees with direction
            elif r.bias == Bias.NEUTRAL:
                add(name, (pts / 2).quantize(Decimal("0.01")))  # half — neutral
            # opposing bias -> 0 points (but not a hard reject; core already gated)

        # --- HTF alignment (contextual, graded) ---
        htf_pts = self.points["htf"]
        if htf_bias == direction.value:
            add("htf", htf_pts)                # full — HTF confirms
        elif htf_bias == "neutral":
            add("htf", (htf_pts / 2).quantize(Decimal("0.01")))  # half — HTF flat
        # HTF opposing -> 0 (a strong contradiction; leaves score lower)

        # --- Volatility (binary): last candle has real range ---
        if candles:
            last = candles[-1]
            avg_range = sum((c.range for c in candles[-14:]), Decimal("0")) / min(14, len(candles))
            if avg_range > 0 and last.range >= avg_range * Decimal("0.5"):
                add("volatility", self.points["volatility"])

        final_score = min(total, Decimal("100")).quantize(Decimal("0.01"))

        return {
            "score": str(final_score),
            "bias": direction.value,
            "core_ok": True,
            "gate": {n: True for n in CORE},
            "awarded": awarded,
            "breakdown": [results[e.name].as_dict() for e in self.engines],
        }
