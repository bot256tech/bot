"""Market Structure Engine + CISD detection.

Identifies HH/HL/LH/LL, BOS (break of structure), CHOCH (change of character)
and MSS (market structure shift). CISD (Change In State of Delivery) is modelled
as a momentum/structure shift confirmed by a decisive candle close through the
most recent internal swing.
"""
from __future__ import annotations

from decimal import Decimal

from .base import Bias, Candle, EngineResult
from .liquidity import _swing_highs, _swing_lows


class MarketStructureEngine:
    name = "market_structure"

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 8:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        highs = _swing_highs(candles)
        lows = _swing_lows(candles)
        if len(highs) < 2 or len(lows) < 2:
            return EngineResult(self.name, False, details={"reason": "not enough swings"})

        last_two_highs = [candles[i].high for i in highs[-2:]]
        last_two_lows = [candles[i].low for i in lows[-2:]]

        hh = last_two_highs[-1] > last_two_highs[-2]
        hl = last_two_lows[-1] > last_two_lows[-2]
        lh = last_two_highs[-1] < last_two_highs[-2]
        ll = last_two_lows[-1] < last_two_lows[-2]

        last_close = candles[-1].close
        recent_high = candles[highs[-1]].high
        recent_low = candles[lows[-1]].low

        bos = choch = None
        bias = Bias.NEUTRAL
        if last_close > recent_high:
            bias = Bias.BULLISH
            bos = "bullish" if (hh and hl) else None
            choch = "bullish" if (lh or ll) else None
        elif last_close < recent_low:
            bias = Bias.BEARISH
            bos = "bearish" if (lh and ll) else None
            choch = "bearish" if (hh or hl) else None

        detected = bool(bos or choch)
        score = Decimal("0.8") if bos else (Decimal("0.6") if choch else Decimal("0"))

        return EngineResult(
            self.name,
            detected,
            bias=bias,
            score=score,
            details={
                "HH": hh, "HL": hl, "LH": lh, "LL": ll,
                "BOS": bos, "CHOCH": choch,
                "recent_high": str(recent_high),
                "recent_low": str(recent_low),
            },
        )


class CISDEngine:
    """Change In State of Delivery: decisive shift confirmed by candle close."""

    name = "cisd"

    def analyze(self, candles: list[Candle]) -> EngineResult:
        if len(candles) < 5:
            return EngineResult(self.name, False, details={"reason": "insufficient data"})

        # Look for a run of same-colour candles followed by a strong opposing close.
        last = candles[-1]
        prev = candles[-4:-1]
        bullish_run = all(c.is_bearish for c in prev) and last.is_bullish
        bearish_run = all(c.is_bullish for c in prev) and last.is_bearish

        # Confirm the opposing candle closes beyond the last opposing body.
        detected = False
        bias = Bias.NEUTRAL
        if bullish_run and last.close > max(c.open for c in prev):
            detected, bias = True, Bias.BULLISH
        elif bearish_run and last.close < min(c.open for c in prev):
            detected, bias = True, Bias.BEARISH

        # Momentum filter: opposing candle body must dominate the recent bodies.
        strong = last.body >= (sum((c.body for c in prev), Decimal("0")) / len(prev))
        detected = detected and strong

        return EngineResult(
            self.name,
            detected,
            bias=bias,
            score=Decimal("0.85") if detected else Decimal("0"),
            details={
                "momentum_shift": detected,
                "confirming_close": str(last.close),
                "strong_body": strong,
            },
        )
