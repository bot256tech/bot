"""Trading domain models: executed trades, journal, and per-user config."""
from __future__ import annotations

from django.conf import settings
from django.db import models

from apps.core.models import BaseModel


class TradeMode(models.TextChoices):
    AUTO = "auto", "Fully Automated"
    CONFIRM = "confirm", "Manual Confirmation"
    SIGNAL = "signal", "Signal Only"


class TradeSide(models.TextChoices):
    BUY = "buy", "Buy"
    SELL = "sell", "Sell"


class TradeStatus(models.TextChoices):
    PENDING = "pending", "Pending"
    OPEN = "open", "Open"
    CLOSED = "closed", "Closed"
    CANCELLED = "cancelled", "Cancelled"
    REJECTED = "rejected", "Rejected"


class Trade(BaseModel):
    """A trade executed (or attempted) through the execution engine."""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="trades",
    )
    signal = models.ForeignKey(
        "signals.Signal",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="trades",
    )
    broker_ticket = models.CharField(max_length=64, blank=True, db_index=True)

    symbol = models.CharField(max_length=20, db_index=True)
    side = models.CharField(max_length=4, choices=TradeSide.choices)
    status = models.CharField(
        max_length=12, choices=TradeStatus.choices,
        default=TradeStatus.PENDING, db_index=True,
    )
    mode = models.CharField(max_length=8, choices=TradeMode.choices, default=TradeMode.SIGNAL)

    volume = models.DecimalField(max_digits=18, decimal_places=6)
    entry_price = models.DecimalField(max_digits=18, decimal_places=6)
    stop_loss = models.DecimalField(max_digits=18, decimal_places=6, null=True, blank=True)
    take_profit = models.DecimalField(max_digits=18, decimal_places=6, null=True, blank=True)
    close_price = models.DecimalField(max_digits=18, decimal_places=6, null=True, blank=True)

    risk_percent = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    risk_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    margin_required = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    score = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    realized_pnl = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    # Full auditable snapshot of the decision (sizing + risk + engine breakdown).
    decision_audit = models.JSONField(default=dict, blank=True)

    opened_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta(BaseModel.Meta):
        indexes = [
            models.Index(fields=["user", "status"]),
            models.Index(fields=["symbol", "status"]),
        ]

    def __str__(self) -> str:
        return f"{self.side.upper()} {self.symbol} {self.volume} [{self.status}]"


class TradeJournalEntry(BaseModel):
    """Journal record attached to a trade (reason, lessons, screenshot)."""

    trade = models.OneToOneField(
        Trade, on_delete=models.CASCADE, related_name="journal"
    )
    reason = models.TextField(blank=True)
    market_conditions = models.TextField(blank=True)
    lessons = models.TextField(blank=True)
    screenshot = models.ImageField(upload_to="journal/", null=True, blank=True)
    tags = models.JSONField(default=list, blank=True)

    def __str__(self) -> str:
        return f"Journal for {self.trade_id}"


class RiskProfile(BaseModel):
    """Per-user risk configuration consumed by the Risk Engine."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="risk_profile"
    )
    mode = models.CharField(max_length=16, default="fixed")
    base_risk_percent = models.DecimalField(max_digits=5, decimal_places=2, default=1)
    min_risk_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0.25)
    max_risk_percent = models.DecimalField(max_digits=5, decimal_places=2, default=2)
    max_daily_loss_percent = models.DecimalField(max_digits=5, decimal_places=2, default=5)
    max_weekly_loss_percent = models.DecimalField(max_digits=5, decimal_places=2, default=10)
    max_monthly_loss_percent = models.DecimalField(max_digits=6, decimal_places=2, default=20)
    max_open_trades = models.PositiveIntegerField(default=10)
    max_total_exposure_percent = models.DecimalField(max_digits=6, decimal_places=2, default=40)
    max_drawdown_percent = models.DecimalField(max_digits=6, decimal_places=2, default=25)
    emergency_stop = models.BooleanField(default=False)
    # Running equity peak used by the prop-guard drawdown measurement.
    peak_equity = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    def __str__(self) -> str:
        return f"RiskProfile({self.user_id}, {self.mode})"
