"""Serializers for the trading domain."""
from __future__ import annotations

from rest_framework import serializers

from .models import RiskProfile, Trade, TradeJournalEntry


class TradeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trade
        fields = (
            "id", "symbol", "side", "status", "mode", "volume",
            "entry_price", "stop_loss", "take_profit", "close_price",
            "risk_percent", "risk_amount", "margin_required", "score",
            "realized_pnl", "broker_ticket", "decision_audit",
            "opened_at", "closed_at", "created_at",
        )
        read_only_fields = fields


class ExecuteSerializer(serializers.Serializer):
    symbol = serializers.CharField()
    timeframe = serializers.CharField(default="M5", required=False)
    htf_bias = serializers.ChoiceField(
        choices=["bullish", "bearish", "neutral"], default="neutral", required=False
    )
    min_score = serializers.DecimalField(
        max_digits=6, decimal_places=2, default=60, required=False
    )
    place_order = serializers.BooleanField(default=False, required=False)
    mode = serializers.ChoiceField(
        choices=["auto", "confirm", "signal"], default="signal", required=False
    )


class ModifyTradeSerializer(serializers.Serializer):
    stop_loss = serializers.DecimalField(max_digits=18, decimal_places=6, required=False)
    take_profit = serializers.DecimalField(max_digits=18, decimal_places=6, required=False)


class CloseTradeSerializer(serializers.Serializer):
    volume = serializers.DecimalField(
        max_digits=18, decimal_places=6, required=False, allow_null=True
    )


class TradeJournalSerializer(serializers.ModelSerializer):
    class Meta:
        model = TradeJournalEntry
        fields = ("id", "trade", "reason", "market_conditions", "lessons", "tags", "created_at")
        read_only_fields = ("id", "created_at")


class RiskProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = RiskProfile
        exclude = ("user", "is_deleted", "deleted_at")
        read_only_fields = ("id", "created_at", "updated_at")
