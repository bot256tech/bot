"""Trading application services: analysis, execution, and position management."""
from __future__ import annotations

import logging
from decimal import Decimal

from django.utils import timezone

from apps.broker.factory import get_broker
from apps.broker.gateway import BrokerGateway

from .engines.base import Candle
from .engines.execution import ExecutionContext, run_pipeline
from .engines.risk import RiskConfig
from .engines.scoring import ScoringEngine
from .models import RiskProfile, Trade, TradeStatus

logger = logging.getLogger("trading")


def _json_safe(obj):
    """Recursively convert Decimals (and tuples) to JSON-serialisable types."""
    if isinstance(obj, Decimal):
        return str(obj)
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    return obj


def _is_custom_tf(timeframe: str) -> int | None:
    """Return the minute-period for a custom 'M<n>' timeframe not offered by MT5.

    Standard MT5 frames (M1/M5/M15/M30/H1/H4/D1/W1/MN1) return None; a request
    like 'M69' returns 69 so it is resampled from 1-minute bars.
    """
    standard = {"M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN1"}
    tf = timeframe.upper()
    if tf in standard:
        return None
    if tf.startswith("M") and tf[1:].isdigit():
        return int(tf[1:])
    return None


def _candles(broker: BrokerGateway, symbol: str, timeframe: str, count: int) -> list[Candle]:
    period = _is_custom_tf(timeframe)
    if period is not None:
        # Fetch enough 1-minute bars to build `count` custom-period bars, then
        # resample through the memory-bounded cache.
        from .engines.resampler import CustomResampler

        one_min = broker.get_candles(symbol, "M1", period * count + period)
        m1_candles = [Candle(b.time, b.open, b.high, b.low, b.close, b.volume) for b in one_min]
        resampler = CustomResampler(period_minutes=period)
        return resampler.resample_cached(symbol, m1_candles)[-count:]

    bars = broker.get_candles(symbol, timeframe, count)
    return [
        Candle(b.time, b.open, b.high, b.low, b.close, b.volume) for b in bars
    ]


def analyze_symbol(symbol: str, timeframe: str = "M5", count: int = 200) -> dict:
    """Run the scoring engine and return the full breakdown (read-only)."""
    broker = get_broker()
    candles = _candles(broker, symbol, timeframe, count)
    return ScoringEngine().score(candles, require_core=False)


def scan_market(
    *,
    timeframe: str = "M5",
    min_score: Decimal = Decimal("0"),
    max_results: int = 100,
    equity: Decimal | None = None,
) -> dict:
    """Scan the ACTIVE profile's full symbol universe for the best setups.

    Uses the broker to resolve which symbols exist, filters by spread/volume
    liquidity, scores each, and returns them ranked. This is what surfaces
    opportunities across ALL pairs (not just XAU/BTC).
    """
    from .engines.profiles import resolve_profile
    from .engines.scanner import scan_universe

    broker = get_broker()
    account = broker.account_summary()
    profile = resolve_profile(equity if equity is not None else account.equity)

    from decouple import config

    scan_all = config("TRADING_SCAN_ALL_SYMBOLS", default=False, cast=bool)
    symbols = list(profile.execution_symbols)
    if scan_all or profile.allow_all_symbols or not symbols:
        # Scan the broker's ENTIRE advertised symbol list (100+), not just the
        # profile's execution shortlist. Executing is still gated separately.
        symbols = _broker_symbols(broker) or symbols

    rows = scan_universe(
        broker, symbols, timeframe=timeframe,
        min_score=min_score, max_results=max_results,
    )
    tradable = [r for r in rows if r.tradable]
    return {
        "profile": profile.name,
        "timeframe": timeframe,
        "scanned": len(symbols),
        "tradable": len(tradable),
        "results": [r.as_dict() for r in rows],
    }


def _broker_symbols(broker) -> list[str]:
    """Best-effort list of broker symbols (adapters may expose list_symbols)."""
    lister = getattr(broker, "list_symbols", None)
    if callable(lister):
        try:
            return list(lister())
        except Exception:  # pragma: no cover
            return []
    return []


def backtest_symbol(
    symbol: str,
    *,
    timeframe: str = "M5",
    count: int = 500,
    min_score: Decimal = Decimal("60"),
    rr_ratio: Decimal = Decimal("2.0"),
) -> dict:
    """Replay historical bars through the pipeline and return trades + metrics."""
    from .engines.backtest import BacktestConfig, run_backtest

    broker = get_broker()
    candles = _candles(broker, symbol, timeframe, count)
    cfg = BacktestConfig(min_score=min_score, rr_ratio=rr_ratio)
    result = run_backtest(candles, cfg)
    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "bars": len(candles),
        "config": {"min_score": str(min_score), "rr_ratio": str(rr_ratio)},
        "metrics": result.metrics,
        "trades": result.trades[-100:],  # cap payload size
    }


def risk_config_for(user) -> RiskConfig:
    profile, _ = RiskProfile.objects.get_or_create(user=user)
    d = lambda v: Decimal(str(v))  # noqa: E731 - coerce int/str defaults to Decimal
    return RiskConfig(
        mode=profile.mode,
        base_risk_percent=d(profile.base_risk_percent),
        min_risk_percent=d(profile.min_risk_percent),
        max_risk_percent=d(profile.max_risk_percent),
        max_daily_loss_percent=d(profile.max_daily_loss_percent),
        max_weekly_loss_percent=d(profile.max_weekly_loss_percent),
        max_monthly_loss_percent=d(profile.max_monthly_loss_percent),
        max_open_trades=profile.max_open_trades,
        max_total_exposure_percent=d(profile.max_total_exposure_percent),
        max_drawdown_percent=d(profile.max_drawdown_percent),
        emergency_stop=profile.emergency_stop,
    )


def _trades_today(user) -> int:
    """Count trades this user opened/attempted today (UTC)."""
    start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
    return Trade.objects.filter(
        user=user, created_at__gte=start,
        status__in=[TradeStatus.OPEN, TradeStatus.CLOSED],
    ).count()


def _realized_pnl_today(user) -> Decimal:
    """Sum realized P&L for trades closed today (UTC)."""
    start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
    total = Decimal("0")
    for t in Trade.objects.filter(user=user, closed_at__gte=start):
        total += t.realized_pnl
    return total


def _peak_equity(user, current_equity: Decimal) -> Decimal:
    """Best-known equity peak for drawdown measurement.

    Uses the running peak stored on the user's RiskProfile, updated toward the
    current equity. Without a broker equity-history feed this is the most
    reliable, monotonic reference available.
    """
    profile, _ = RiskProfile.objects.get_or_create(user=user)
    stored = getattr(profile, "peak_equity", None) or Decimal("0")
    peak = max(Decimal(str(stored)), current_equity)
    if peak != Decimal(str(stored)):
        profile.peak_equity = peak
        profile.save(update_fields=["peak_equity", "updated_at"])
    return peak


def _trading_days_completed(user) -> int:
    """Distinct UTC dates on which this user has closed at least one trade."""
    dates = (
        Trade.objects.filter(user=user, closed_at__isnull=False)
        .values_list("closed_at", flat=True)
    )
    return len({d.date() for d in dates})


def execute_setup(
    user,
    symbol: str,
    *,
    timeframe: str = "M5",
    htf_bias: str = "neutral",
    min_score: Decimal | None = None,
    place_order: bool = False,
    mode: str = "signal",
) -> Trade:
    """Run the full Romeo TPT pipeline with the ACTIVE trading profile.

    The profile (Small Account vs Prop Firm) is resolved from live broker equity
    on every call, so it flips automatically as the account grows past / drops
    below ``SMALL_ACCOUNT_THRESHOLD``.
    """
    from .engines.profiles import resolve_profile

    broker = get_broker()
    account = broker.account_summary()
    profile = resolve_profile(account.equity)

    # The profile's min_score wins unless the caller explicitly overrides it.
    effective_min_score = min_score if min_score is not None else profile.min_score

    realised_today = _realized_pnl_today(user)

    # Prop accounts get the tiered prop-guard (soft-stop/warning + time/news).
    prop_guard = None
    if profile.name == "PROP":
        from .engines.prop_guard import evaluate_prop_guard

        prop_guard = evaluate_prop_guard(
            balance=account.balance,
            equity=account.equity,
            peak_equity=_peak_equity(user, account.equity),
            realised_pnl_today=realised_today,
            trading_days_completed=_trading_days_completed(user),
            news_events=None,  # wire an economic-calendar source here later
        )
        # Throttled Telegram alert (anti-spam) on any non-OK tier.
        if prop_guard.tier != "OK":
            try:
                from apps.telegram_bot.services import broadcast_prop_guard

                broadcast_prop_guard(prop_guard.tier, prop_guard.reasons, prop_guard.checks)
            except Exception:  # pragma: no cover - defensive
                logger.exception("Prop-guard Telegram alert failed")

    candles = _candles(broker, symbol, timeframe, 200)
    ctx = ExecutionContext(
        symbol=symbol,
        candles=candles,
        htf_bias=htf_bias,
        min_score=effective_min_score,
        risk_config=profile.risk_config,
        place_order=place_order,
        enforce_latency=place_order,  # only gate real orders on data freshness
        realised_pnl_today=realised_today,
        profile_name=profile.name,
        require_htf_match=profile.require_htf_match,
        max_daily_trades=profile.max_daily_trades,
        trades_today=_trades_today(user),
        symbol_allowed=profile.symbol_allowed(symbol),
        prop_guard=prop_guard,
    )
    decision = run_pipeline(ctx, broker)

    status = (
        TradeStatus.OPEN if decision.executed
        else TradeStatus.PENDING if decision.accepted
        else TradeStatus.REJECTED
    )
    trade = Trade.objects.create(
        user=user,
        symbol=symbol,
        side=decision.side or "buy",
        status=status,
        mode=mode,
        volume=decision.lot_size,
        entry_price=decision.entry or Decimal("0"),
        stop_loss=decision.stop_loss,
        take_profit=decision.take_profit,
        score=decision.score,
        risk_percent=Decimal(str(decision.audit.get("risk", {}).get("risk_percent", "0"))),
        risk_amount=Decimal(str(decision.audit.get("sizing", {}).get("risk_amount", "0"))),
        margin_required=Decimal(str(decision.audit.get("sizing", {}).get("margin_required", "0"))),
        broker_ticket=decision.broker_ticket or "",
        decision_audit=_json_safe(decision.audit),
        opened_at=timezone.now() if decision.executed else None,
    )
    logger.info(
        "Setup executed [%s profile, equity=%s]: %s -> %s (%s)",
        profile.name, account.equity, symbol, status, decision.reason,
    )
    if decision.executed:
        try:
            from apps.telegram_bot.services import broadcast_trade

            broadcast_trade(trade)
        except Exception:  # pragma: no cover - defensive
            logger.exception("Telegram trade broadcast failed")
    return trade


def close_trade(trade: Trade, volume: Decimal | None = None) -> Trade:
    """Close (or partially close) an open trade via the broker."""
    broker = get_broker()
    if trade.broker_ticket:
        result = broker.close_position(trade.broker_ticket, volume)
        if not result.accepted:
            from apps.core.exceptions import BrokerError

            raise BrokerError(result.message)
        if result.filled_price:
            trade.close_price = result.filled_price
    if volume is None or volume >= trade.volume:
        trade.status = TradeStatus.CLOSED
        trade.closed_at = timezone.now()
    trade.save()
    return trade


def modify_trade(
    trade: Trade, stop_loss: Decimal | None = None, take_profit: Decimal | None = None
) -> Trade:
    broker = get_broker()
    if trade.broker_ticket:
        result = broker.modify_position(trade.broker_ticket, stop_loss, take_profit)
        if not result.accepted:
            from apps.core.exceptions import BrokerError

            raise BrokerError(result.message)
    if stop_loss is not None:
        trade.stop_loss = stop_loss
    if take_profit is not None:
        trade.take_profit = take_profit
    trade.save()
    return trade
