"""Celery tasks for the trading engine: maintenance and monitoring."""
from __future__ import annotations

import logging

from celery import shared_task

logger = logging.getLogger("trading")


@shared_task(name="trading.purge_resampler_cache")
def purge_resampler_cache() -> int:
    """Hourly memory cleanup for the custom-timeframe resampler cache.

    Prevents the resampler's dataframe cache from growing unbounded on the VPS
    (the "resampler memory leak" trap). Scheduled via Celery beat every hour.
    """
    from .engines.resampler import m69_resampler

    removed = m69_resampler.purge_stale()
    logger.info(
        "Resampler cache purge: removed %d stale entries (size now %d)",
        removed, m69_resampler.cache_size,
    )
    return removed


@shared_task(name="trading.monitor_data_latency")
def monitor_data_latency(symbols: list[str] | None = None) -> dict:
    """Periodically check broker data latency and alert on stale streams."""
    from apps.broker.factory import get_broker

    from .engines.data_integrity import check_quote_freshness

    broker = get_broker()
    # Use the broker's REAL symbols (respecting the "m" suffix etc.). Fall back
    # to the caller's list or a small default only if the broker can't list them.
    if not symbols:
        lister = getattr(broker, "list_symbols", None)
        if callable(lister):
            try:
                symbols = list(lister())[:10]  # sample the first 10 to stay light
            except Exception:
                symbols = []
        if not symbols:
            symbols = ["EURUSDm", "XAUUSDm", "BTCUSDm"]

    results: dict[str, dict] = {}
    for sym in symbols:
        try:
            report = check_quote_freshness(broker, sym)
            results[sym] = {"latency_ms": report.latency_ms, "fresh": report.fresh}
            if not report.fresh:
                logger.warning("Stale data on %s: %s", sym, report.reason)
        except Exception as exc:
            # Symbol may not exist on this broker; skip quietly (no stack spam).
            results[sym] = {"error": str(exc)}
    return results


@shared_task(name="trading.auto_scan_and_trade")
def auto_scan_and_trade() -> dict:
    """Autonomous engine: scan all pairs, auto-signal + auto-execute by score.

    For every tradable pair in the active profile universe:
      * score >= AUTO_SIGNAL_MIN_SCORE  -> generate a signal + push to Telegram
      * score >= AUTO_EXECUTE_MIN_SCORE -> ALSO execute the trade (auto mode)

    Controlled by env flags so it is safe by default:
      TRADING_AUTO_EXECUTION (default false)  - master on/off for live orders
      AUTO_SIGNAL_MIN_SCORE  (default 75)     - threshold to broadcast a signal
      AUTO_EXECUTE_MIN_SCORE (default 85)     - threshold to place a live trade
      AUTO_SCAN_TIMEFRAME    (default M15)    - timeframe to scan on
    """
    from decimal import Decimal

    from decouple import config

    from django.contrib.auth import get_user_model

    from apps.broker.factory import get_broker

    from . import services
    from .engines.profiles import resolve_profile
    from .engines.scanner import scan_universe

    auto_exec_enabled = config("TRADING_AUTO_EXECUTION", default=False, cast=bool)
    signal_min = Decimal(str(config("AUTO_SIGNAL_MIN_SCORE", default="75")))
    execute_min = Decimal(str(config("AUTO_EXECUTE_MIN_SCORE", default="85")))
    timeframe = config("AUTO_SCAN_TIMEFRAME", default="M15")

    broker = get_broker()
    account = broker.account_summary()
    profile = resolve_profile(account.equity)

    symbols = list(profile.execution_symbols)
    if not symbols:
        lister = getattr(broker, "list_symbols", None)
        symbols = list(lister())[:40] if callable(lister) else []

    rows = scan_universe(broker, symbols, timeframe=timeframe, min_score=signal_min)

    # Use the first admin/analyst as the signal author for auto-generated items.
    User = get_user_model()
    author = (
        User.objects.filter(is_superuser=True).first()
        or User.objects.filter(is_staff=True).first()
    )

    signalled: list[str] = []
    executed: list[str] = []
    for row in rows:
        if not row.tradable or Decimal(row.score) < signal_min:
            continue
        symbol = row.symbol

        # 1) Broadcast a signal using the REAL engine score (Telegram fan-out
        #    happens inside publish). Skips if no directional setup.
        try:
            from apps.signals.services import generate_signal_from_engines

            sig = generate_signal_from_engines(
                symbol, timeframe=timeframe, created_by=author, min_score=signal_min
            )
            if sig is not None:
                signalled.append(symbol)
        except Exception as exc:
            logger.warning("Auto-signal failed for %s: %s", symbol, exc)

        # 2) Execute a live trade for the strongest setups (auto mode).
        if auto_exec_enabled and author and Decimal(row.score) >= execute_min:
            try:
                trade = services.execute_setup(
                    author, symbol, timeframe=timeframe,
                    place_order=True, mode="auto",
                )
                if trade.status == "open":
                    executed.append(symbol)
            except Exception as exc:
                logger.warning("Auto-execute failed for %s: %s", symbol, exc)

    logger.info(
        "Auto scan [%s]: signalled=%s executed=%s", profile.name, signalled, executed
    )
    return {"profile": profile.name, "signalled": signalled, "executed": executed}
