"""Trading URL routes."""
from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import (
    ActiveProfileView,
    AnalyticsView,
    AnalyzeView,
    BacktestView,
    JournalViewSet,
    RiskProfileView,
    ScanView,
    TradeViewSet,
)

app_name = "trading"

router = DefaultRouter()
router.register("trades", TradeViewSet, basename="trade")
router.register("journal", JournalViewSet, basename="journal")

urlpatterns = [
    path("analyze/", AnalyzeView.as_view(), name="analyze"),
    path("scan/", ScanView.as_view(), name="scan"),
    path("backtest/", BacktestView.as_view(), name="backtest"),
    path("analytics/", AnalyticsView.as_view(), name="analytics"),
    path("profile/", ActiveProfileView.as_view(), name="active-profile"),
    path("risk-profile/", RiskProfileView.as_view(), name="risk-profile"),
    *router.urls,
]
