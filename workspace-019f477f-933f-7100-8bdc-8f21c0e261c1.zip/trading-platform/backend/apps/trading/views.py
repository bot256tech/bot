"""Trading API: analysis, execution, open positions, and risk profile."""
from __future__ import annotations

from decimal import Decimal

from drf_spectacular.utils import (
    OpenApiParameter,
    extend_schema,
    inline_serializer,
)
from rest_framework import mixins, permissions, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.core.roles import IsSignalAuthor

from . import services
from .models import RiskProfile, Trade, TradeStatus
from .serializers import (
    CloseTradeSerializer,
    ExecuteSerializer,
    ModifyTradeSerializer,
    RiskProfileSerializer,
    TradeSerializer,
)


_ScoreSerializer = inline_serializer(
    "ScoreBreakdown",
    {
        "score": serializers.CharField(),
        "bias": serializers.CharField(),
        "alignment": serializers.CharField(),
        "breakdown": serializers.ListField(child=serializers.DictField()),
    },
)


@extend_schema(
    tags=["trading"],
    parameters=[
        OpenApiParameter("symbol", str, required=True),
        OpenApiParameter("timeframe", str, required=False),
    ],
    responses=_ScoreSerializer,
)
class AnalyzeView(APIView):
    """Run the scoring engine over a symbol (read-only, no order)."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        symbol = request.query_params.get("symbol", "EURUSD")
        timeframe = request.query_params.get("timeframe", "M5")
        return Response(services.analyze_symbol(symbol, timeframe))


@extend_schema(tags=["trading"], parameters=[OpenApiParameter("id", str, "path")])
class TradeViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    """List/inspect trades and run the execution pipeline."""

    serializer_class = TradeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = Trade.objects.filter(user=self.request.user)
        status_param = self.request.query_params.get("status")
        return qs.filter(status=status_param) if status_param else qs

    @extend_schema(request=ExecuteSerializer, responses=TradeSerializer)
    @action(detail=False, methods=["post"], permission_classes=[IsSignalAuthor])
    def execute(self, request):
        """Run the full Romeo TPT pipeline and persist a trade."""
        s = ExecuteSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        trade = services.execute_setup(
            request.user,
            d["symbol"],
            timeframe=d.get("timeframe", "M5"),
            htf_bias=d.get("htf_bias", "neutral"),
            min_score=Decimal(str(d.get("min_score", 60))),
            place_order=d.get("place_order", False),
            mode=d.get("mode", "signal"),
        )
        return Response(TradeSerializer(trade).data, status=201)

    @extend_schema(request=CloseTradeSerializer, responses=TradeSerializer)
    @action(detail=True, methods=["post"])
    def close(self, request, pk=None):
        s = CloseTradeSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        trade = services.close_trade(self.get_object(), s.validated_data.get("volume"))
        return Response(TradeSerializer(trade).data)

    @extend_schema(request=ModifyTradeSerializer, responses=TradeSerializer)
    @action(detail=True, methods=["post"])
    def modify(self, request, pk=None):
        s = ModifyTradeSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        trade = services.modify_trade(
            self.get_object(),
            s.validated_data.get("stop_loss"),
            s.validated_data.get("take_profit"),
        )
        return Response(TradeSerializer(trade).data)


_MetricsSerializer = inline_serializer(
    "PerformanceMetrics",
    {
        "total_trades": serializers.IntegerField(),
        "win_rate": serializers.CharField(),
        "loss_rate": serializers.CharField(),
        "profit_factor": serializers.CharField(),
        "expectancy": serializers.CharField(),
        "avg_rr": serializers.CharField(),
        "net_profit": serializers.CharField(),
        "max_drawdown": serializers.CharField(),
        "equity_curve": serializers.ListField(child=serializers.DictField()),
        "by_symbol": serializers.DictField(),
    },
)


@extend_schema(
    tags=["trading"],
    parameters=[
        OpenApiParameter("timeframe", str, required=False),
        OpenApiParameter("min_score", float, required=False),
        OpenApiParameter("max_results", int, required=False),
    ],
    responses=inline_serializer("MarketScan", {
        "profile": serializers.CharField(),
        "scanned": serializers.IntegerField(),
        "tradable": serializers.IntegerField(),
        "results": serializers.ListField(child=serializers.DictField()),
    }),
)
class ScanView(APIView):
    """Scan the active profile's full symbol universe for the best setups."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from decimal import Decimal

        p = request.query_params
        return Response(services.scan_market(
            timeframe=p.get("timeframe", "M5"),
            min_score=Decimal(str(p.get("min_score", 0))),
            max_results=int(p.get("max_results", 100)),
        ))


@extend_schema(
    tags=["trading"],
    parameters=[
        OpenApiParameter("symbol", str, required=True),
        OpenApiParameter("timeframe", str, required=False),
        OpenApiParameter("count", int, required=False),
        OpenApiParameter("min_score", float, required=False),
        OpenApiParameter("rr_ratio", float, required=False),
    ],
    responses=inline_serializer("BacktestResult", {
        "symbol": serializers.CharField(),
        "bars": serializers.IntegerField(),
        "metrics": serializers.DictField(),
        "trades": serializers.ListField(child=serializers.DictField()),
    }),
)
class BacktestView(APIView):
    """Backtest the strategy over historical bars for a symbol."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from decimal import Decimal

        p = request.query_params
        return Response(services.backtest_symbol(
            p.get("symbol", "EURUSD"),
            timeframe=p.get("timeframe", "M5"),
            count=int(p.get("count", 500)),
            min_score=Decimal(str(p.get("min_score", 60))),
            rr_ratio=Decimal(str(p.get("rr_ratio", 2.0))),
        ))


@extend_schema(
    tags=["trading"],
    responses=inline_serializer("ActiveProfile", {
        "name": serializers.CharField(),
        "account_equity": serializers.CharField(),
        "threshold": serializers.CharField(),
        "risk_percent": serializers.CharField(),
        "min_score": serializers.CharField(),
        "max_open_trades": serializers.IntegerField(),
        "max_daily_trades": serializers.IntegerField(),
        "trades_today": serializers.IntegerField(),
        "daily_drawdown_limit_percent": serializers.CharField(),
        "max_drawdown_limit_percent": serializers.CharField(),
        "require_htf_match": serializers.BooleanField(),
        "prop_guard": serializers.DictField(required=False),
    }),
)
class ActiveProfileView(APIView):
    """The trading profile currently active for live account equity.

    Shows whether the account is treated as a SMALL (growth) or PROP (funded)
    account, and the limits that flow from that.
    """

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from decouple import config

        from apps.broker.factory import get_broker

        from .engines.profiles import resolve_profile

        account = get_broker().account_summary()
        p = resolve_profile(account.equity)
        data = {
            "name": p.name,
            "account_equity": str(account.equity),
            "threshold": str(config("SMALL_ACCOUNT_THRESHOLD", default="1000")),
            "risk_percent": str(p.risk_config.base_risk_percent),
            "min_score": str(p.min_score),
            "max_open_trades": p.risk_config.max_open_trades,
            "max_daily_trades": p.max_daily_trades,
            "trades_today": services._trades_today(request.user),
            "daily_drawdown_limit_percent": str(p.daily_drawdown_limit_percent),
            "max_drawdown_limit_percent": str(p.max_drawdown_limit_percent),
            "require_htf_match": p.require_htf_match,
        }
        # For prop accounts, include the live tiered prop-guard status.
        if p.name == "PROP":
            from .engines.prop_guard import evaluate_prop_guard

            pg = evaluate_prop_guard(
                balance=account.balance,
                equity=account.equity,
                peak_equity=services._peak_equity(request.user, account.equity),
                realised_pnl_today=services._realized_pnl_today(request.user),
                trading_days_completed=services._trading_days_completed(request.user),
            )
            data["prop_guard"] = pg.as_dict()
        return Response(data)


@extend_schema(tags=["trading"], responses=_MetricsSerializer)
class AnalyticsView(APIView):
    """Performance analytics computed from the user's closed trades."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from .analytics import compute_metrics

        trades = list(Trade.objects.filter(user=request.user))
        return Response(compute_metrics(trades))


@extend_schema(tags=["trading"], parameters=[OpenApiParameter("id", str, "path")])
class JournalViewSet(viewsets.ModelViewSet):
    """CRUD for trade journal entries (per user)."""

    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        from .serializers import TradeJournalSerializer

        return TradeJournalSerializer

    def get_queryset(self):
        from .models import TradeJournalEntry

        return TradeJournalEntry.objects.filter(trade__user=self.request.user)


@extend_schema(tags=["trading"], responses=RiskProfileSerializer)
class RiskProfileView(APIView):
    """Read or update the current user's risk profile."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        profile, _ = RiskProfile.objects.get_or_create(user=request.user)
        return Response(RiskProfileSerializer(profile).data)

    @extend_schema(request=RiskProfileSerializer, responses=RiskProfileSerializer)
    def patch(self, request):
        profile, _ = RiskProfile.objects.get_or_create(user=request.user)
        s = RiskProfileSerializer(profile, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response(s.data)
