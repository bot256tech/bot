"""ASGI entrypoint.

Routes HTTP traffic to Django and WebSocket traffic to Channels consumers.
JWT-authenticated WebSockets are handled by the custom middleware in
``apps.core.ws_auth``.
"""
import os

from channels.routing import ProtocolTypeRouter, URLRouter
from channels.security.websocket import AllowedHostsOriginValidator
from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

# Initialise Django before importing anything that touches models/apps.
django_asgi_app = get_asgi_application()

from apps.core.ws_auth import JWTAuthMiddleware  # noqa: E402
from apps.signals.routing import websocket_urlpatterns  # noqa: E402

application = ProtocolTypeRouter(
    {
        "http": django_asgi_app,
        "websocket": AllowedHostsOriginValidator(
            JWTAuthMiddleware(URLRouter(websocket_urlpatterns))
        ),
    }
)
