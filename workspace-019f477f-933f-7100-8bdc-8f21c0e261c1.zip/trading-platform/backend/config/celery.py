"""Celery application factory.

Import this in ``config/__init__.py`` so the app is loaded when Django starts.
Workers/beat are run as NSSM services on the Windows VPS (see deployment guide).
"""
import os

from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

app = Celery("trading_platform")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

# Periodic schedule: evaluate active signals against live prices every 30s.
# In production you may prefer django-celery-beat for a DB-backed schedule.
app.conf.beat_schedule = {
    "evaluate-active-signals": {
        "task": "signals.evaluate",
        "schedule": 30.0,
    },
    # Hourly memory cleanup for the custom-timeframe (M69) resampler cache.
    "purge-resampler-cache": {
        "task": "trading.purge_resampler_cache",
        "schedule": 3600.0,
    },
    # Watch broker data latency (stale-data trap) every minute.
    "monitor-data-latency": {
        "task": "trading.monitor_data_latency",
        "schedule": 60.0,
    },
    # Autonomous engine: scan all pairs, auto-signal (>=75) + auto-execute (>=85).
    # Runs every 5 minutes; controlled by env thresholds & TRADING_AUTO_EXECUTION.
    "auto-scan-and-trade": {
        "task": "trading.auto_scan_and_trade",
        "schedule": 300.0,
    },
}


@app.task(bind=True, ignore_result=True)
def debug_task(self) -> None:
    """Trivial task used to verify the worker is alive."""
    print(f"Celery request: {self.request!r}")
