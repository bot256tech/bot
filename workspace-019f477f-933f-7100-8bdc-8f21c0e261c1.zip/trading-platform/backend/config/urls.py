"""Root URL configuration.

Exposes:
    /admin/                 Django admin
    /api/v1/auth/           Authentication & user endpoints (JWT)
    /api/v1/signals/        Signal domain endpoints
    /api/v1/broker/         Broker abstraction endpoints
    /api/schema/            OpenAPI 3 schema (drf-spectacular)
    /api/docs/              Swagger UI
    /api/redoc/             ReDoc
"""
from django.contrib import admin
from django.urls import include, path
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)

from apps.core.health import LivenessView, ReadinessView

api_v1_patterns = [
    path("health/", LivenessView.as_view(), name="health"),
    path("health/ready/", ReadinessView.as_view(), name="health-ready"),
    path("auth/", include("apps.accounts.urls")),
    path("signals/", include("apps.signals.urls")),
    path("broker/", include("apps.broker.urls")),
    path("trading/", include("apps.trading.urls")),
    path("telegram/", include("apps.telegram_bot.urls")),
]

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/", include((api_v1_patterns, "api"), namespace="v1")),
    # API documentation
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path(
        "api/docs/",
        SpectacularSwaggerView.as_view(url_name="schema"),
        name="swagger-ui",
    ),
    path(
        "api/redoc/",
        SpectacularRedocView.as_view(url_name="schema"),
        name="redoc",
    ),
]
