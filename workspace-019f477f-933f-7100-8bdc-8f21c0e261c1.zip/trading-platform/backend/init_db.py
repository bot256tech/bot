"""Database provisioner / reset helper.

Creates the PostgreSQL role and database used by the platform, and can reset a
half-migrated (broken) schema so migrations apply cleanly.

Reads connection settings from the same ``.env`` the app uses:
    POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_HOST, POSTGRES_PORT

Requires a PostgreSQL SUPERUSER to create roles/databases. Provide it via:
    PG_SUPERUSER (default "postgres") and PG_SUPERPASSWORD

Usage
-----
    python init_db.py            # create role + database if missing
    python init_db.py --reset    # DROP and recreate the database (DESTRUCTIVE)

``--reset`` is safe on a fresh deploy (no real data yet) and is the correct fix
for the "incompatible types: uuid and bigint" FK error, which is caused by a
partially-applied migration leaving inconsistent tables behind.
"""
from __future__ import annotations

import sys

import psycopg
from decouple import config
from psycopg import sql

DB_NAME = config("POSTGRES_DB", default="trading_platform")
DB_USER = config("POSTGRES_USER", default="trading")
DB_PASSWORD = config("POSTGRES_PASSWORD", default="")
DB_HOST = config("POSTGRES_HOST", default="127.0.0.1")
DB_PORT = config("POSTGRES_PORT", default="5432")

SUPERUSER = config("PG_SUPERUSER", default="postgres")
SUPERPASSWORD = config("PG_SUPERPASSWORD", default="")


def _connect_super():
    return psycopg.connect(
        host=DB_HOST, port=DB_PORT, dbname="postgres",
        user=SUPERUSER, password=SUPERPASSWORD, autocommit=True,
    )


def ensure_role(cur) -> None:
    cur.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (DB_USER,))
    if cur.fetchone():
        # Keep the password in sync with .env.
        cur.execute(
            sql.SQL("ALTER ROLE {} WITH LOGIN PASSWORD %s").format(sql.Identifier(DB_USER)),
            (DB_PASSWORD,),
        )
        print(f"Role '{DB_USER}' already exists (password synced).")
    else:
        cur.execute(
            sql.SQL("CREATE ROLE {} WITH LOGIN PASSWORD %s").format(sql.Identifier(DB_USER)),
            (DB_PASSWORD,),
        )
        print(f"Successfully created database user: {DB_USER}")


def drop_database(cur) -> None:
    # Terminate other connections first, then drop.
    cur.execute(
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
        "WHERE datname = %s AND pid <> pg_backend_pid()",
        (DB_NAME,),
    )
    cur.execute(sql.SQL("DROP DATABASE IF EXISTS {}").format(sql.Identifier(DB_NAME)))
    print(f"Dropped database '{DB_NAME}'.")


def create_database(cur) -> None:
    cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (DB_NAME,))
    if cur.fetchone():
        print(f"Database '{DB_NAME}' already exists.")
    else:
        cur.execute(
            sql.SQL("CREATE DATABASE {} OWNER {}").format(
                sql.Identifier(DB_NAME), sql.Identifier(DB_USER)
            )
        )
        print(f"Created database '{DB_NAME}' owned by '{DB_USER}'.")


def grant(cur) -> None:
    cur.execute(
        sql.SQL("GRANT ALL PRIVILEGES ON DATABASE {} TO {}").format(
            sql.Identifier(DB_NAME), sql.Identifier(DB_USER)
        )
    )


def main() -> int:
    reset = "--reset" in sys.argv
    try:
        with _connect_super() as conn, conn.cursor() as cur:
            ensure_role(cur)
            if reset:
                confirm = input(
                    f"⚠️  DROP and recreate database '{DB_NAME}'? All data lost. "
                    f"Type 'yes' to continue: "
                )
                if confirm.strip().lower() != "yes":
                    print("Aborted.")
                    return 1
                drop_database(cur)
            create_database(cur)
            grant(cur)
    except psycopg.OperationalError as exc:
        print(f"ERROR connecting as superuser '{SUPERUSER}': {exc}")
        print("Set PG_SUPERUSER / PG_SUPERPASSWORD in your environment and retry.")
        return 1

    print("Initialization finished. Now run: python manage.py migrate")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
