"""Tests for the performance analytics engine."""
from decimal import Decimal

import pytest
from django.utils import timezone

from apps.accounts.models import User
from apps.trading.analytics import compute_metrics
from apps.trading.models import Trade, TradeStatus


@pytest.fixture
def user(db):
    return User.objects.create_user(email="a@a.com", password="StrongPass123!")


def _trade(user, symbol, pnl, entry="1.0", sl="0.99", tp="1.02"):
    return Trade.objects.create(
        user=user, symbol=symbol, side="buy", status=TradeStatus.CLOSED,
        volume=Decimal("0.1"), entry_price=Decimal(entry),
        stop_loss=Decimal(sl), take_profit=Decimal(tp),
        realized_pnl=Decimal(str(pnl)), closed_at=timezone.now(),
    )


def test_empty_metrics(user):
    m = compute_metrics(list(Trade.objects.filter(user=user)))
    assert m["total_trades"] == 0
    assert m["win_rate"] == "0"


def test_win_rate_and_profit_factor(user):
    _trade(user, "EURUSD", 100)
    _trade(user, "EURUSD", 100)
    _trade(user, "GBPUSD", -50)
    _trade(user, "GBPUSD", -50)
    m = compute_metrics(list(Trade.objects.filter(user=user)))
    assert m["total_trades"] == 4
    assert m["win_rate"] == "50.00"
    assert m["profit_factor"] == "2.00"       # 200 / 100
    assert m["net_profit"] == "100.00"
    assert m["gross_profit"] == "200.00"
    assert m["gross_loss"] == "100.00"


def test_drawdown_and_equity_curve(user):
    _trade(user, "EURUSD", 100)   # equity 100 (peak 100)
    _trade(user, "EURUSD", -80)   # equity 20  (dd 80)
    _trade(user, "EURUSD", 50)    # equity 70
    m = compute_metrics(list(Trade.objects.filter(user=user)))
    assert len(m["equity_curve"]) == 3
    assert m["max_drawdown"] == "80.00"
    assert m["equity_curve"][-1]["equity"] == "70.00"


def test_expectancy_positive(user):
    _trade(user, "EURUSD", 200)
    _trade(user, "EURUSD", -100)
    m = compute_metrics(list(Trade.objects.filter(user=user)))
    # 0.5*200 - 0.5*100 = 50
    assert m["expectancy"] == "50.00"
