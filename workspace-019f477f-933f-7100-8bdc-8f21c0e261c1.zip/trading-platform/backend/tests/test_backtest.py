"""Tests for the backtesting engine."""
from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.broker.factory import reset_broker
from apps.trading.engines.backtest import BacktestConfig, run_backtest
from apps.trading.engines.base import Candle


@pytest.fixture(autouse=True)
def _reset():
    reset_broker()
    yield
    reset_broker()


def _trend(n: int, up: bool = True):
    """An oscillating series with pullbacks/sweeps so real setups can form.

    A pure monotonic trend has no liquidity sweeps, so the strict Romeo TPT core
    (CRT+sweep+KOD+CISD) correctly produces no setups. This series adds periodic
    dips (sweeps of prior lows) inside an uptrend to create tradable patterns.
    """
    import math

    bars = []
    base = 100.0
    for i in range(n):
        drift = i * 0.15 * (1 if up else -1)
        wave = math.sin(i / 3.0) * 1.2  # oscillation creates swings/sweeps
        o = Decimal(str(round(base + drift + wave, 4)))
        c = Decimal(str(round(base + drift + math.sin((i + 1) / 3.0) * 1.2, 4)))
        hi = max(o, c) + Decimal("0.4")
        lo = min(o, c) - Decimal("0.4")
        bars.append(Candle(i * 60, o, hi, lo, c))
    return bars


def test_backtest_runs_and_returns_metrics():
    bars = _trend(200)
    result = run_backtest(bars, BacktestConfig(min_score=Decimal("0"), warmup_bars=50))
    assert "total_trades" in result.metrics
    # With a permissive threshold on a trending series, at least one trade fires.
    assert result.metrics["total_trades"] >= 1
    for t in result.trades:
        assert t["reason"] in ("tp", "sl", "timeout", "eod")
        assert "pnl" in t and "r_multiple" in t


def test_backtest_no_trades_when_threshold_impossible():
    bars = _trend(150)
    result = run_backtest(bars, BacktestConfig(min_score=Decimal("999"), warmup_bars=50))
    assert result.metrics["total_trades"] == 0


def test_backtest_metrics_shape():
    bars = _trend(200)
    result = run_backtest(bars, BacktestConfig(min_score=Decimal("0"), warmup_bars=50))
    m = result.metrics
    for key in ("win_rate", "profit_factor", "net_profit", "max_drawdown", "expectancy"):
        assert key in m


def test_backtest_api(db):
    User.objects.create_user(email="bt@example.com", password="StrongPass123!")
    c = APIClient()
    token = c.post("/api/v1/auth/login/",
                   {"email": "bt@example.com", "password": "StrongPass123!"},
                   format="json").data["access"]
    c.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    r = c.get("/api/v1/trading/backtest/?symbol=EURUSD&timeframe=M5&count=300&min_score=0")
    assert r.status_code == 200, r.content
    assert "metrics" in r.data
    assert r.data["bars"] > 0
