"""Tests for the broker abstraction layer (simulated adapter)."""
from decimal import Decimal

import pytest

from apps.broker.adapters.simulated import SimulatedBroker
from apps.broker.gateway import BrokerGateway, OrderRequest, OrderSide


def test_simulated_broker_satisfies_protocol():
    broker = SimulatedBroker()
    assert isinstance(broker, BrokerGateway)


def test_connect_and_quote():
    broker = SimulatedBroker()
    assert broker.connect() is True
    assert broker.is_connected()
    quote = broker.get_quote("EURUSD")
    assert quote.ask > quote.bid
    assert quote.spread > 0


def test_place_and_close_position():
    broker = SimulatedBroker()
    broker.connect()
    result = broker.place_order(
        OrderRequest(symbol="EURUSD", side=OrderSide.BUY, volume=Decimal("0.10"))
    )
    assert result.accepted
    assert result.order_id is not None
    positions = broker.open_positions()
    assert len(positions) == 1

    close = broker.close_position(result.order_id)
    assert close.accepted
    assert broker.open_positions() == []


def test_order_rejected_when_disconnected():
    broker = SimulatedBroker()
    result = broker.place_order(
        OrderRequest(symbol="EURUSD", side=OrderSide.SELL, volume=Decimal("1"))
    )
    assert not result.accepted
