"""Tests for the trading engines: sizing, risk, strategy engines, pipeline."""
from decimal import Decimal

import pytest

from apps.broker.gateway import AccountSummary, SymbolInfo
from apps.trading.engines.base import Candle
from apps.trading.engines.crt import CRTEngine
from apps.trading.engines.kod import KODEngine
from apps.trading.engines.liquidity import LiquidityEngine
from apps.trading.engines.position_sizing import calculate_position_size
from apps.trading.engines.risk import RiskConfig, evaluate
from apps.trading.engines.scoring import ScoringEngine


def _account(balance="100000", leverage=100, equity=None, margin="0"):
    bal = Decimal(balance)
    return AccountSummary(
        login="SIM", balance=bal, equity=Decimal(equity or balance),
        margin=Decimal(margin), free_margin=bal, margin_level=Decimal("0"),
        currency="USD", leverage=leverage, connected=True,
        server="X", broker_name="Y", trade_allowed=True,
    )


def _forex_info():
    return SymbolInfo(
        symbol="EURUSD", digits=5, point=Decimal("0.00001"),
        contract_size=Decimal("100000"), tick_size=Decimal("0.00001"),
        tick_value=Decimal("1"), min_volume=Decimal("0.01"),
        max_volume=Decimal("100"), volume_step=Decimal("0.01"),
        spread_points=10, trade_allowed=True, filling_modes=("IOC",),
        currency_base="EUR", currency_profit="USD", currency_margin="EUR",
        margin_initial=Decimal("0"),
    )


def _crypto_info():
    return SymbolInfo(
        symbol="BTCUSD", digits=2, point=Decimal("0.01"),
        contract_size=Decimal("1"), tick_size=Decimal("0.01"),
        tick_value=Decimal("0.01"), min_volume=Decimal("0.01"),
        max_volume=Decimal("50"), volume_step=Decimal("0.01"),
        spread_points=200, trade_allowed=True, filling_modes=("IOC",),
        currency_base="BTC", currency_profit="USD", currency_margin="USD",
        margin_initial=Decimal("0"),
    )


# -- position sizing --------------------------------------------------- #
def test_forex_sizing_risks_correct_amount():
    info = _forex_info()
    acc = _account(balance="10000")
    # Risk 1% of 10,000 = $100. Stop 20 pips = 0.00200 price. value/price = 100000.
    # loss_per_lot = 0.00200 * (1/0.00001) = 0.00200*100000 = 200 per lot.
    # raw lots = 100/200 = 0.5
    res = calculate_position_size(
        symbol="EURUSD", entry_price=Decimal("1.10000"),
        stop_loss=Decimal("1.09800"), risk_percent=Decimal("1"),
        account=acc, info=info,
    )
    assert res.executable
    assert res.risk_amount == Decimal("100.00")
    assert res.final_lot_size == Decimal("0.50")


def test_crypto_sizing_uses_broker_specs():
    info = _crypto_info()
    acc = _account(balance="10000")
    res = calculate_position_size(
        symbol="BTCUSD", entry_price=Decimal("60000.00"),
        stop_loss=Decimal("59000.00"), risk_percent=Decimal("1"),
        account=acc, info=info,
    )
    # risk = $100; stop = 1000 price; value/price = 0.01/0.01 = 1; loss/lot = 1000.
    # raw = 0.1 -> snapped 0.1
    assert res.executable
    assert res.final_lot_size == Decimal("0.10")


def test_sizing_rejects_zero_stop():
    res = calculate_position_size(
        symbol="EURUSD", entry_price=Decimal("1.1"), stop_loss=Decimal("1.1"),
        risk_percent=Decimal("1"), account=_account(), info=_forex_info(),
    )
    assert not res.executable


# -- risk engine ------------------------------------------------------- #
def test_risk_blocks_on_daily_loss():
    cfg = RiskConfig(max_daily_loss_percent=Decimal("5"))
    acc = _account(balance="10000")
    v = evaluate(cfg, account=acc, open_positions=[], peak_equity=acc.equity,
                 realised_pnl_today=Decimal("-600"))  # 6% loss > 5%
    assert not v.allowed
    assert "Daily loss" in v.reason


def test_risk_emergency_stop():
    v = evaluate(RiskConfig(emergency_stop=True), account=_account(),
                 open_positions=[], peak_equity=Decimal("100000"))
    assert not v.allowed


def test_confidence_risk_scales():
    cfg = RiskConfig(mode="confidence", min_risk_percent=Decimal("0.5"),
                     max_risk_percent=Decimal("2.0"))
    acc = _account()
    v = evaluate(cfg, account=acc, open_positions=[], peak_equity=acc.equity,
                 confidence=Decimal("100"))
    assert v.effective_risk_percent == Decimal("2.00")


# -- strategy engines -------------------------------------------------- #
def _c(o, h, l, cl, t=0):
    return Candle(t, Decimal(str(o)), Decimal(str(h)), Decimal(str(l)), Decimal(str(cl)))


def test_liquidity_detects_sweep_of_lows():
    # A confirmed swing low (index needs 2 candles either side), then later a
    # candle sweeps below it and closes back above.
    candles = [
        _c(10.5, 10.8, 10.2, 10.4, 1),
        _c(10.4, 10.6, 10.0, 10.1, 2),
        _c(10.1, 10.3, 9.0, 9.2, 3),   # swing low at 9.0 (confirmed by neighbours)
        _c(9.2, 10.0, 9.3, 9.9, 4),
        _c(9.9, 10.4, 9.6, 10.2, 5),
        _c(10.2, 10.5, 10.0, 10.3, 6),
        _c(10.3, 10.6, 8.8, 10.1, 7),  # sweeps below 9.0, closes back above
    ]
    res = LiquidityEngine().analyze(candles)
    assert res.detected
    assert res.bias.value == "bullish"


def test_kod_requires_sweep_and_rejection():
    candles = [
        _c(10, 10.2, 9.8, 9.9, 1),
        _c(9.9, 10.0, 9.7, 9.8, 2),
        _c(9.8, 9.9, 9.5, 9.6, 3),
        # KOD: sweeps below prior low 9.5, long lower wick (>=50% of range),
        # strong bullish close. Range 9.0..10.0 = 1.0; lower wick = 9.6-9.0=0.6.
        _c(9.6, 10.0, 9.0, 9.95, 4),
    ]
    res = KODEngine().analyze(candles)
    assert res.detected
    assert res.bias.value == "bullish"


def test_scoring_returns_breakdown():
    candles = [_c(10 + i * 0.1, 10.3 + i * 0.1, 9.7 + i * 0.1, 10.1 + i * 0.1, i)
               for i in range(30)]
    out = ScoringEngine().score(candles, require_core=False)
    assert "score" in out and "breakdown" in out
    assert len(out["breakdown"]) == 8
    assert Decimal(out["score"]) >= 0


def _fake_engine(name, bias, detected=True, score="0.9"):
    from apps.trading.engines.base import Bias, EngineResult

    bmap = {"bullish": Bias.BULLISH, "bearish": Bias.BEARISH, "neutral": Bias.NEUTRAL}

    class _E:
        def __init__(self):
            self.name = name

        def analyze(self, candles):
            return EngineResult(name, detected, bmap[bias], Decimal(str(score)))

    return _E()


def test_full_aligned_confluence_scores_high():
    """A full aligned confluence (all engines bullish) reaches a high score."""
    from apps.trading.engines import scoring

    eng = scoring.ScoringEngine()
    eng.engines = [_fake_engine(n, "bullish") for n in scoring.POINTS
                   if n not in ("htf", "volatility")]
    out = eng.score([], htf_bias="bullish", require_core=True)
    assert out["core_ok"] is True
    assert out["bias"] == "bullish"
    assert Decimal(out["score"]) >= Decimal("85")


def test_core_gate_rejects_when_core_missing():
    """If a core engine (e.g. CISD) is absent, the strict gate rejects (score 0)."""
    from apps.trading.engines import scoring

    engs = []
    for n in scoring.POINTS:
        if n in ("htf", "volatility"):
            continue
        detected = n != "cisd"  # CISD missing
        engs.append(_fake_engine(n, "bullish", detected=detected))
    eng = scoring.ScoringEngine()
    eng.engines = engs
    out = eng.score([], require_core=True)
    assert out["core_ok"] is False
    assert Decimal(out["score"]) == Decimal("0")


def test_scanner_mode_grades_partial_confluence():
    """With require_core=False the scanner still scores partial confluence."""
    from apps.trading.engines import scoring

    engs = []
    for n in scoring.POINTS:
        if n in ("htf", "volatility"):
            continue
        detected = n in ("crt", "liquidity")  # only 2 core present
        engs.append(_fake_engine(n, "bullish", detected=detected))
    eng = scoring.ScoringEngine()
    eng.engines = engs
    out = eng.score([], require_core=False)
    # CRT(12) + Liquidity(15) present -> ~27 graded score, not 0, not full.
    assert Decimal(out["score"]) > Decimal("0")
    assert Decimal(out["score"]) < Decimal("85")
