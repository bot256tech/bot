"""Tests for Order Block, FVG, and Premium/Discount engines."""
from decimal import Decimal

from apps.trading.engines.base import Candle
from apps.trading.engines.fvg import FairValueGapEngine
from apps.trading.engines.order_block import OrderBlockEngine
from apps.trading.engines.premium_discount import PremiumDiscountEngine
from apps.trading.engines.scoring import ScoringEngine


def _c(o, h, l, cl, t=0):
    return Candle(t, Decimal(str(o)), Decimal(str(h)), Decimal(str(l)), Decimal(str(cl)))


# -- Order Block ------------------------------------------------------- #
def test_order_block_detects_bullish_block():
    # A bearish origin candle followed by a large bullish displacement.
    candles = [
        _c(10.0, 10.1, 9.9, 10.0, 1),
        _c(10.0, 10.1, 9.9, 10.0, 2),
        _c(10.0, 10.1, 9.9, 9.95, 3),
        _c(10.0, 10.15, 9.85, 9.90, 4),   # bearish origin (order block)
        _c(9.90, 11.0, 9.88, 10.95, 5),   # large bullish displacement
        _c(10.95, 11.1, 10.6, 10.7, 6),
        _c(10.7, 10.9, 9.92, 9.95, 7),    # price returns near the block (mitigation)
    ]
    res = OrderBlockEngine(displacement_factor=Decimal("1.2")).analyze(candles)
    assert res.detected
    assert res.bias.value == "bullish"
    assert res.details["active_block"] is not None


def test_order_block_none_in_flat_market():
    candles = [_c(10, 10.05, 9.95, 10.0, i) for i in range(8)]
    res = OrderBlockEngine().analyze(candles)
    assert not res.detected


# -- FVG --------------------------------------------------------------- #
def test_fvg_detects_bullish_gap():
    # candle[i-1].high < candle[i+1].low creates a bullish imbalance.
    candles = [
        _c(10.0, 10.2, 9.8, 10.1, 1),   # high 10.2
        _c(10.2, 11.0, 10.2, 10.9, 2),  # displacement middle
        _c(10.9, 11.5, 10.5, 11.3, 3),  # low 10.5 > 10.2 -> gap 10.2..10.5
        _c(11.3, 11.6, 11.1, 11.4, 4),
    ]
    res = FairValueGapEngine(min_strength=Decimal("0.1")).analyze(candles)
    assert res.detected
    assert res.bias.value == "bullish"
    assert res.details["active_gap"]["ce"] is not None


def test_fvg_reports_consequent_encroachment():
    candles = [
        _c(10.0, 10.2, 9.8, 10.1, 1),
        _c(10.2, 11.0, 10.2, 10.9, 2),
        _c(10.9, 11.5, 10.6, 11.3, 3),  # gap 10.2..10.6, CE = 10.4
        _c(11.3, 11.6, 11.1, 11.4, 4),
    ]
    res = FairValueGapEngine(min_strength=Decimal("0.1")).analyze(candles)
    # The first detected gap spans 10.2..10.6, so its CE is 10.4.
    ce_values = [Decimal(g["ce"]) for g in res.details["gaps"]]
    assert any(Decimal("10.3") < ce < Decimal("10.5") for ce in ce_values)


# -- Premium / Discount ------------------------------------------------ #
def test_premium_discount_flags_discount():
    # Range 9..11; price near the low -> discount / bullish.
    candles = [_c(10, 11.0, 9.0, 10.0, 0)]
    candles += [_c(10, 10.5, 9.5, 9.3 + i * 0.0, i + 1) for i in range(6)]
    res = PremiumDiscountEngine().analyze(candles)
    assert res.bias.value == "bullish"
    assert res.details["zone"] in ("discount", "discount_ote")


def test_premium_discount_flags_premium():
    candles = [_c(10, 11.0, 9.0, 10.0, 0)]
    candles += [_c(10, 10.9, 9.5, 10.8, i + 1) for i in range(6)]
    res = PremiumDiscountEngine().analyze(candles)
    assert res.bias.value == "bearish"


# -- Scoring integration ---------------------------------------------- #
def test_scoring_includes_all_eight_engines():
    candles = [_c(10 + i * 0.1, 10.3 + i * 0.1, 9.7 + i * 0.1, 10.1 + i * 0.1, i)
               for i in range(40)]
    out = ScoringEngine().score(candles, require_core=False)
    engines = {b["engine"] for b in out["breakdown"]}
    assert engines == {
        "crt", "liquidity", "kod", "cisd", "market_structure",
        "order_block", "fvg", "premium_discount",
    }
