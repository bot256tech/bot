"""Tests for the health-check endpoints."""
import pytest
from rest_framework.test import APIClient

from apps.broker.factory import reset_broker


@pytest.fixture(autouse=True)
def _reset():
    reset_broker()
    yield
    reset_broker()


def test_liveness_is_public_and_ok():
    r = APIClient().get("/api/v1/health/")
    assert r.status_code == 200
    assert r.data["status"] == "ok"


def test_readiness_reports_checks(db):
    r = APIClient().get("/api/v1/health/ready/")
    assert r.status_code in (200, 503)
    assert "database" in r.data["checks"]
    assert "broker" in r.data["checks"]
    # DB must be reachable in the test environment.
    assert r.data["checks"]["database"] is True
