"""Tests for the Auto-Profile engine (Small Account vs Prop Firm)."""
from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.broker.factory import reset_broker
from apps.trading.engines.profiles import resolve_profile


@pytest.fixture(autouse=True)
def _reset():
    reset_broker()
    yield
    reset_broker()


@pytest.fixture(autouse=True)
def _profile_env(monkeypatch):
    # Deterministic thresholds regardless of any .env present.
    monkeypatch.setenv("AUTO_PROFILE_ENABLED", "true")
    monkeypatch.setenv("SMALL_ACCOUNT_THRESHOLD", "1000")
    monkeypatch.setenv("SMALL_RISK_PERCENT", "0.75")
    monkeypatch.setenv("PROP_RISK_PERCENT", "0.25")
    monkeypatch.setenv("PROP_DAILY_DRAWDOWN_LIMIT_PERCENT", "4.0")
    monkeypatch.setenv("PROP_MAX_DRAWDOWN_LIMIT_PERCENT", "8.0")
    yield


def test_below_threshold_is_small():
    p = resolve_profile(Decimal("500"))
    assert p.name == "SMALL"
    assert p.risk_config.base_risk_percent == Decimal("0.75")


def test_at_threshold_is_prop():
    p = resolve_profile(Decimal("1000"))
    assert p.name == "PROP"
    assert p.risk_config.base_risk_percent == Decimal("0.25")


def test_above_threshold_is_prop():
    p = resolve_profile(Decimal("10000"))
    assert p.name == "PROP"


def test_small_account_has_safety_caps():
    """Growth-focused but NOT unlimited: daily/drawdown caps must exist."""
    p = resolve_profile(Decimal("500"))
    assert p.risk_config.max_daily_loss_percent == Decimal("8.0")
    assert p.risk_config.max_drawdown_percent == Decimal("20.0")


def test_prop_maps_drawdown_limits_to_risk_engine():
    p = resolve_profile(Decimal("10000"))
    # Prop daily drawdown -> risk engine daily loss limit.
    assert p.risk_config.max_daily_loss_percent == Decimal("4.0")
    assert p.risk_config.max_drawdown_percent == Decimal("8.0")
    assert p.daily_drawdown_limit_percent == Decimal("4.0")


def test_forced_profile_when_auto_disabled(monkeypatch):
    monkeypatch.setenv("AUTO_PROFILE_ENABLED", "false")
    monkeypatch.setenv("TRADING_PROFILE", "SMALL")
    # Even with big equity, forced SMALL.
    assert resolve_profile(Decimal("50000")).name == "SMALL"


def test_symbol_universe_enforced(monkeypatch):
    monkeypatch.setenv("ALLOW_EXECUTION_ALL_SYMBOLS", "false")
    monkeypatch.setenv("PROP_EXECUTION_SYMBOLS", "BTCUSDm,XAUUSDm,EURUSDm")
    p = resolve_profile(Decimal("10000"))
    assert p.symbol_allowed("XAUUSDm")
    assert not p.symbol_allowed("GBPJPYm")


def test_active_profile_api(db, monkeypatch):
    monkeypatch.setenv("SMALL_ACCOUNT_THRESHOLD", "1000")
    User.objects.create_user(email="p@example.com", password="StrongPass123!")
    c = APIClient()
    token = c.post("/api/v1/auth/login/",
                   {"email": "p@example.com", "password": "StrongPass123!"},
                   format="json").data["access"]
    c.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    r = c.get("/api/v1/trading/profile/")
    assert r.status_code == 200, r.content
    # Simulated broker starts at 100,000 equity -> PROP.
    assert r.data["name"] == "PROP"
    assert "account_equity" in r.data
