"""Tests for the Prop-Firm Guard engine and Telegram anti-spam throttle."""
from datetime import datetime, timezone
from decimal import Decimal

import pytest

from apps.telegram_bot import throttle
from apps.trading.engines.prop_guard import (
    NewsEvent,
    TIER_HARD_STOP,
    TIER_OK,
    TIER_SOFT_STOP,
    TIER_WARNING,
    evaluate_prop_guard,
)


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setenv("PROP_DAILY_WARNING_PERCENT", "3.0")
    monkeypatch.setenv("PROP_DAILY_SOFT_STOP_PERCENT", "3.5")
    monkeypatch.setenv("PROP_DAILY_DRAWDOWN_LIMIT_PERCENT", "4.0")
    monkeypatch.setenv("PROP_MAX_DRAWDOWN_WARNING_PERCENT", "6.0")
    monkeypatch.setenv("PROP_MAX_DRAWDOWN_SOFT_STOP_PERCENT", "7.0")
    monkeypatch.setenv("PROP_MAX_DRAWDOWN_LIMIT_PERCENT", "8.0")
    monkeypatch.setenv("PROP_WEEKEND_CLOSE_ENABLED", "true")
    monkeypatch.setenv("PROP_FRIDAY_CLOSE_HOUR_UTC", "20")
    monkeypatch.setenv("PROP_FRIDAY_CLOSE_MINUTE_UTC", "30")
    monkeypatch.setenv("PROP_NEWS_BLOCK_BEFORE_MINUTES", "15")
    monkeypatch.setenv("PROP_NEWS_BLOCK_AFTER_MINUTES", "15")
    monkeypatch.setenv("PROP_MIN_TRADING_DAYS", "5")
    throttle.reset()
    yield
    throttle.reset()


# A quiet mid-week trading time (Wednesday 12:00 UTC).
WED = datetime(2026, 7, 8, 12, 0, tzinfo=timezone.utc)


def test_ok_when_flat():
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=WED)
    assert v.tier == TIER_OK and v.allowed


def test_daily_warning_still_allows():
    # 3.2% daily loss -> WARNING (>=3.0, <3.5). Trading still allowed.
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("9680"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("-320"),
                            now=WED)
    assert v.tier == TIER_WARNING
    assert v.allowed


def test_daily_soft_stop_blocks():
    # 3.6% daily loss -> SOFT_STOP. Blocks new entries.
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("9640"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("-360"),
                            now=WED)
    assert v.tier == TIER_SOFT_STOP
    assert not v.allowed


def test_daily_hard_stop_blocks():
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("9550"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("-450"),
                            now=WED)
    assert v.tier == TIER_HARD_STOP
    assert not v.allowed


def test_max_drawdown_soft_stop():
    # 7.2% drawdown from peak -> SOFT_STOP.
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("9280"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=WED)
    assert v.tier == TIER_SOFT_STOP
    assert not v.allowed


def test_friday_close_blocks():
    friday_late = datetime(2026, 7, 10, 21, 0, tzinfo=timezone.utc)  # Fri 21:00 UTC
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=friday_late)
    assert v.tier == TIER_HARD_STOP
    assert not v.allowed
    assert any("Friday" in r for r in v.reasons)


def test_saturday_blocks():
    saturday = datetime(2026, 7, 11, 12, 0, tzinfo=timezone.utc)
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=saturday)
    assert not v.allowed
    assert any("Saturday" in r for r in v.reasons)


def test_sunday_before_open_blocks(monkeypatch):
    monkeypatch.setenv("PROP_SUNDAY_OPEN_HOUR_UTC", "21")
    monkeypatch.setenv("PROP_SUNDAY_OPEN_MINUTE_UTC", "0")
    sunday_am = datetime(2026, 7, 12, 8, 0, tzinfo=timezone.utc)  # Sunday 08:00
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=sunday_am)
    assert not v.allowed
    assert any("Sunday open" in r for r in v.reasons)


def test_sunday_after_open_trades():
    # Sunday 22:00 UTC (after the 21:00 open) -> weekend setups can be taken.
    sunday_pm = datetime(2026, 7, 12, 22, 0, tzinfo=timezone.utc)
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=sunday_pm)
    assert v.allowed
    assert v.tier == TIER_OK


def test_sunday_trading_can_be_disabled(monkeypatch):
    monkeypatch.setenv("PROP_SUNDAY_TRADING_ENABLED", "false")
    sunday_pm = datetime(2026, 7, 12, 22, 0, tzinfo=timezone.utc)
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=sunday_pm)
    assert not v.allowed


def test_news_window_blocks():
    event = NewsEvent(time=WED.timestamp() + 300, title="NFP", impact="high")  # +5 min
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=WED, news_events=[event])
    assert not v.allowed
    assert any("news" in r.lower() for r in v.reasons)


def test_news_outside_window_ok():
    event = NewsEvent(time=WED.timestamp() + 3600, title="NFP", impact="high")  # +60 min
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            now=WED, news_events=[event])
    assert v.tier == TIER_OK


def test_min_trading_days_tracked_but_never_blocks():
    v = evaluate_prop_guard(balance=Decimal("10000"), equity=Decimal("10000"),
                            peak_equity=Decimal("10000"), realised_pnl_today=Decimal("0"),
                            trading_days_completed=2, now=WED)
    assert v.checks["min_days_met"] is False
    assert v.allowed  # informational only


# -- Telegram anti-spam throttle -------------------------------------- #
def test_throttle_suppresses_duplicates():
    assert throttle.allow("k1", ttl=100) is True
    assert throttle.allow("k1", ttl=100) is False  # within window -> suppressed
    assert throttle.allow("k2", ttl=100) is True   # different key -> allowed


def test_throttle_zero_ttl_always_allows():
    assert throttle.allow("x", ttl=0) is True
    assert throttle.allow("x", ttl=0) is True


def test_broadcast_prop_guard_throttled(monkeypatch):
    from apps.telegram_bot import services

    monkeypatch.setenv("TELEGRAM_RISK_ALERTS_ENABLED", "true")
    sent_calls = []
    monkeypatch.setattr(services, "_broadcast", lambda text, pref: (sent_calls.append(text) or 1))
    throttle.reset()

    n1 = services.broadcast_prop_guard("WARNING", ["Daily loss 3.20% -> WARNING."], {})
    n2 = services.broadcast_prop_guard("WARNING", ["Daily loss 3.20% -> WARNING."], {})
    assert n1 == 1        # first alert sent
    assert n2 == 0        # duplicate suppressed (anti-spam)
    assert len(sent_calls) == 1
