"""Tests for the data-integrity (stale data) guard and the M69 resampler."""
import time
from decimal import Decimal

import pytest

from apps.broker.adapters.simulated import SimulatedBroker
from apps.trading.engines.base import Candle
from apps.trading.engines.data_integrity import (
    StaleDataError,
    check_quote_freshness,
    require_fresh_quote,
)
from apps.trading.engines.resampler import CustomResampler


# -- Stale-data guard -------------------------------------------------- #
def test_fresh_quote_passes():
    broker = SimulatedBroker()
    broker.connect()
    report = check_quote_freshness(broker, "EURUSD", threshold_ms=500)
    assert report.fresh
    assert report.latency_ms <= 500


def test_stale_quote_detected():
    broker = SimulatedBroker()
    broker.connect()
    # Simulate "now" being 3 seconds in the future -> 3000ms latency.
    future = time.time() + 3.0
    report = check_quote_freshness(broker, "EURUSD", threshold_ms=500, now=future)
    assert not report.fresh
    assert report.latency_ms >= 2500
    assert "exceeds" in report.reason


def test_require_fresh_raises_on_stale(monkeypatch):
    broker = SimulatedBroker()
    broker.connect()

    real = check_quote_freshness

    def stale(*args, **kwargs):
        kwargs["now"] = time.time() + 5
        return real(*args, **kwargs)

    monkeypatch.setattr(
        "apps.trading.engines.data_integrity.check_quote_freshness", stale
    )
    with pytest.raises(StaleDataError):
        require_fresh_quote(broker, "EURUSD", threshold_ms=500)


# -- M69 resampler ----------------------------------------------------- #
def _m1(n: int, start: int = 0):
    bars = []
    price = Decimal("100")
    for i in range(n):
        o = price
        c = price + Decimal("0.1")
        bars.append(Candle(start + i * 60, o, c + Decimal("0.2"), o - Decimal("0.1"), c))
        price = c
    return bars


def test_resample_69_minute_bars():
    bars = _m1(138)  # exactly two 69-minute buckets
    r = CustomResampler(period_minutes=69)
    out = r.resample(bars)
    assert len(out) == 2
    # First bucket open == first M1 open; close == 69th M1 close.
    assert out[0].open == bars[0].open
    assert out[0].close == bars[68].close
    # High/low are the extremes across the bucket.
    assert out[0].high == max(b.high for b in bars[:69])
    assert out[0].low == min(b.low for b in bars[:69])


def test_resampler_cache_hit_and_bounded():
    r = CustomResampler(period_minutes=69, max_entries=3, ttl_seconds=3600)
    bars = _m1(138)
    first = r.resample_cached("EURUSD", bars)
    assert r.cache_size == 1
    # Same input -> cache hit (identical output).
    again = r.resample_cached("EURUSD", bars)
    assert again == first
    assert r.cache_size == 1
    # Distinct inputs beyond the cap evict oldest entries.
    for i in range(5):
        r.resample_cached(f"SYM{i}", _m1(138, start=i * 100000))
    assert r.cache_size <= 3


def test_resampler_purges_stale_entries():
    r = CustomResampler(period_minutes=69, ttl_seconds=3600)
    now = time.time()
    r.resample_cached("EURUSD", _m1(138), now=now)
    assert r.cache_size == 1
    # Purge with a clock 2 hours later -> entry released.
    removed = r.purge_stale(now=now + 7200)
    assert removed == 1
    assert r.cache_size == 0
