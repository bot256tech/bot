"""Tests for the market scanner (full-universe, liquidity-filtered)."""
from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.broker.adapters.simulated import SimulatedBroker
from apps.broker.factory import reset_broker
from apps.trading.engines.scanner import scan_universe


@pytest.fixture(autouse=True)
def _reset():
    reset_broker()
    yield
    reset_broker()


def test_scan_covers_many_symbols():
    broker = SimulatedBroker()
    broker.connect()
    symbols = broker.list_symbols()
    assert len(symbols) > 10  # not just XAU/BTC
    rows = scan_universe(broker, symbols, min_score=Decimal("0"))
    scanned = {r.symbol for r in rows}
    # A broad set of asset classes is represented.
    assert "EURUSD" in scanned
    assert "XAUUSD" in scanned
    assert "NAS100" in scanned
    assert "BTCUSD" in scanned
    assert len(scanned) == len(symbols)


def test_scan_results_ranked_by_score():
    broker = SimulatedBroker()
    broker.connect()
    rows = scan_universe(broker, broker.list_symbols(), min_score=Decimal("0"))
    tradable = [r for r in rows if r.tradable]
    scores = [r.score for r in tradable]
    assert scores == sorted(scores, reverse=True)


def test_scan_reports_spread_and_volume_flags():
    broker = SimulatedBroker()
    broker.connect()
    rows = scan_universe(broker, ["EURUSD", "BTCUSD"], min_score=Decimal("0"))
    for r in rows:
        assert hasattr(r, "spread_ok")
        assert hasattr(r, "volume_ok")
        assert r.spread_points >= 0


def test_scan_api(db):
    User.objects.create_user(email="scan@example.com", password="StrongPass123!")
    c = APIClient()
    token = c.post("/api/v1/auth/login/",
                   {"email": "scan@example.com", "password": "StrongPass123!"},
                   format="json").data["access"]
    c.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    r = c.get("/api/v1/trading/scan/?min_score=0")
    assert r.status_code == 200, r.content
    assert "results" in r.data
    assert r.data["scanned"] >= 1
