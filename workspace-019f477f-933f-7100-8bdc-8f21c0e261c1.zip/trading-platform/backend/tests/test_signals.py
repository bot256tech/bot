"""End-to-end tests for the signals vertical slice."""
import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.broker.factory import reset_broker
from apps.core.roles import Role
from apps.signals.models import Signal, SignalStatus
from apps.signals.services import evaluate_active_signals, generate_signal_from_market


@pytest.fixture(autouse=True)
def _reset_broker():
    reset_broker()
    yield
    reset_broker()


@pytest.fixture
def trader(db):
    return User.objects.create_user(
        email="trader@example.com", password="StrongPass123!", role=Role.TRADER
    )


@pytest.fixture
def auth_client(trader):
    client = APIClient()
    resp = client.post(
        "/api/v1/auth/login/",
        {"email": "trader@example.com", "password": "StrongPass123!"},
        format="json",
    )
    assert resp.status_code == 200, resp.content
    token = resp.data["access"]
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    return client


# -- service layer ------------------------------------------------------ #
def test_generate_signal_from_market(db, trader):
    signal = generate_signal_from_market("EURUSD", created_by=trader)
    assert signal.status == SignalStatus.ACTIVE
    assert signal.symbol == "EURUSD"
    assert signal.risk_reward is not None
    # SL/TP consistency
    if signal.direction == "buy":
        assert signal.stop_loss < signal.entry_price < signal.take_profit
    else:
        assert signal.take_profit < signal.entry_price < signal.stop_loss


def test_evaluate_closes_signal_on_tp(db):
    # Force an immediate TP by setting an already-passed target.
    from decimal import Decimal

    from apps.broker.factory import get_broker

    broker = get_broker()
    price = (broker.get_quote("EURUSD").bid + broker.get_quote("EURUSD").ask) / 2
    sig = Signal.objects.create(
        symbol="EURUSD",
        direction="buy",
        entry_price=price - Decimal("0.01"),
        stop_loss=price - Decimal("0.02"),
        take_profit=price - Decimal("0.005"),  # already below current price -> TP hit
        status=SignalStatus.ACTIVE,
    )
    changed = evaluate_active_signals(broker=broker)
    sig.refresh_from_db()
    assert changed >= 1
    assert sig.status == SignalStatus.HIT_TP


# -- API layer ---------------------------------------------------------- #
def test_api_generate_and_list(auth_client):
    resp = auth_client.post(
        "/api/v1/signals/generate/", {"symbol": "GBPUSD"}, format="json"
    )
    assert resp.status_code == 201, resp.content
    assert resp.data["symbol"] == "GBPUSD"

    lst = auth_client.get("/api/v1/signals/")
    assert lst.status_code == 200
    assert lst.data["count"] >= 1


def test_api_requires_auth():
    client = APIClient()
    resp = client.get("/api/v1/signals/")
    assert resp.status_code == 401


def test_subscriber_cannot_create_signal(db):
    User.objects.create_user(
        email="sub@example.com", password="StrongPass123!", role=Role.SUBSCRIBER
    )
    client = APIClient()
    token = client.post(
        "/api/v1/auth/login/",
        {"email": "sub@example.com", "password": "StrongPass123!"},
        format="json",
    ).data["access"]
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    resp = client.post("/api/v1/signals/generate/", {"symbol": "EURUSD"}, format="json")
    assert resp.status_code == 403
