"""Tests for Telegram linking, verification, and broadcast (network mocked)."""
from unittest.mock import patch

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.telegram_bot import services
from apps.telegram_bot.models import TelegramSubscriber


@pytest.fixture
def user(db):
    return User.objects.create_user(email="tg@example.com", password="StrongPass123!")


@pytest.fixture
def client(user):
    c = APIClient()
    token = c.post(
        "/api/v1/auth/login/",
        {"email": "tg@example.com", "password": "StrongPass123!"},
        format="json",
    ).data["access"]
    c.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    return c


def test_link_returns_code(client):
    r = client.post("/api/v1/telegram/link/")
    assert r.status_code == 201
    assert len(r.data["verification_code"]) == 8
    assert TelegramSubscriber.objects.filter(is_verified=False).count() == 1


def test_confirm_link_verifies_subscriber(user):
    sub = services.start_link(user)
    with patch("apps.telegram_bot.client.is_configured", return_value=False):
        ok = services.confirm_link(sub.verification_code, "123456", "tester")
    assert ok
    sub.refresh_from_db()
    assert sub.is_verified
    assert sub.chat_id == "123456"


def test_webhook_verify_command(client, user):
    sub = services.start_link(user)
    webhook = APIClient()
    with patch("apps.telegram_bot.client.is_configured", return_value=False):
        r = webhook.post(
            "/api/v1/telegram/webhook/anything/",
            {"message": {"text": f"/verify {sub.verification_code}",
                         "chat": {"id": 999, "username": "u"}}},
            format="json",
        )
    assert r.status_code == 200
    assert r.data["linked"] is True


def test_broadcast_signal_sends_to_verified(user):
    sub = services.start_link(user)
    with patch("apps.telegram_bot.client.is_configured", return_value=False):
        services.confirm_link(sub.verification_code, "555", "u")

    class FakeSignal:
        symbol = "EURUSD"
        direction = "buy"
        entry_price = "1.1000"
        stop_loss = "1.0980"
        take_profit = "1.1040"
        confidence = "70"
        strategy = "crt"
        risk_reward = "2.0"

    with patch("apps.telegram_bot.client.is_configured", return_value=True), \
         patch("apps.telegram_bot.client.send_message") as send:
        sent = services.broadcast_signal(FakeSignal())
    assert sent == 1
    send.assert_called_once()
