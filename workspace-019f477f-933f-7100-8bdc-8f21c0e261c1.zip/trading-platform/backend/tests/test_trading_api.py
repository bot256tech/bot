"""Integration tests for the trading API and execution pipeline."""
import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.broker.factory import reset_broker
from apps.core.roles import Role
from apps.trading.models import Trade


@pytest.fixture(autouse=True)
def _reset_broker():
    reset_broker()
    yield
    reset_broker()


@pytest.fixture
def client(db):
    User.objects.create_user(
        email="t@example.com", password="StrongPass123!", role=Role.TRADER
    )
    c = APIClient()
    token = c.post(
        "/api/v1/auth/login/",
        {"email": "t@example.com", "password": "StrongPass123!"},
        format="json",
    ).data["access"]
    c.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    return c


def test_analyze_returns_score(client):
    r = client.get("/api/v1/trading/analyze/?symbol=EURUSD&timeframe=M5")
    assert r.status_code == 200
    assert "score" in r.data
    assert len(r.data["breakdown"]) == 8


def test_broker_symbol_intelligence(client):
    r = client.get("/api/v1/broker/symbol/?symbol=BTCUSD")
    assert r.status_code == 200
    assert r.data["symbol"] == "BTCUSD"
    assert "tick_value" in r.data
    assert "contract_size" in r.data
    assert isinstance(r.data["filling_modes"], list)


def test_execute_persists_trade_with_audit(client):
    r = client.post(
        "/api/v1/trading/trades/execute/",
        {"symbol": "EURUSD", "min_score": 0, "place_order": False},
        format="json",
    )
    assert r.status_code == 201, r.content
    assert r.data["decision_audit"]["stages"]
    assert Trade.objects.count() == 1


def test_execute_with_order_placement(client):
    r = client.post(
        "/api/v1/trading/trades/execute/",
        {"symbol": "XAUUSD", "min_score": 0, "place_order": True, "mode": "auto"},
        format="json",
    )
    assert r.status_code == 201, r.content
    # Either executed (open + ticket) or rejected by risk/sizing — both audited.
    assert "stages" in r.data["decision_audit"]


def test_risk_profile_roundtrip(client):
    r = client.get("/api/v1/trading/risk-profile/")
    assert r.status_code == 200
    assert r.data["mode"] == "fixed"
    r2 = client.patch(
        "/api/v1/trading/risk-profile/",
        {"mode": "confidence", "base_risk_percent": "1.5"},
        format="json",
    )
    assert r2.status_code == 200
    assert r2.data["mode"] == "confidence"
