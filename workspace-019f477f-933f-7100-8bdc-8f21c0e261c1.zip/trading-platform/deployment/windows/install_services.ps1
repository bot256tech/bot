# -----------------------------------------------------------------------------
# install_services.ps1
# Registers all platform components as Windows services using NSSM.
#
# Prerequisites (installed & on PATH):
#   - Python 3.13+          - Node.js 18+/20+
#   - PostgreSQL 15+        - Redis for Windows (Memurai or redis-windows)
#   - NSSM (https://nssm.cc)
#
# Run this script from an elevated (Administrator) PowerShell prompt.
# Edit $Root and $NssmPath below to match your installation.
# -----------------------------------------------------------------------------
param(
    [string]$Root = "C:\trading-platform",
    [string]$NssmPath = "C:\nssm\nssm.exe"
)

$ErrorActionPreference = "Stop"

function New-PlatformService {
    param(
        [string]$Name,
        [string]$Script,
        [string]$LogFile
    )
    Write-Host "Installing service: $Name"
    & $NssmPath install $Name "powershell.exe" `
        "-ExecutionPolicy Bypass -NoProfile -File `"$Root\scripts\$Script`""
    & $NssmPath set $Name AppDirectory $Root
    & $NssmPath set $Name Start SERVICE_AUTO_START
    & $NssmPath set $Name AppStdout "$Root\logs\$LogFile"
    & $NssmPath set $Name AppStderr "$Root\logs\$LogFile"
    & $NssmPath set $Name AppRotateFiles 1
    & $NssmPath set $Name AppRotateBytes 10485760
    & $NssmPath set $Name AppExit Default Restart
}

New-PlatformService -Name "TradeDesk-Backend"      -Script "run_backend.ps1"       -LogFile "svc_backend.log"
New-PlatformService -Name "TradeDesk-CeleryWorker" -Script "run_celery_worker.ps1" -LogFile "svc_worker.log"
New-PlatformService -Name "TradeDesk-CeleryBeat"   -Script "run_celery_beat.ps1"   -LogFile "svc_beat.log"
New-PlatformService -Name "TradeDesk-Frontend"     -Script "run_frontend.ps1"      -LogFile "svc_frontend.log"

Write-Host ""
Write-Host "All services installed. Start them with:"
Write-Host "  nssm start TradeDesk-Backend"
Write-Host "  nssm start TradeDesk-CeleryWorker"
Write-Host "  nssm start TradeDesk-CeleryBeat"
Write-Host "  nssm start TradeDesk-Frontend"
Write-Host ""
Write-Host "Remember: the MT5 terminal must be running & logged in for BROKER_ADAPTER=mt5."
