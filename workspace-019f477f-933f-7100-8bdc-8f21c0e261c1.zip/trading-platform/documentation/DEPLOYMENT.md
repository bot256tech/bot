# Deployment Guide — Windows VPS (NSSM, no Docker)

This deploys all four components as auto-starting Windows services managed by
**NSSM**, with **PostgreSQL** and **Redis** running natively. MetaTrader 5 runs
as a normal desktop application logged into your broker account.

## Architecture

```
                       ┌───────────────────────────┐
   Browser  ── HTTPS ─▶│  IIS / nginx (reverse proxy)│
                       └────────────┬──────────────┘
                    /api, /ws       │        /
                        ┌───────────┴───────────┐
                        ▼                        ▼
              TradeDesk-Backend           TradeDesk-Frontend
              (Daphne, ASGI)              (Next.js, :3000)
                        │
        ┌───────────────┼───────────────┐
        ▼               ▼               ▼
   PostgreSQL        Redis        MT5 Terminal
                        ▲
        ┌───────────────┴───────────────┐
   TradeDesk-CeleryWorker      TradeDesk-CeleryBeat
```

## 1. Install prerequisites on the VPS

- Python 3.13+, Node.js 20+
- PostgreSQL 15+ (create DB + user matching `.env`)
- Redis for Windows (**Memurai** recommended) — run as a service
- NSSM → https://nssm.cc (place `nssm.exe`, e.g. `C:\nssm\nssm.exe`)
- MetaTrader 5 terminal, logged into the broker account
- `pip install MetaTrader5` inside the backend venv

## 2. Deploy the code

```powershell
git clone <your-repo> C:\trading-platform
cd C:\trading-platform\backend
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
pip install MetaTrader5           # Windows only
copy .env.example .env            # edit: BROKER_ADAPTER=mt5, MT5_*, POSTGRES_*, USE_REDIS_CHANNELS=True, DJANGO_DEBUG=False
python manage.py migrate
python manage.py collectstatic --noinput

cd ..\frontend
npm ci
npm run build
```

## 3. Register services (elevated PowerShell)

```powershell
cd C:\trading-platform\deployment\windows
.\install_services.ps1 -Root "C:\trading-platform" -NssmPath "C:\nssm\nssm.exe"

nssm start TradeDesk-Backend
nssm start TradeDesk-CeleryWorker
nssm start TradeDesk-CeleryBeat
nssm start TradeDesk-Frontend
```

Each service auto-restarts on failure and writes rotating logs to
`C:\trading-platform\logs\`.

## 4. Reverse proxy (TLS + routing)

Terminate HTTPS at IIS (with URL Rewrite + ARR) or nginx and proxy:
- `/api/`  and `/ws/`  → `127.0.0.1:8000` (WebSocket upgrade headers required)
- everything else      → `127.0.0.1:3000`

Set `DJANGO_ALLOWED_HOSTS` and `CORS_ALLOWED_ORIGINS` to your domain, keep
`DJANGO_DEBUG=False` (this auto-enables HSTS, secure cookies, SSL redirect).

## 5. Health checks & validation

```powershell
Invoke-WebRequest http://127.0.0.1:8000/api/docs/ | Select StatusCode
Get-Service TradeDesk-*
```

## Your VPS: 194.37.80.107 (frontend on :3000)

The frontend is served on **port 3000** of the VPS. Configure so the browser can
reach the backend API:

1. **Backend `.env`** (`backend/.env`):
   ```
   DJANGO_DEBUG=False
   DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1,194.37.80.107
   CORS_ALLOWED_ORIGINS=http://194.37.80.107:3000
   BROKER_ADAPTER=mt5
   USE_REDIS_CHANNELS=True
   ```
   Run the backend (Daphne) on `0.0.0.0:8000`:
   ```powershell
   .\scripts\run_backend.ps1 -BindHost 0.0.0.0 -Port 8000
   ```

2. **Frontend `.env.production`** (`frontend/.env.production`):
   ```
   NEXT_PUBLIC_API_BASE=http://194.37.80.107:8000/api/v1
   NEXT_PUBLIC_WS_BASE=ws://194.37.80.107:8000/ws
   ```
   Then `npm run build` and start on port 3000:
   ```powershell
   .\scripts\run_frontend.ps1 -Port 3000
   ```

3. **Open firewall ports** 3000 (frontend) and 8000 (backend) on the VPS.

> For production you should put both behind a reverse proxy with TLS and a real
> domain; serving raw HTTP on 3000/8000 is fine for initial bring-up only.
> Since `DJANGO_DEBUG=False` enables `SECURE_SSL_REDIRECT`, keep it `True` only
> once TLS is in front — for plain-HTTP bring-up set `SECURE_SSL_REDIRECT=False`.

## Easiest startup: double-click the .cmd files

The project ships Windows batch files at the repo root so you never have to type
or paste commands. Just double-click them (in order the first time):

| File | What it does |
|------|--------------|
| `1_setup.cmd` | One-time: venv, install deps + MetaTrader5, create DB, migrate, superuser |
| `open_firewall.cmd` | Right-click → Run as admin: opens Windows ports 8000 & 3000 |
| `START_ALL.cmd` | Starts backend + worker + beat + frontend, each in its own window |
| `2_backend.cmd` | Backend only (Daphne on 0.0.0.0:8000) |
| `3_worker.cmd` | Celery worker only |
| `4_beat.cmd` | Celery beat only |
| `5_frontend.cmd` | Frontend only (Next.js on 0.0.0.0:3000) |
| `rebuild_frontend.cmd` | Rebuild after changing `frontend\.env.production` (VPS IP) |

**First-time flow on the VPS:**
1. Install Python, PostgreSQL, Redis/Memurai, Node.js, MetaTrader 5.
2. Double-click **`1_setup.cmd`** (creates everything + your admin login).
3. Right-click **`open_firewall.cmd`** → Run as administrator.
4. Open ports 8000 & 3000 in your cloud provider's firewall/security group.
5. Double-click **`START_ALL.cmd`**.
6. Browse `http://194.37.80.107:3000`.

Prerequisites that must be running before START_ALL: PostgreSQL, Redis/Memurai,
and (for live trading) the MT5 terminal logged in.

## Quick manual startup (run scripts AS FILES)

> **Do NOT paste script contents line-by-line into PowerShell.** `$PSScriptRoot`
> is only set when a `.ps1` runs as a file, and Celery must run from the backend
> dir with the venv active. Paste-mode causes `C:\backend not found` and
> `The module config was not found`.

Launch everything in one go (each part opens in its own window):
```powershell
powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\start_all.ps1
```

Or start each component individually (each in its own window):
```powershell
powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_backend.ps1
powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_celery_worker.ps1
powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_celery_beat.ps1
powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_frontend.ps1
```

Manual equivalents (if you prefer typing commands, note the `cd` + activate):
```powershell
cd C:\trading-platform\backend
.\.venv\Scripts\Activate.ps1
daphne -b 0.0.0.0 -p 8000 config.asgi:application     # backend (all interfaces)
# in another window (same cd + activate):
celery -A config worker --loglevel=info --pool=solo    # worker
celery -A config beat --loglevel=info                  # beat
# frontend:
cd C:\trading-platform\frontend
npm install ; npm run build ; npm run start -- -H 0.0.0.0 -p 3000
```

## "Failed to fetch" on login (frontend can't reach backend)

Two causes, both fixed by config:

1. **Backend bound to 127.0.0.1** — the browser can't reach it. Start Daphne
   with `-b 0.0.0.0` and confirm the log says `Listening on TCP address
   0.0.0.0:8000` (NOT 127.0.0.1). The run scripts now default to 0.0.0.0.

2. **Frontend built with the wrong API URL** — `NEXT_PUBLIC_*` is baked in at
   BUILD time. Ensure `frontend/.env.production` has:
   ```
   NEXT_PUBLIC_API_BASE=http://194.37.80.107:8000/api/v1
   NEXT_PUBLIC_WS_BASE=ws://194.37.80.107:8000/ws
   ```
   then **rebuild**: `cd frontend; npm run build; npm run start -- -H 0.0.0.0 -p 3000`.
   (The client also auto-falls back to the page's own host:8000 if the env is
   missing, so a rebuild after setting the file is the reliable fix.)

3. Forgot the login? Create/reset a superuser:
   `python manage.py createsuperuser` (email + a 10+ char, non-common password).

## "This site can't be reached" / ERR_CONNECTION_TIMED_OUT

If `http://194.37.80.107:3000` times out, work through these in order:
1. **Frontend running?** It must be started (`run_frontend.ps1`) and listening
   on `0.0.0.0`, not `127.0.0.1`.
2. **Windows Firewall** — open the ports (run as Administrator):
   ```powershell
   powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\open_firewall.ps1
   ```
3. **Cloud provider firewall** — MOST COMMON cause on a VPS. Open inbound TCP
   **3000** and **8000** in your provider's security group / network firewall
   panel (AWS Security Group, Azure NSG, Hetzner/Contabo firewall, etc.). The
   Windows firewall alone is not enough.
4. **Backend bound to 0.0.0.0** — use `daphne -b 0.0.0.0 -p 8000`, not 127.0.0.1.
5. Confirm from the VPS itself first: browse `http://127.0.0.1:3000` on the
   server. If that works but the public IP doesn't, it's a firewall (step 2/3).

## Notes on MT5

- The MT5 terminal **must stay running and logged in**; the service connects to
  the live terminal via the local API.
- To fail over to no-broker mode, set `BROKER_ADAPTER=simulated` and restart the
  backend + worker services.
