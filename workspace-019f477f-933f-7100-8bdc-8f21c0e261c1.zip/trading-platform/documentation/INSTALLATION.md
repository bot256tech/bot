# Installation Guide

This guide sets up the platform for **local development**. For production on a
Windows VPS see `DEPLOYMENT.md`.

## Prerequisites

| Component | Version | Notes |
|-----------|---------|-------|
| Python    | 3.13+   | Backend |
| Node.js   | 18+ / 20+ | Frontend |
| PostgreSQL| 15+     | Optional for dev (SQLite fallback exists) |
| Redis     | 7+      | Optional for dev; required for realtime/Celery in prod |

> On Windows, use **Memurai** or **redis-windows** for Redis. MetaTrader 5 is
> Windows-only; for local dev on any OS keep `BROKER_ADAPTER=simulated`.

## 1. Backend

```bash
cd backend
python -m venv .venv
# Windows:  .venv\Scripts\activate
# Linux/mac: source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env          # then edit values
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver     # dev (HTTP only)
```

For WebSocket support during development, run the ASGI server instead:

```bash
daphne -b 127.0.0.1 -p 8000 config.asgi:application
```

Visit:
- API docs: http://127.0.0.1:8000/api/docs/
- Admin:    http://127.0.0.1:8000/admin/

## 2. Frontend

```bash
cd frontend
npm install
npm run dev        # http://localhost:3000
```

Log in at `/` with the superuser (or a seeded analyst/trader) and open
`/signals` to generate and watch realtime signals.

## 3. Redis + Celery (optional in dev)

```bash
# terminal 1 — Redis
redis-server

# terminal 2 — worker
celery -A config worker --loglevel=info --pool=solo

# terminal 3 — beat (periodic signal evaluation)
celery -A config beat --loglevel=info
```

Set `USE_REDIS_CHANNELS=True` in `.env` to use Redis for WebSocket fan-out
(recommended once you run more than one process).

## Database setup (PostgreSQL)

Create the role + database before the first migration. The bundled provisioner
reads your `.env` and does this for you (needs a Postgres superuser):

```powershell
# Set the superuser password once for this shell (or add to .env as PG_SUPERPASSWORD)
$env:PG_SUPERPASSWORD = "your-postgres-superuser-password"
python init_db.py
python manage.py migrate
python manage.py createsuperuser
```

## Troubleshooting

### `password authentication failed for user "trading"`
The DB role/password doesn't match `.env`. Run `python init_db.py` (it creates
the role and **syncs its password** to `POSTGRES_PASSWORD`), or set it manually:
`ALTER ROLE trading WITH LOGIN PASSWORD '...';`

### `foreign key constraint ... incompatible types: uuid and bigint`
The database is **half-migrated** — an earlier run failed partway and left
inconsistent tables (the custom UUID `User` table wasn't created before other
tables referenced it). On a fresh deploy (no real data yet) reset the DB:

```powershell
$env:PG_SUPERPASSWORD = "your-postgres-superuser-password"
python init_db.py --reset      # DROP + recreate the empty database
python manage.py migrate       # applies cleanly in the correct app order
python manage.py createsuperuser
```

Or manually with psql:
```powershell
psql -U postgres -h 127.0.0.1 -c "DROP DATABASE IF EXISTS trading_platform;"
psql -U postgres -h 127.0.0.1 -c "CREATE DATABASE trading_platform OWNER trading;"
python manage.py migrate
```

This is safe because the schema migrates cleanly from empty; the error only
comes from residual tables of a previous failed attempt.

## Other troubleshooting

- **`Database access not allowed`** in tests → add the `db` fixture / mark.
- **WebSocket won't connect** → ensure you started `daphne` (not `runserver`
  alone) and passed `?token=<access_jwt>`.
- **MT5 errors on non-Windows** → keep `BROKER_ADAPTER=simulated`.
