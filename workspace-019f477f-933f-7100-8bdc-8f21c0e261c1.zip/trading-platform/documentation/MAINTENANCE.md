# Maintenance Guide

## Logs

Rotating per-domain logs live in `logs/`:

| File | Contents |
|------|----------|
| `trading.log` | Signal generation/evaluation, broker actions (logger `trading`) |
| `errors.log`  | All `ERROR`+ across the app |
| `svc_*.log`   | Per-NSSM-service stdout/stderr (Windows) |

Rotation: 10 MB × 5 backups (configured in `settings.LOGGING` and NSSM).

## Services (Windows / NSSM)

```powershell
nssm status  TradeDesk-Backend
nssm restart TradeDesk-Backend
nssm stop    TradeDesk-CeleryWorker
Get-Service  TradeDesk-*
```

Config lives in the service registration; re-run `install_services.ps1` after
changing a run script.

## Database

```bash
python manage.py migrate                 # apply new migrations
python manage.py makemigrations          # after model changes
pg_dump -Fc trading_platform > backup.dump   # backup
```

Soft-deleted rows remain in the DB (`is_deleted=True`). To query them use
`Model.all_objects`. Purge policy is a business decision — implement a periodic
Celery task if hard deletion is desired.

## Rotating secrets

- `DJANGO_SECRET_KEY`: rotating invalidates existing sessions (JWT is signed
  with it) — expect users to re-login.
- MT5 credentials: update `.env` and restart `TradeDesk-Backend` +
  `TradeDesk-CeleryWorker`.

## Monitoring & health

- Liveness: `GET /api/docs/` (200 = web tier up).
- Broker: `GET /api/v1/broker/account/` → `connected: true`.
- Worker: check `svc_worker.log` for periodic `signals.evaluate` runs (every 30s).
- Redis/Postgres: monitor via their own tooling (Memurai console / `pg_isready`).

## Upgrades

1. `git pull`
2. Backend: `pip install -r requirements.txt && python manage.py migrate && python manage.py collectstatic --noinput`
3. Frontend: `npm ci && npm run build`
4. `nssm restart TradeDesk-*`

## Common issues

| Symptom | Likely cause / fix |
|---------|--------------------|
| WS clients get code 4401 | Missing/expired `?token=`; refresh access token |
| Signals not auto-closing | Celery beat/worker not running; check `svc_beat.log` |
| `BrokerError: MetaTrader5 not installed` | Wrong OS or venv; set `BROKER_ADAPTER=simulated` or `pip install MetaTrader5` on Windows |
| 500s with generic message | See `logs/errors.log` for the stack trace |
