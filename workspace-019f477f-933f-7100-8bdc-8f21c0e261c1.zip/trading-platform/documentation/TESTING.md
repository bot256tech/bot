# Testing Guide

The platform ships with a pytest suite covering the broker abstraction and the
full signals vertical slice (service layer + REST API + RBAC).

## Run the backend suite

```bash
cd backend
python -m pytest            # verbose
python -m pytest -q         # quiet
python -m pytest tests/test_signals.py::test_api_generate_and_list
```

Current suite (9 tests, all passing):

| Area | Tests |
|------|-------|
| Broker | protocol conformance, connect/quote, place+close, reject when disconnected |
| Signals service | generate-from-market, TP evaluation & auto-close |
| Signals API | generate+list, auth required (401), RBAC (subscriber 403) |

Tests run against the **simulated** broker with a **seeded** price feed, so they
are deterministic and require no Postgres, Redis, or MT5.

## Frontend checks

```bash
cd frontend
npm run typecheck     # tsc --noEmit  (currently: 0 errors)
npm run build         # production build (currently: succeeds, 6 routes)
npm run lint
```

## OpenAPI schema validation

```bash
cd backend
python manage.py spectacular --file schema.yml
# Expect: Errors 0, Warnings 0
```

## Writing new tests

Follow `tests/test_signals.py`:
- Use the `db` fixture (or `@pytest.mark.django_db`) for DB access.
- Reset the broker singleton between tests with `reset_broker()` (see the
  autouse fixture) so state never leaks.
- Prefer testing the **service layer** for business logic and the **API layer**
  for auth/serialization/permissions.

## Continuous integration (suggested)

```yaml
# .github/workflows/ci.yml (sketch)
- run: pip install -r backend/requirements.txt
- run: cd backend && python -m pytest -q
- run: cd frontend && npm ci && npm run typecheck && npm run build
```
