"use client";

import { useQuery } from "@tanstack/react-query";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { api } from "@/lib/api";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);

export default function AnalyticsPage() {
  const { data, isLoading } = useQuery({
    queryKey: ["analytics"],
    queryFn: () => api.analytics(),
  });

  const curve = data?.equity_curve ?? [];
  const chartData = {
    labels: curve.map((_, i) => `#${i + 1}`),
    datasets: [
      {
        label: "Equity",
        data: curve.map((c) => Number(c.equity)),
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59,130,246,0.15)",
        fill: true,
        tension: 0.25,
        pointRadius: 0,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Performance Analytics</h1>
        <p className="text-sm text-muted">Computed from your closed trades</p>
      </header>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Metric label="Total trades" value={data?.total_trades ?? "…"} />
        <Metric label="Win rate" value={data ? `${data.win_rate}%` : "…"} accent />
        <Metric label="Profit factor" value={data?.profit_factor ?? "…"} />
        <Metric label="Expectancy" value={data ? `$${data.expectancy}` : "…"} />
        <Metric
          label="Net profit"
          value={data ? `$${data.net_profit}` : "…"}
          tone={data && Number(data.net_profit) >= 0 ? "up" : "down"}
        />
        <Metric label="Max drawdown" value={data ? `$${data.max_drawdown}` : "…"} tone="down" />
        <Metric label="Avg R:R" value={data?.avg_rr ?? "…"} />
        <Metric label="Loss rate" value={data ? `${data.loss_rate}%` : "…"} />
      </div>

      <div className="glass rounded-xl p-5">
        <h2 className="mb-3 text-sm font-semibold uppercase text-muted">Equity curve</h2>
        {isLoading ? (
          <div className="h-64 animate-pulse rounded bg-white/5" />
        ) : curve.length ? (
          <div className="h-64">
            <Line
              data={chartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  x: { grid: { color: "#1e2637" }, ticks: { color: "#8592a6" } },
                  y: { grid: { color: "#1e2637" }, ticks: { color: "#8592a6" } },
                },
                plugins: { legend: { display: false } },
              }}
            />
          </div>
        ) : (
          <p className="py-12 text-center text-sm text-muted">
            No closed trades yet — run the pipeline and close positions to see analytics.
          </p>
        )}
      </div>

      <div className="glass overflow-hidden rounded-xl">
        <div className="border-b border-border px-4 py-3 text-sm font-semibold uppercase text-muted">
          Per-symbol performance
        </div>
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted">
            <tr className="border-b border-border">
              <th className="px-4 py-2">Symbol</th>
              <th className="px-4 py-2">Trades</th>
              <th className="px-4 py-2">Win rate</th>
              <th className="px-4 py-2">Net</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(data?.by_symbol ?? {}).map(([sym, s]) => (
              <tr key={sym} className="border-b border-border hover:bg-white/5">
                <td className="px-4 py-2 font-medium">{sym}</td>
                <td className="px-4 py-2">{s.trades}</td>
                <td className="px-4 py-2">{s.win_rate}%</td>
                <td className={`px-4 py-2 ${Number(s.net) >= 0 ? "text-up" : "text-down"}`}>
                  ${s.net}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!data || Object.keys(data.by_symbol).length === 0 ? (
          <p className="p-6 text-center text-sm text-muted">No data.</p>
        ) : null}
      </div>
    </div>
  );
}

function Metric({ label, value, accent, tone }: {
  label: string; value: string | number; accent?: boolean; tone?: "up" | "down";
}) {
  const color = tone === "up" ? "text-up" : tone === "down" ? "text-down" : accent ? "text-accent" : "";
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-xs uppercase text-muted">{label}</div>
      <div className={`mt-1 text-xl font-bold ${color}`}>{value}</div>
    </div>
  );
}
