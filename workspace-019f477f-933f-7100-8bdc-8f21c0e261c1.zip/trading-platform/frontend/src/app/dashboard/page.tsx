"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export default function DashboardPage() {
  const { data: account } = useQuery({
    queryKey: ["broker-account"],
    queryFn: () => api.brokerAccount(),
  });
  const { data: signals } = useQuery({
    queryKey: ["signals"],
    queryFn: () => api.listSignals(),
  });
  const { data: profile } = useQuery({
    queryKey: ["active-profile"],
    queryFn: () => api.activeProfile(),
    refetchInterval: 15000,
  });
  const { data: scan } = useQuery({
    queryKey: ["scan", "dashboard"],
    queryFn: () => api.scan({ timeframe: "M5", min_score: 0, max_results: 6 }),
    refetchInterval: 20000,
  });

  const tier = profile?.prop_guard?.tier;
  const tierColor =
    tier === "HARD_STOP" || tier === "SOFT_STOP"
      ? "text-down"
      : tier === "WARNING"
        ? "text-yellow-400"
        : "text-up";

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>

      {profile && (
        <div className="glass flex flex-wrap items-center justify-between gap-4 rounded-xl p-4">
          <div>
            <div className="text-xs uppercase text-muted">Active profile</div>
            <div className="text-lg font-bold">
              {profile.name === "PROP" ? "🏦 Prop Firm" : "🌱 Small Account"}
              <span className="ml-2 text-sm font-normal text-muted">
                equity ${Number(profile.account_equity).toLocaleString()} · threshold $
                {profile.threshold}
              </span>
            </div>
          </div>
          <div className="flex gap-6 text-sm">
            <div>
              <div className="text-xs uppercase text-muted">Risk / trade</div>
              <div className="font-semibold">{profile.risk_percent}%</div>
            </div>
            <div>
              <div className="text-xs uppercase text-muted">Trades today</div>
              <div className="font-semibold">
                {profile.trades_today}/{profile.max_daily_trades}
              </div>
            </div>
            {profile.prop_guard && (
              <div>
                <div className="text-xs uppercase text-muted">Prop guard</div>
                <div className={`font-semibold ${tierColor}`}>
                  {profile.prop_guard.tier.replace("_", " ")}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {profile?.prop_guard && profile.prop_guard.tier !== "OK" && (
        <div className="rounded-xl border border-down/40 bg-down/10 p-3 text-sm text-down">
          {profile.prop_guard.reasons.join(" ")}
        </div>
      )}
      <div className="grid grid-cols-4 gap-4">
        <Card label="Balance" value={account ? `$${account.balance}` : "…"} />
        <Card label="Equity" value={account ? `$${account.equity}` : "…"} />
        <Card
          label="Broker"
          value={account?.connected ? "Connected" : "…"}
          accent
        />
        <Card label="Signals" value={signals?.count ?? "…"} />
      </div>
      {/* Top setups preview (full view on the Scanner page) */}
      <div className="glass overflow-hidden rounded-xl">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <span className="text-sm font-semibold uppercase text-muted">
            Top setups {scan ? `(${scan.tradable} tradable of ${scan.scanned})` : ""}
          </span>
          <Link href="/scanner" className="text-xs text-accent hover:underline">
            Open Scanner →
          </Link>
        </div>
        <table className="w-full text-sm">
          <tbody>
            {(scan?.results ?? []).slice(0, 6).map((r) => (
              <tr key={r.symbol} className="border-b border-border last:border-0">
                <td className="px-4 py-2 font-medium">{r.symbol}</td>
                <td className="px-4 py-2">
                  <span
                    className={
                      Number(r.score) >= 60
                        ? "text-up"
                        : Number(r.score) >= 40
                          ? "text-accent"
                          : "text-muted"
                    }
                  >
                    {Number(r.score).toFixed(2)}
                  </span>
                </td>
                <td className="px-4 py-2">
                  <span className={r.bias === "bullish" ? "text-up" : r.bias === "bearish" ? "text-down" : "text-muted"}>
                    {r.bias}
                  </span>
                </td>
                <td className="px-4 py-2 text-right text-muted">{r.spread_points} pts</td>
              </tr>
            ))}
            {!scan && (
              <tr>
                <td className="px-4 py-4 text-muted">Loading scan…</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="glass rounded-xl p-6 text-sm text-muted">
        Welcome to the institutional trading desk. Use the Signals page to
        generate and monitor live trading signals in realtime.
      </div>
    </div>
  );
}

function Card({
  label,
  value,
  accent,
}: {
  label: string;
  value: string | number;
  accent?: boolean;
}) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-xs uppercase text-muted">{label}</div>
      <div className={`mt-1 text-xl font-bold ${accent ? "text-up" : ""}`}>
        {value}
      </div>
    </div>
  );
}
