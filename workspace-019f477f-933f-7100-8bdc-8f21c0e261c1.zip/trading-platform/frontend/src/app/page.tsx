"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/store/auth";

export default function LoginPage() {
  const router = useRouter();
  const { login, loading, user } = useAuth();
  const [email, setEmail] = useState("analyst@example.com");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  if (user) router.replace("/signals");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await login(email, password);
      router.push("/signals");
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <div className="flex min-h-[80vh] items-center justify-center">
      <form
        onSubmit={submit}
        className="glass w-full max-w-sm space-y-4 rounded-2xl p-8"
      >
        <h1 className="text-xl font-bold">
          <span className="text-accent">◆</span> TradeDesk Login
        </h1>
        <div>
          <label className="mb-1 block text-xs text-muted">Email</label>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border border-border bg-black/30 px-3 py-2 text-sm outline-none focus:border-accent"
          />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg border border-border bg-black/30 px-3 py-2 text-sm outline-none focus:border-accent"
          />
        </div>
        {error && <p className="text-sm text-down">{error}</p>}
        <button
          disabled={loading}
          className="w-full rounded-lg bg-accent py-2 text-sm font-semibold text-white disabled:opacity-50"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </div>
  );
}
