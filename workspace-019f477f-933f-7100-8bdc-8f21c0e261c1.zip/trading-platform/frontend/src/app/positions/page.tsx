"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, ScoreBreakdown } from "@/lib/api";
import { canAuthorSignals, useAuth } from "@/store/auth";

const FALLBACK_SYMBOLS = [
  "EURUSDm", "GBPUSDm", "USDJPYm", "XAUUSDm", "US30m", "NAS100m",
  "BTCUSDm", "ETHUSDm", "SOLUSDm",
];

export default function PositionsPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [minScore, setMinScore] = useState(0);
  const [placeOrder, setPlaceOrder] = useState(true);
  const [analysis, setAnalysis] = useState<ScoreBreakdown | null>(null);

  // Pull the REAL broker symbols from the scanner so the dropdown matches the
  // broker's naming (e.g. EURUSDm, not EURUSD). Falls back to a static list.
  const { data: scanForSymbols } = useQuery({
    queryKey: ["scan-symbols"],
    queryFn: () => api.scan({ timeframe: "H1", min_score: 0, max_results: 100 }),
    staleTime: 60000,
  });
  const symbols =
    scanForSymbols?.results?.map((r) => r.symbol) ?? FALLBACK_SYMBOLS;

  const [symbol, setSymbol] = useState("");
  const activeSymbol = symbol || symbols[0] || "EURUSDm";

  const { data: positions } = useQuery({
    queryKey: ["positions"],
    queryFn: () => api.positions(),
    refetchInterval: 4000,
  });
  const { data: account } = useQuery({
    queryKey: ["broker-account"],
    queryFn: () => api.brokerAccount(),
    refetchInterval: 5000,
  });

  const analyzeMut = useMutation({
    mutationFn: () => api.analyze(activeSymbol),
    onSuccess: setAnalysis,
  });
  const executeMut = useMutation({
    mutationFn: () =>
      api.execute({ symbol: activeSymbol, min_score: minScore, place_order: placeOrder, mode: "auto" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["positions"] });
      qc.invalidateQueries({ queryKey: ["broker-account"] });
      qc.invalidateQueries({ queryKey: ["trades"] });
    },
  });

  const lastTrade = executeMut.data;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Positions & Execution</h1>
        <p className="text-sm text-muted">
          Broker-aware order placement via the Romeo TPT pipeline
        </p>
      </header>

      {/* Account strip */}
      <div className="grid grid-cols-4 gap-4">
        <Stat label="Balance" value={account ? `$${money(account.balance)}` : "…"} />
        <Stat label="Equity" value={account ? `$${money(account.equity)}` : "…"} />
        <Stat label="Free margin" value={account ? `$${money(account.free_margin)}` : "…"} />
        <Stat
          label="Broker"
          value={account?.broker_name ?? "…"}
          sub={account ? `${account.server} · 1:${account.leverage}` : ""}
          accent={account?.connected}
        />
      </div>

      {/* Order ticket */}
      {canAuthorSignals(user?.role) && (
        <div className="glass rounded-xl p-5">
          <h2 className="mb-3 text-sm font-semibold uppercase text-muted">
            New order
          </h2>
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Symbol">
              <select
                value={activeSymbol}
                onChange={(e) => setSymbol(e.target.value)}
                className="rounded-lg border border-border bg-panel px-3 py-2 text-sm"
              >
                {symbols.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </Field>
            <Field label="Min score">
              <input
                type="number"
                value={minScore}
                onChange={(e) => setMinScore(Number(e.target.value))}
                className="w-24 rounded-lg border border-border bg-black/30 px-3 py-2 text-sm"
              />
            </Field>
            <label className="flex items-center gap-2 py-2 text-sm text-muted">
              <input
                type="checkbox"
                checked={placeOrder}
                onChange={(e) => setPlaceOrder(e.target.checked)}
              />
              Place order (uncheck = dry-run)
            </label>
            <button
              onClick={() => analyzeMut.mutate()}
              className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-white/5"
            >
              {analyzeMut.isPending ? "Analyzing…" : "Analyze"}
            </button>
            <button
              onClick={() => executeMut.mutate()}
              disabled={executeMut.isPending}
              className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
            >
              {executeMut.isPending ? "Running…" : "Run pipeline"}
            </button>
          </div>

          {executeMut.isError && (
            <p className="mt-3 text-sm text-down">
              {(executeMut.error as Error).message}
            </p>
          )}

          {/* Analysis breakdown */}
          {analysis && (
            <div className="mt-4 rounded-lg border border-border p-3">
              <div className="mb-2 flex items-center gap-3 text-sm">
                <span>Score: <b>{analysis.score}</b></span>
                <span className={biasColor(analysis.bias)}>{analysis.bias}</span>
                <span className="text-muted">alignment {analysis.alignment}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {analysis.breakdown.map((b) => (
                  <span
                    key={b.engine}
                    className={`rounded-full px-2 py-1 text-xs ${
                      b.detected ? "bg-accent/20 text-accent" : "bg-white/5 text-muted"
                    }`}
                  >
                    {b.engine} {b.detected ? "✓" : "·"}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Last decision audit */}
          {lastTrade && (
            <div className="mt-4 rounded-lg border border-border p-3 text-sm">
              <div className="mb-2">
                Result:{" "}
                <span className={statusColor(lastTrade.status)}>
                  {lastTrade.status.toUpperCase()}
                </span>{" "}
                {lastTrade.side?.toUpperCase()} {lastTrade.symbol} · {lastTrade.volume} lots ·
                risk {lastTrade.risk_percent}%
              </div>
              <div className="flex flex-wrap gap-1">
                {lastTrade.decision_audit.stages?.map((s) => (
                  <span
                    key={s.stage}
                    className={`rounded px-2 py-0.5 text-xs ${
                      s.passed ? "bg-up/20 text-up" : "bg-down/20 text-down"
                    }`}
                  >
                    {s.stage} {s.passed ? "✓" : "✗"}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Open positions */}
      <div className="glass overflow-hidden rounded-xl">
        <div className="border-b border-border px-4 py-3 text-sm font-semibold uppercase text-muted">
          Open positions
        </div>
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted">
            <tr className="border-b border-border">
              <th className="px-4 py-2">Ticket</th>
              <th className="px-4 py-2">Symbol</th>
              <th className="px-4 py-2">Side</th>
              <th className="px-4 py-2">Volume</th>
              <th className="px-4 py-2">Open</th>
              <th className="px-4 py-2">Current</th>
              <th className="px-4 py-2">P&L</th>
            </tr>
          </thead>
          <tbody>
            {(positions ?? []).map((p) => (
              <motion.tr
                key={p.ticket}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="border-b border-border hover:bg-white/5"
              >
                <td className="px-4 py-2 text-muted">{p.ticket}</td>
                <td className="px-4 py-2 font-medium">{p.symbol}</td>
                <td className={`px-4 py-2 ${p.side === "buy" ? "text-up" : "text-down"}`}>
                  {p.side.toUpperCase()}
                </td>
                <td className="px-4 py-2">{p.volume}</td>
                <td className="px-4 py-2">{p.open_price}</td>
                <td className="px-4 py-2">{p.current_price}</td>
                <td className={`px-4 py-2 ${Number(p.profit) >= 0 ? "text-up" : "text-down"}`}>
                  ${p.profit}
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
        {(!positions || positions.length === 0) && (
          <p className="p-6 text-center text-sm text-muted">No open positions.</p>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, sub, accent }: {
  label: string; value: string; sub?: string; accent?: boolean;
}) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-xs uppercase text-muted">{label}</div>
      <div className={`mt-1 truncate text-lg font-bold ${accent ? "text-up" : ""}`}>
        {value}
      </div>
      {sub && <div className="text-xs text-muted">{sub}</div>}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs text-muted">{label}</label>
      {children}
    </div>
  );
}

const money = (v: string) => Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 });
const biasColor = (b: string) =>
  b === "bullish" ? "text-up" : b === "bearish" ? "text-down" : "text-muted";
const statusColor = (s: string) =>
  s === "open" ? "text-up" : s === "rejected" ? "text-down" : "text-accent";
