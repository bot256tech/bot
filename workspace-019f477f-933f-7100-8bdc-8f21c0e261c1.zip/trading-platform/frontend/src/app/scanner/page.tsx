"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, ScanRow, ScoreBreakdown } from "@/lib/api";
import { canAuthorSignals, useAuth } from "@/store/auth";

const TIMEFRAMES = ["M5", "M15", "M30", "H1", "H4"];
const REFRESH_MS = 15000;

export default function ScannerPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [timeframe, setTimeframe] = useState("M5");
  const [minScore, setMinScore] = useState(0);
  const [onlyTradable, setOnlyTradable] = useState(true);
  const [auto, setAuto] = useState(true);
  const [analyzing, setAnalyzing] = useState<string | null>(null);
  const [detail, setDetail] = useState<{ symbol: string; data: ScoreBreakdown } | null>(null);
  const [detailError, setDetailError] = useState<string | null>(null);

  const { data, isLoading, isFetching, error, dataUpdatedAt } = useQuery({
    queryKey: ["scan", timeframe, minScore],
    queryFn: () => api.scan({ timeframe, min_score: minScore, max_results: 100 }),
    refetchInterval: auto ? REFRESH_MS : false,
  });

  // Analyze = fetch the 8-engine breakdown for a symbol and show it in a panel.
  const analyzeMut = useMutation({
    mutationFn: (symbol: string) => api.analyze(symbol, timeframe),
    onMutate: (symbol) => {
      setAnalyzing(symbol);
      setDetailError(null);
    },
    onSuccess: (res, symbol) => setDetail({ symbol, data: res }),
    onError: (err) => setDetailError((err as Error).message),
    onSettled: () => setAnalyzing(null),
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    return onlyTradable ? all.filter((r) => r.tradable) : all;
  }, [data, onlyTradable]);

  const updated = dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString() : "—";

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Market Scanner</h1>
          <p className="text-sm text-muted">
            Best setups across all pairs — liquidity-filtered, ranked by score
            <span className="ml-2 inline-flex items-center gap-1 text-muted">
              <span
                className={`h-2 w-2 rounded-full ${
                  isFetching ? "bg-accent animate-pulse" : auto ? "bg-up" : "bg-muted"
                }`}
              />
              {auto ? `auto · ${updated}` : "paused"}
            </span>
          </p>
        </div>
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Timeframe">
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              className="rounded-lg border border-border bg-panel px-3 py-2 text-sm"
            >
              {TIMEFRAMES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </Field>
          <Field label="Min score">
            <input
              type="number"
              value={minScore}
              onChange={(e) => setMinScore(Number(e.target.value))}
              className="w-24 rounded-lg border border-border bg-black/30 px-3 py-2 text-sm"
            />
          </Field>
          <label className="flex items-center gap-2 py-2 text-sm text-muted">
            <input
              type="checkbox"
              checked={onlyTradable}
              onChange={(e) => setOnlyTradable(e.target.checked)}
            />
            Tradable only
          </label>
          <label className="flex items-center gap-2 py-2 text-sm text-muted">
            <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
            Auto-refresh
          </label>
          <button
            onClick={() => qc.invalidateQueries({ queryKey: ["scan"] })}
            className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-white/5"
          >
            Refresh now
          </button>
        </div>
      </header>

      {/* Summary strip */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Stat label="Profile" value={data?.profile ?? "…"} />
        <Stat label="Scanned" value={data?.scanned ?? "…"} />
        <Stat label="Tradable" value={data?.tradable ?? "…"} accent />
        <Stat
          label="Top score"
          value={rows[0]?.score ?? "—"}
        />
      </div>

      <div className="glass overflow-hidden rounded-xl">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted">
            <tr className="border-b border-border">
              <th className="px-4 py-3">#</th>
              <th className="px-4 py-3">Symbol</th>
              <th className="px-4 py-3">Score</th>
              <th className="px-4 py-3">Bias</th>
              <th className="px-4 py-3">Spread</th>
              <th className="px-4 py-3">Liquidity</th>
              <th className="px-4 py-3">Status</th>
              {canAuthorSignals(user?.role) && <th className="px-4 py-3" />}
            </tr>
          </thead>
          <tbody>
            {isLoading &&
              Array.from({ length: 8 }).map((_, i) => (
                <tr key={i} className="border-b border-border">
                  <td colSpan={8} className="px-4 py-4">
                    <div className="h-4 w-full animate-pulse rounded bg-white/5" />
                  </td>
                </tr>
              ))}
            <AnimatePresence>
              {rows.map((r: ScanRow, i: number) => (
                <motion.tr
                  key={r.symbol}
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="border-b border-border hover:bg-white/5"
                >
                  <td className="px-4 py-3 text-muted">{i + 1}</td>
                  <td className="px-4 py-3 font-medium">{r.symbol}</td>
                  <td className="px-4 py-3">
                    <ScoreBadge score={Number(r.score)} />
                  </td>
                  <td className="px-4 py-3">
                    <span className={biasColor(r.bias)}>{r.bias.toUpperCase()}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={r.spread_ok ? "" : "text-down"}>{r.spread_points} pts</span>
                  </td>
                  <td className="px-4 py-3">
                    <Flag ok={r.spread_ok} label="spread" />{" "}
                    <Flag ok={r.volume_ok} label="vol" />
                  </td>
                  <td className="px-4 py-3">
                    {r.tradable ? (
                      <span className="rounded-full bg-up/20 px-2 py-1 text-xs text-up">
                        tradable
                      </span>
                    ) : (
                      <span
                        className="rounded-full bg-white/10 px-2 py-1 text-xs text-muted"
                        title={r.reason}
                      >
                        skipped
                      </span>
                    )}
                  </td>
                  {canAuthorSignals(user?.role) && (
                    <td className="px-4 py-3 text-right">
                      {r.tradable && (
                        <button
                          onClick={() => analyzeMut.mutate(r.symbol)}
                          disabled={analyzing === r.symbol}
                          className="rounded-lg bg-accent/90 px-3 py-1 text-xs font-semibold text-white disabled:opacity-50"
                        >
                          {analyzing === r.symbol ? "…" : "Analyze"}
                        </button>
                      )}
                    </td>
                  )}
                </motion.tr>
              ))}
            </AnimatePresence>
          </tbody>
        </table>
        {error && <p className="p-4 text-sm text-down">{(error as Error).message}</p>}
        {!isLoading && rows.length === 0 && (
          <p className="p-6 text-center text-sm text-muted">
            No setups match the current filters.
          </p>
        )}
      </div>

      {detailError && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
             onClick={() => setDetailError(null)}>
          <div className="glass max-w-md rounded-xl p-5 text-sm text-down">
            Analysis failed: {detailError}
            <p className="mt-2 text-muted">
              This usually means the broker has no candle history for this symbol/timeframe.
              Try a higher timeframe (H1/H4).
            </p>
          </div>
        </div>
      )}

      {/* Analysis detail panel: full 8-engine breakdown for the clicked symbol */}
      {detail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
             onClick={() => setDetail(null)}>
          <div className="glass max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-xl p-5"
               onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold">{detail.symbol}</h3>
                <p className="text-sm">
                  Score <b>{detail.data.score}</b> ·{" "}
                  <span className={biasColor(detail.data.bias)}>{detail.data.bias}</span>{" "}
                  · alignment {detail.data.alignment}
                </p>
              </div>
              <button onClick={() => setDetail(null)}
                      className="text-muted hover:text-white">✕</button>
            </div>
            <div className="space-y-2">
              {detail.data.breakdown.map((b) => (
                <div key={b.engine}
                     className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
                  <span className="font-medium">{b.engine}</span>
                  <span className="flex items-center gap-3 text-sm">
                    <span className={biasColor(b.bias)}>{b.bias}</span>
                    <span className="text-muted">score {b.score}</span>
                    <span className={b.detected ? "text-up" : "text-muted"}>
                      {b.detected ? "✓ detected" : "· none"}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ScoreBadge({ score }: { score: number }) {
  const color =
    score >= 60 ? "bg-up/20 text-up" : score >= 40 ? "bg-accent/20 text-accent" : "bg-white/10 text-muted";
  return <span className={`rounded px-2 py-1 text-xs font-semibold ${color}`}>{score.toFixed(2)}</span>;
}

function Flag({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`text-xs ${ok ? "text-up" : "text-down"}`} title={label}>
      {ok ? "✓" : "✗"}
      {label}
    </span>
  );
}

function Stat({ label, value, accent }: { label: string; value: string | number; accent?: boolean }) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-xs uppercase text-muted">{label}</div>
      <div className={`mt-1 text-xl font-bold ${accent ? "text-accent" : ""}`}>{value}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs text-muted">{label}</label>
      {children}
    </div>
  );
}

const biasColor = (b: string) =>
  b === "bullish" ? "text-up" : b === "bearish" ? "text-down" : "text-muted";
