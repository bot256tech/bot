"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";

export default function SettingsPage() {
  const qc = useQueryClient();
  const { data: subs } = useQuery({
    queryKey: ["telegram-subs"],
    queryFn: () => api.telegramSubscribers(),
  });
  const linkMut = useMutation({ mutationFn: () => api.telegramLink() });
  const prefMut = useMutation({
    mutationFn: (v: { id: string; prefs: Record<string, boolean> }) =>
      api.telegramUpdatePrefs(v.id, v.prefs),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["telegram-subs"] }),
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-muted">Telegram notifications</p>
      </header>

      <div className="glass rounded-xl p-5">
        <h2 className="mb-3 text-sm font-semibold uppercase text-muted">
          Link Telegram
        </h2>
        <button
          onClick={() => linkMut.mutate()}
          className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white"
        >
          {linkMut.isPending ? "Generating…" : "Generate link code"}
        </button>
        {linkMut.data && (
          <div className="mt-3 rounded-lg border border-border p-3 text-sm">
            <p>
              Send this to the bot in Telegram:{" "}
              <code className="rounded bg-black/40 px-2 py-1 text-accent">
                /verify {linkMut.data.verification_code}
              </code>
            </p>
            <p className="mt-1 text-muted">{linkMut.data.instructions}</p>
          </div>
        )}
      </div>

      <div className="glass overflow-hidden rounded-xl">
        <div className="border-b border-border px-4 py-3 text-sm font-semibold uppercase text-muted">
          Linked chats
        </div>
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted">
            <tr className="border-b border-border">
              <th className="px-4 py-2">Chat</th>
              <th className="px-4 py-2">Verified</th>
              <th className="px-4 py-2">Signals</th>
              <th className="px-4 py-2">Trades</th>
              <th className="px-4 py-2">Errors</th>
            </tr>
          </thead>
          <tbody>
            {(subs ?? []).map((s) => (
              <tr key={s.id} className="border-b border-border">
                <td className="px-4 py-2">{s.username || s.chat_id}</td>
                <td className="px-4 py-2">
                  <span className={s.is_verified ? "text-up" : "text-muted"}>
                    {s.is_verified ? "✓" : "pending"}
                  </span>
                </td>
                {(["receive_signals", "receive_trades", "receive_errors"] as const).map(
                  (field) => (
                    <td key={field} className="px-4 py-2">
                      <input
                        type="checkbox"
                        checked={s[field]}
                        disabled={!s.is_verified}
                        onChange={(e) =>
                          prefMut.mutate({
                            id: s.id,
                            prefs: { [field]: e.target.checked },
                          })
                        }
                      />
                    </td>
                  ),
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {(!subs || subs.length === 0) && (
          <p className="p-6 text-center text-sm text-muted">
            No linked chats yet. Generate a code above.
          </p>
        )}
      </div>
    </div>
  );
}
