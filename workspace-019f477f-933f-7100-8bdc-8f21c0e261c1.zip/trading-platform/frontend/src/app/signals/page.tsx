"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api, openSignalSocket, Signal, SignalEvent } from "@/lib/api";
import { canAuthorSignals, useAuth } from "@/store/auth";

const STATUS_STYLE: Record<string, string> = {
  active: "bg-accent/20 text-accent",
  hit_tp: "bg-up/20 text-up",
  hit_sl: "bg-down/20 text-down",
  pending: "bg-white/10 text-muted",
  cancelled: "bg-white/10 text-muted",
  expired: "bg-white/10 text-muted",
};

const FALLBACK_SYMBOLS = ["EURUSDm", "GBPUSDm", "USDJPYm", "XAUUSDm", "BTCUSDm"];

export default function SignalsPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [live, setLive] = useState(false);
  const [symbol, setSymbol] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: scanForSymbols } = useQuery({
    queryKey: ["scan-symbols"],
    queryFn: () => api.scan({ timeframe: "H1", min_score: 0, max_results: 100 }),
    staleTime: 60000,
  });
  const symbols =
    scanForSymbols?.results?.map((r) => r.symbol) ?? FALLBACK_SYMBOLS;
  const activeSymbol = symbol || symbols[0] || "EURUSDm";

  const { data, isLoading, error } = useQuery({
    queryKey: ["signals"],
    queryFn: () => api.listSignals(),
  });

  // Watchlist monitor: pairs with a FORMING setup — good volume/spread and a
  // real bias appearing, but NOT yet at the execute threshold (85). Shown here
  // for monitoring so the Scanner isn't crowded. Range: WATCH_MIN..EXECUTE.
  const WATCH_MIN = 45;
  const EXECUTE_THRESHOLD = 85;
  const { data: sweetScan } = useQuery({
    queryKey: ["watchlist"],
    queryFn: () => api.scan({ timeframe: "M15", min_score: WATCH_MIN, max_results: 60 }),
    refetchInterval: 15000,
  });
  const watchlist = (sweetScan?.results ?? []).filter(
    (r) => r.tradable && Number(r.score) >= WATCH_MIN && Number(r.score) < EXECUTE_THRESHOLD,
  );

  const [genBusy, setGenBusy] = useState<string | null>(null);
  async function generateFor(sym: string) {
    setGenBusy(sym);
    try {
      await api.generateSignal(sym);
      qc.invalidateQueries({ queryKey: ["signals"] });
    } finally {
      setGenBusy(null);
    }
  }

  const [cleanBusy, setCleanBusy] = useState(false);
  async function cleanupFinished() {
    setCleanBusy(true);
    try {
      await api.cleanupSignals();
      qc.invalidateQueries({ queryKey: ["signals"] });
    } finally {
      setCleanBusy(false);
    }
  }
  async function removeSignal(id: string) {
    await api.cancelSignal(id);
    qc.invalidateQueries({ queryKey: ["signals"] });
  }

  // Realtime WebSocket subscription.
  useEffect(() => {
    const ws = openSignalSocket((e: SignalEvent) => {
      if (e.event === "connection.ready") {
        setLive(true);
        return;
      }
      // Any signal event -> refetch the list (source of truth stays the API).
      qc.invalidateQueries({ queryKey: ["signals"] });
    });
    return () => ws?.close();
  }, [qc]);

  async function generate() {
    setBusy(true);
    try {
      await api.generateSignal(activeSymbol);
      qc.invalidateQueries({ queryKey: ["signals"] });
    } finally {
      setBusy(false);
    }
  }

  const signals = data?.results ?? [];
  const stats = useMemo(() => {
    const total = signals.length;
    const tp = signals.filter((s) => s.status === "hit_tp").length;
    const closed = signals.filter((s) => s.status.startsWith("hit")).length;
    return {
      total,
      active: signals.filter((s) => s.status === "active").length,
      winRate: closed ? Math.round((tp / closed) * 100) : 0,
    };
  }, [signals]);

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Signals</h1>
          <p className="text-sm text-muted">
            Realtime trading signals
            <span
              className={`ml-2 inline-flex items-center gap-1 ${
                live ? "text-up" : "text-muted"
              }`}
            >
              <span
                className={`h-2 w-2 rounded-full ${
                  live ? "bg-up animate-pulse" : "bg-muted"
                }`}
              />
              {live ? "live" : "offline"}
            </span>
          </p>
        </div>
        {canAuthorSignals(user?.role) && (
          <div className="flex items-center gap-2">
            <select
              value={activeSymbol}
              onChange={(e) => setSymbol(e.target.value)}
              className="rounded-lg border border-border bg-panel px-3 py-2 text-sm"
            >
              {symbols.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
            <button
              onClick={generate}
              disabled={busy}
              className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
            >
              {busy ? "Generating…" : "Generate signal"}
            </button>
            <button
              onClick={cleanupFinished}
              disabled={cleanBusy}
              className="rounded-lg border border-border px-4 py-2 text-sm text-muted hover:text-white disabled:opacity-50"
              title="Remove expired / closed / cancelled signals"
            >
              {cleanBusy ? "Clearing…" : "Clear finished"}
            </button>
          </div>
        )}
      </header>

      {/* SWEET SPOT MONITOR — pairs that have reached a real setup (score >=60,
          good spread & volume). This is the curated feed, not the noisy scanner. */}
      <div className="glass overflow-hidden rounded-xl border border-accent/30">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <span className="text-sm font-semibold uppercase text-accent">
            👀 Watchlist — forming setups (score {WATCH_MIN}–{EXECUTE_THRESHOLD}, good spread + vol)
          </span>
          <span className="text-xs text-muted">{watchlist.length} watching</span>
        </div>
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted">
            <tr className="border-b border-border">
              <th className="px-4 py-2">Symbol</th>
              <th className="px-4 py-2">Score</th>
              <th className="px-4 py-2">Bias</th>
              <th className="px-4 py-2">Spread</th>
              <th className="px-4 py-2">Liquidity</th>
              {canAuthorSignals(user?.role) && <th className="px-4 py-2" />}
            </tr>
          </thead>
          <tbody>
            {watchlist.map((r) => (
              <tr key={r.symbol} className="border-b border-border hover:bg-white/5">
                <td className="px-4 py-2 font-medium">{r.symbol}</td>
                <td className="px-4 py-2">
                  <span className="rounded bg-up/20 px-2 py-1 text-xs font-semibold text-up">
                    {Number(r.score).toFixed(2)}
                  </span>
                </td>
                <td className={`px-4 py-2 ${r.bias === "bullish" ? "text-up" : "text-down"}`}>
                  {r.bias.toUpperCase()}
                </td>
                <td className="px-4 py-2">{r.spread_points} pts</td>
                <td className="px-4 py-2 text-up">✓ spread ✓ vol</td>
                {canAuthorSignals(user?.role) && (
                  <td className="px-4 py-2 text-right">
                    <button
                      onClick={() => generateFor(r.symbol)}
                      disabled={genBusy === r.symbol}
                      className="rounded-lg bg-accent px-3 py-1 text-xs font-semibold text-white disabled:opacity-50"
                    >
                      {genBusy === r.symbol ? "…" : "Send signal"}
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {watchlist.length === 0 && (
          <p className="p-4 text-center text-sm text-muted">
            No forming setups on the watchlist right now. Monitoring… (auto-refreshes every 15s)
          </p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Stat label="Total signals" value={stats.total} />
        <Stat label="Active" value={stats.active} accent />
        <Stat label="Win rate" value={`${stats.winRate}%`} />
      </div>

      <div className="glass overflow-hidden rounded-xl">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted">
            <tr className="border-b border-border">
              <th className="px-4 py-3">Symbol</th>
              <th className="px-4 py-3">Side</th>
              <th className="px-4 py-3">Entry</th>
              <th className="px-4 py-3">SL</th>
              <th className="px-4 py-3">TP</th>
              <th className="px-4 py-3">R:R</th>
              <th className="px-4 py-3">Conf.</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {isLoading &&
              Array.from({ length: 4 }).map((_, i) => (
                <tr key={i} className="border-b border-border">
                  <td colSpan={8} className="px-4 py-4">
                    <div className="h-4 w-full animate-pulse rounded bg-white/5" />
                  </td>
                </tr>
              ))}
            <AnimatePresence>
              {signals.map((s: Signal) => (
                <motion.tr
                  key={s.id}
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="border-b border-border hover:bg-white/5"
                >
                  <td className="px-4 py-3 font-medium">{s.symbol}</td>
                  <td className="px-4 py-3">
                    <span className={s.direction === "buy" ? "text-up" : "text-down"}>
                      {s.direction.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3">{fmt(s.entry_price)}</td>
                  <td className="px-4 py-3 text-down">{fmt(s.stop_loss)}</td>
                  <td className="px-4 py-3 text-up">{fmt(s.take_profit)}</td>
                  <td className="px-4 py-3">{s.risk_reward ?? "—"}</td>
                  <td className="px-4 py-3">{s.confidence}%</td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-1 text-xs ${
                        STATUS_STYLE[s.status] ?? "bg-white/10"
                      }`}
                    >
                      {s.status.replace("_", " ")}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => removeSignal(s.id)}
                      className="rounded px-2 py-1 text-xs text-muted hover:text-down"
                      title="Remove / cancel this signal"
                    >
                      ✕
                    </button>
                  </td>
                </motion.tr>
              ))}
            </AnimatePresence>
          </tbody>
        </table>
        {error && (
          <p className="p-4 text-sm text-down">{(error as Error).message}</p>
        )}
        {!isLoading && signals.length === 0 && (
          <p className="p-6 text-center text-sm text-muted">No signals yet.</p>
        )}
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  accent,
}: {
  label: string;
  value: string | number;
  accent?: boolean;
}) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-xs uppercase text-muted">{label}</div>
      <div className={`mt-1 text-2xl font-bold ${accent ? "text-accent" : ""}`}>
        {value}
      </div>
    </div>
  );
}

const fmt = (v: string) => Number(v).toLocaleString(undefined, {
  maximumFractionDigits: 5,
});
