"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useAuth } from "@/store/auth";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: "📊" },
  { href: "/scanner", label: "Scanner", icon: "🔍" },
  { href: "/signals", label: "Signals", icon: "📡" },
  { href: "/positions", label: "Positions", icon: "💹" },
  { href: "/analytics", label: "Analytics", icon: "📈" },
  { href: "/settings", label: "Settings", icon: "⚙️" },
];

export function Sidebar() {
  const path = usePathname();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);

  // Close the drawer whenever the route changes (mobile UX).
  useEffect(() => {
    setOpen(false);
  }, [path]);

  const NavLinks = (
    <>
      <div className="mb-6 flex items-center justify-between px-2">
        <div className="text-lg font-bold">
          <span className="text-accent">◆</span> TradeDesk
        </div>
        {/* Close button (mobile only) */}
        <button
          onClick={() => setOpen(false)}
          className="text-muted hover:text-white md:hidden"
          aria-label="Close menu"
        >
          ✕
        </button>
      </div>
      <nav className="flex-1 space-y-1">
        {NAV.map((n) => {
          const active = path?.startsWith(n.href);
          return (
            <Link
              key={n.href}
              href={n.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                active
                  ? "bg-accent/20 text-white"
                  : "text-muted hover:bg-white/5 hover:text-white"
              }`}
            >
              <span>{n.icon}</span>
              {n.label}
            </Link>
          );
        })}
      </nav>
      {user ? (
        <div className="border-t border-border pt-3 text-sm">
          <div className="truncate px-2 text-muted">{user.email}</div>
          <div className="px-2 text-xs uppercase text-accent">{user.role}</div>
          <button
            onClick={logout}
            className="mt-2 w-full rounded-lg bg-white/5 px-3 py-2 text-left text-muted hover:text-white"
          >
            Sign out
          </button>
        </div>
      ) : (
        <Link
          href="/"
          className="border-t border-border pt-3 text-sm text-muted hover:text-white"
        >
          Sign in
        </Link>
      )}
    </>
  );

  return (
    <>
      {/* Mobile top bar with hamburger (hidden on md+) */}
      <div className="glass sticky top-0 z-30 flex items-center justify-between px-4 py-3 md:hidden">
        <div className="text-base font-bold">
          <span className="text-accent">◆</span> TradeDesk
        </div>
        <button
          onClick={() => setOpen(true)}
          className="rounded-lg border border-border px-3 py-1.5 text-sm text-muted hover:text-white"
          aria-label="Open menu"
        >
          ☰ Menu
        </button>
      </div>

      {/* Desktop sidebar (always visible on md+) */}
      <aside className="glass hidden w-60 shrink-0 flex-col p-4 md:flex">
        {NavLinks}
      </aside>

      {/* Mobile slide-in drawer + overlay */}
      {open && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/60"
            onClick={() => setOpen(false)}
          />
          <aside className="glass absolute left-0 top-0 flex h-full w-64 flex-col p-4 shadow-2xl">
            {NavLinks}
          </aside>
        </div>
      )}
    </>
  );
}
