/**
 * Typed API client for the Institutional Trading Platform backend.
 *
 * Handles JWT auth (access + refresh), transparent token refresh on 401, and
 * exposes strongly-typed helpers for the signal & broker domains.
 */

/** Resolve the API/WS base URLs.
 *
 * Priority: runtime browser host (most reliable — matches whatever IP you typed
 * in the address bar) > explicit NEXT_PUBLIC_* build var > localhost fallback.
 *
 * Putting the browser host FIRST means a stale build (or a missing env file)
 * can never point the app at 127.0.0.1 when you're actually on the VPS IP.
 * Localhost dev still works because the browser host is then "localhost".
 */
function resolveApiBase(): string {
  if (typeof window !== "undefined") {
    return `${window.location.protocol}//${window.location.hostname}:8000/api/v1`;
  }
  if (process.env.NEXT_PUBLIC_API_BASE) return process.env.NEXT_PUBLIC_API_BASE;
  return "http://127.0.0.1:8000/api/v1";
}

function resolveWsBase(): string {
  if (typeof window !== "undefined") {
    const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
    return `${proto}//${window.location.hostname}:8000/ws`;
  }
  if (process.env.NEXT_PUBLIC_WS_BASE) return process.env.NEXT_PUBLIC_WS_BASE;
  return "ws://127.0.0.1:8000/ws";
}

export const API_BASE = resolveApiBase();
export const WS_BASE = resolveWsBase();

export type Role =
  | "super_admin"
  | "admin"
  | "developer"
  | "analyst"
  | "moderator"
  | "trader"
  | "subscriber";

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: Role;
  is_email_verified: boolean;
}

export type SignalDirection = "buy" | "sell";
export type SignalStatus =
  | "pending"
  | "active"
  | "hit_tp"
  | "hit_sl"
  | "expired"
  | "cancelled";

export interface Signal {
  id: string;
  symbol: string;
  direction: SignalDirection;
  status: SignalStatus;
  entry_price: string;
  stop_loss: string;
  take_profit: string;
  confidence: string;
  strategy: string;
  rationale: string;
  risk_reward: string | null;
  created_by_email: string | null;
  published_at: string | null;
  closed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Paginated<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

const ACCESS_KEY = "tp_access";
const REFRESH_KEY = "tp_refresh";

export const tokens = {
  get access() {
    return typeof window !== "undefined"
      ? localStorage.getItem(ACCESS_KEY)
      : null;
  },
  get refresh() {
    return typeof window !== "undefined"
      ? localStorage.getItem(REFRESH_KEY)
      : null;
  },
  set(access: string, refresh?: string) {
    localStorage.setItem(ACCESS_KEY, access);
    if (refresh) localStorage.setItem(REFRESH_KEY, refresh);
  },
  clear() {
    localStorage.removeItem(ACCESS_KEY);
    localStorage.removeItem(REFRESH_KEY);
  },
};

async function refreshAccess(): Promise<boolean> {
  const refresh = tokens.refresh;
  if (!refresh) return false;
  const res = await fetch(`${API_BASE}/auth/token/refresh/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh }),
  });
  if (!res.ok) return false;
  const data = await res.json();
  tokens.set(data.access);
  return true;
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  retry = true,
): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set("Content-Type", "application/json");
  if (tokens.access) headers.set("Authorization", `Bearer ${tokens.access}`);

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (res.status === 401 && retry && (await refreshAccess())) {
    return request<T>(path, options, false);
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.detail ?? `Request failed (${res.status})`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export interface Position {
  ticket: string;
  symbol: string;
  side: "buy" | "sell";
  volume: string;
  open_price: string;
  current_price: string;
  profit: string;
  stop_loss: string | null;
  take_profit: string | null;
}

export interface Trade {
  id: string;
  symbol: string;
  side: "buy" | "sell";
  status: "pending" | "open" | "closed" | "cancelled" | "rejected";
  mode: string;
  volume: string;
  entry_price: string;
  stop_loss: string | null;
  take_profit: string | null;
  close_price: string | null;
  risk_percent: string;
  risk_amount: string;
  margin_required: string;
  score: string;
  realized_pnl: string;
  broker_ticket: string;
  decision_audit: { stages?: { stage: string; passed: boolean }[] } & Record<string, unknown>;
  opened_at: string | null;
  closed_at: string | null;
  created_at: string;
}

export interface ScoreBreakdown {
  score: string;
  bias: "bullish" | "bearish" | "neutral";
  alignment: string;
  breakdown: {
    engine: string;
    detected: boolean;
    bias: string;
    score: string;
    details: Record<string, unknown>;
  }[];
}

export interface AccountSummary {
  login: string;
  balance: string;
  equity: string;
  margin: string;
  free_margin: string;
  margin_level: string;
  currency: string;
  leverage: number;
  connected: boolean;
  server: string;
  broker_name: string;
  trade_allowed: boolean;
}

export const api = {
  async login(email: string, password: string) {
    const res = await fetch(`${API_BASE}/auth/login/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) throw new Error("Invalid credentials");
    const data = await res.json();
    tokens.set(data.access, data.refresh);
    return data.user as User;
  },

  me: () => request<User>("/auth/me/"),

  listSignals: (params?: { status?: string; symbol?: string }) => {
    const q = new URLSearchParams(params as Record<string, string>).toString();
    return request<Paginated<Signal>>(`/signals/${q ? `?${q}` : ""}`);
  },

  generateSignal: (symbol: string, strategy = "momentum") =>
    request<Signal>("/signals/generate/", {
      method: "POST",
      body: JSON.stringify({ symbol, strategy }),
    }),

  cancelSignal: (id: string) =>
    request<Signal>(`/signals/${id}/cancel/`, { method: "POST" }),

  cleanupSignals: () =>
    request<{ removed: number }>("/signals/cleanup/", { method: "POST" }),

  brokerAccount: () => request<AccountSummary>("/broker/account/"),

  positions: () => request<Position[]>("/broker/positions/"),

  symbolInfo: (symbol: string) =>
    request<Record<string, unknown>>(`/broker/symbol/?symbol=${symbol}`),

  analyze: (symbol: string, timeframe = "M5") =>
    request<ScoreBreakdown>(`/trading/analyze/?symbol=${symbol}&timeframe=${timeframe}`),

  listTrades: (status?: string) =>
    request<Paginated<Trade>>(`/trading/trades/${status ? `?status=${status}` : ""}`),

  execute: (body: {
    symbol: string;
    timeframe?: string;
    htf_bias?: string;
    min_score?: number;
    place_order?: boolean;
    mode?: string;
  }) =>
    request<Trade>("/trading/trades/execute/", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  closeTrade: (id: string, volume?: string) =>
    request<Trade>(`/trading/trades/${id}/close/`, {
      method: "POST",
      body: JSON.stringify(volume ? { volume } : {}),
    }),

  modifyTrade: (id: string, stop_loss?: string, take_profit?: string) =>
    request<Trade>(`/trading/trades/${id}/modify/`, {
      method: "POST",
      body: JSON.stringify({ stop_loss, take_profit }),
    }),

  analytics: () => request<Metrics>("/trading/analytics/"),

  activeProfile: () => request<ActiveProfile>("/trading/profile/"),

  scan: (params?: { timeframe?: string; min_score?: number; max_results?: number }) => {
    const q = new URLSearchParams(
      Object.fromEntries(
        Object.entries(params ?? {}).map(([k, v]) => [k, String(v)]),
      ),
    ).toString();
    return request<MarketScan>(`/trading/scan/${q ? `?${q}` : ""}`);
  },

  telegramLink: () =>
    request<{ verification_code: string; instructions: string }>(
      "/telegram/link/",
      { method: "POST" },
    ),
  telegramSubscribers: () =>
    request<TelegramSubscriber[]>("/telegram/subscribers/"),
  telegramUpdatePrefs: (
    id: string,
    prefs: Partial<Pick<TelegramSubscriber, "receive_signals" | "receive_trades" | "receive_errors">>,
  ) =>
    request<TelegramSubscriber>(`/telegram/subscribers/${id}/`, {
      method: "PATCH",
      body: JSON.stringify(prefs),
    }),
};

export interface ScanRow {
  symbol: string;
  tradable: boolean;
  score: string;
  bias: "bullish" | "bearish" | "neutral";
  spread_points: number;
  spread_ok: boolean;
  volume_ok: boolean;
  reason: string;
}

export interface MarketScan {
  profile: string;
  timeframe: string;
  scanned: number;
  tradable: number;
  results: ScanRow[];
}

export interface ActiveProfile {
  name: "SMALL" | "PROP";
  account_equity: string;
  threshold: string;
  risk_percent: string;
  min_score: string;
  max_open_trades: number;
  max_daily_trades: number;
  trades_today: number;
  daily_drawdown_limit_percent: string;
  max_drawdown_limit_percent: string;
  require_htf_match: boolean;
  prop_guard?: {
    allowed: boolean;
    tier: "OK" | "WARNING" | "SOFT_STOP" | "HARD_STOP";
    reasons: string[];
    checks: Record<string, unknown>;
  };
}

export interface TelegramSubscriber {
  id: string;
  chat_id: string;
  username: string;
  receive_signals: boolean;
  receive_trades: boolean;
  receive_errors: boolean;
  is_verified: boolean;
  created_at: string;
}

export interface Metrics {
  total_trades: number;
  wins?: number;
  losses?: number;
  win_rate: string;
  loss_rate: string;
  profit_factor: string;
  expectancy: string;
  avg_rr: string;
  gross_profit: string;
  gross_loss: string;
  net_profit: string;
  max_drawdown: string;
  equity_curve: { time: string; equity: string; trade_pnl: string; symbol: string }[];
  by_symbol: Record<string, { trades: number; win_rate: string; net: string }>;
}

export interface SignalEvent {
  event: "connection.ready" | "signal.created" | "signal.update" | "signal.closed";
  data: Signal | { group: string };
}

/** Open an authenticated WebSocket for realtime signal events. */
export function openSignalSocket(
  onEvent: (e: SignalEvent) => void,
): WebSocket | null {
  if (!tokens.access) return null;
  const ws = new WebSocket(`${WS_BASE}/signals/?token=${tokens.access}`);
  ws.onmessage = (msg) => onEvent(JSON.parse(msg.data) as SignalEvent);
  return ws;
}
