/** Global auth state (Zustand). */
import { create } from "zustand";
import { api, tokens, User } from "@/lib/api";

interface AuthState {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  hydrate: () => Promise<void>;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: false,
  async login(email, password) {
    set({ loading: true });
    try {
      const user = await api.login(email, password);
      set({ user });
    } finally {
      set({ loading: false });
    }
  },
  logout() {
    tokens.clear();
    set({ user: null });
  },
  async hydrate() {
    if (!tokens.access) return;
    try {
      const user = await api.me();
      set({ user });
    } catch {
      tokens.clear();
    }
  },
}));

const CAN_AUTHOR: User["role"][] = ["super_admin", "admin", "analyst", "trader"];
export const canAuthorSignals = (role?: User["role"]) =>
  !!role && CAN_AUTHOR.includes(role);
