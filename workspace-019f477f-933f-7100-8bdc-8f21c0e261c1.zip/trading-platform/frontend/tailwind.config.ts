import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0a0e17", panel: "#111725", border: "#1e2637",
        muted: "#8592a6", accent: "#3b82f6", up: "#16c784", down: "#ea3943",
      },
    },
  },
  plugins: [],
};
export default config;
