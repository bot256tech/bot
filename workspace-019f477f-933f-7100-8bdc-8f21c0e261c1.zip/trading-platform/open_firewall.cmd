@echo off
REM ============================================================================
REM open_firewall.cmd  -  Opens Windows Firewall inbound ports 8000 and 3000.
REM RIGHT-CLICK -> "Run as administrator".
REM
REM NOTE: On a cloud VPS you must ALSO open ports 3000 and 8000 in your cloud
REM provider's firewall / security group panel - Windows firewall alone is not
REM enough to make the public IP reachable.
REM ============================================================================
netsh advfirewall firewall add rule name="TradeDesk Backend 8000" dir=in action=allow protocol=TCP localport=8000
netsh advfirewall firewall add rule name="TradeDesk Frontend 3000" dir=in action=allow protocol=TCP localport=3000
echo.
echo Opened inbound TCP ports 8000 and 3000 in Windows Firewall.
echo If the public IP is still unreachable, open the same ports in your cloud
echo provider's firewall / security group.
pause
