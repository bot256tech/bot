@echo off
REM ============================================================================
REM rebuild_frontend.cmd  -  Force a clean rebuild of the frontend.
REM Run this AFTER editing frontend\.env.production (VPS IP / API URL), because
REM Next.js bakes NEXT_PUBLIC_* values into the build at build time.
REM ============================================================================
setlocal
cd /d "%~dp0frontend"

echo Removing old build...
if exist ".next" rmdir /s /q ".next"

echo Installing dependencies...
call npm install

echo Building with current .env.production...
call npm run build

echo.
echo Rebuild complete.
endlocal
