# -----------------------------------------------------------------------------
# open_firewall.ps1
# Opens the Windows Firewall inbound ports so the platform is reachable from a
# browser on the VPS public IP. RUN AS ADMINISTRATOR.
#
#     powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\open_firewall.ps1
#
# NOTE: On a cloud VPS you usually ALSO need to open these ports in the cloud
# provider's network security group / firewall panel (AWS Security Group, Azure
# NSG, etc.) - the Windows firewall alone is not enough.
# -----------------------------------------------------------------------------
$ErrorActionPreference = "Stop"

$rules = @(
    @{ Name = "TradeDesk Backend 8000";  Port = 8000 },
    @{ Name = "TradeDesk Frontend 3000"; Port = 3000 }
)

foreach ($r in $rules) {
    $existing = Get-NetFirewallRule -DisplayName $r.Name -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Host "Rule already exists: $($r.Name)"
    } else {
        New-NetFirewallRule -DisplayName $r.Name -Direction Inbound `
            -Action Allow -Protocol TCP -LocalPort $r.Port | Out-Null
        Write-Host "Opened inbound TCP port $($r.Port): $($r.Name)"
    }
}

Write-Host ""
Write-Host "Windows Firewall configured. If the site is STILL unreachable:"
Write-Host "  1. Open ports 8000 & 3000 in your cloud provider's firewall/security group."
Write-Host "  2. Make sure the backend runs with -b 0.0.0.0 and the frontend with -H 0.0.0.0."
