# -----------------------------------------------------------------------------
# run_backend.ps1
# Starts the Django ASGI server (Daphne) for HTTP + WebSocket traffic.
# Binds 0.0.0.0 by default so the VPS is reachable from a browser.
#
# RUN IT AS A FILE (do NOT paste the contents line-by-line):
#     powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_backend.ps1
# -----------------------------------------------------------------------------
param(
    [string]$BindHost = "0.0.0.0",
    [int]$Port = 8000
)

$ErrorActionPreference = "Stop"

# Resolve project root robustly (works when run as a file OR pasted).
if ($PSScriptRoot) {
    $root = Split-Path -Parent $PSScriptRoot
} else {
    $root = "C:\trading-platform"
}
Set-Location "$root\backend"

# Activate virtual environment if present.
if (Test-Path "$root\backend\.venv\Scripts\Activate.ps1") {
    & "$root\backend\.venv\Scripts\Activate.ps1"
}

python manage.py migrate --noinput
python manage.py collectstatic --noinput

# Daphne serves both HTTP and WebSockets (ASGI).
daphne -b $BindHost -p $Port config.asgi:application
