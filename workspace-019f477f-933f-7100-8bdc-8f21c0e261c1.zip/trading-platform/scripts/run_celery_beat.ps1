# -----------------------------------------------------------------------------
# run_celery_beat.ps1
# Starts the Celery beat scheduler (periodic signal eval, resampler cache purge,
# data-latency monitor). Wrap as an NSSM service.
#
# RUN IT AS A FILE (do NOT paste the contents line-by-line):
#     powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_celery_beat.ps1
# -----------------------------------------------------------------------------
$ErrorActionPreference = "Stop"

if ($PSScriptRoot) {
    $root = Split-Path -Parent $PSScriptRoot
} else {
    $root = "C:\trading-platform"
}
Set-Location "$root\backend"

if (Test-Path "$root\backend\.venv\Scripts\Activate.ps1") {
    & "$root\backend\.venv\Scripts\Activate.ps1"
}

celery -A config beat --loglevel=info
