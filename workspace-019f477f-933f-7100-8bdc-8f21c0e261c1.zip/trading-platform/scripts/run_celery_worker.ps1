# -----------------------------------------------------------------------------
# run_celery_worker.ps1
# Starts a Celery worker (signal generation / evaluation / prop-guard tasks).
#
# RUN IT AS A FILE (do NOT paste the contents line-by-line):
#     powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_celery_worker.ps1
# -----------------------------------------------------------------------------
$ErrorActionPreference = "Stop"

if ($PSScriptRoot) {
    $root = Split-Path -Parent $PSScriptRoot
} else {
    $root = "C:\trading-platform"
}
Set-Location "$root\backend"

if (Test-Path "$root\backend\.venv\Scripts\Activate.ps1") {
    & "$root\backend\.venv\Scripts\Activate.ps1"
}

# The "solo" pool is the most reliable on Windows.
celery -A config worker --loglevel=info --pool=solo
