# -----------------------------------------------------------------------------
# run_frontend.ps1
# Builds and serves the Next.js frontend in production mode on all interfaces
# so the VPS is reachable at http://<vps-ip>:3000.
#
# RUN IT AS A FILE (do NOT paste the contents line-by-line):
#     powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\run_frontend.ps1
# -----------------------------------------------------------------------------
param([int]$Port = 3000)

$ErrorActionPreference = "Stop"

if ($PSScriptRoot) {
    $root = Split-Path -Parent $PSScriptRoot
} else {
    $root = "C:\trading-platform"
}
Set-Location "$root\frontend"

# Install deps + build if not already built. Use `npm install` (npm ci needs a
# committed package-lock.json).
if (-not (Test-Path "$root\frontend\.next")) {
    if (Test-Path "$root\frontend\package-lock.json") {
        npm ci
    } else {
        npm install
    }
    npm run build
}

$env:PORT = $Port
# -H 0.0.0.0 makes Next.js listen on all interfaces (reachable from outside).
npm run start -- -H 0.0.0.0 -p $Port
