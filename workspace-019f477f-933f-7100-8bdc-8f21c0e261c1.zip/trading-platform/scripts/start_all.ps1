# -----------------------------------------------------------------------------
# start_all.ps1
# One-shot launcher: opens each platform component in its own PowerShell window.
# Good for quick manual startup (for production, prefer the NSSM services).
#
#     powershell -ExecutionPolicy Bypass -File C:\trading-platform\scripts\start_all.ps1
# -----------------------------------------------------------------------------
$ErrorActionPreference = "Stop"

if ($PSScriptRoot) {
    $scripts = $PSScriptRoot
} else {
    $scripts = "C:\trading-platform\scripts"
}

function Start-Component {
    param([string]$Title, [string]$File)
    Write-Host "Launching $Title ..."
    Start-Process powershell -ArgumentList @(
        "-NoExit", "-ExecutionPolicy", "Bypass", "-File", "$scripts\$File"
    )
    Start-Sleep -Seconds 2
}

Write-Host "Starting the Institutional Trading Platform..."
Write-Host "(Ensure PostgreSQL, Redis/Memurai and the MT5 terminal are already running.)"
Write-Host ""

Start-Component -Title "Backend (Daphne :8000)"     -File "run_backend.ps1"
Start-Component -Title "Celery Worker"               -File "run_celery_worker.ps1"
Start-Component -Title "Celery Beat"                 -File "run_celery_beat.ps1"
Start-Component -Title "Frontend (Next.js :3000)"    -File "run_frontend.ps1"

Write-Host ""
Write-Host "All components launched in separate windows."
Write-Host "  Backend  : http://<vps-ip>:8000/api/docs/"
Write-Host "  Frontend : http://<vps-ip>:3000"
Write-Host "Close a window to stop that component."
